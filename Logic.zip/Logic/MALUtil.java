package ConsistencyRuleModel.Transformation.Logic;

    import java.util.Set;  
    import aquintos.mm.eea.mapping.MSWComponentMapping;  
    import aquintos.mm.metricmm.datatypes.MDataType;  
    import aquintos.mm.eea.signalpoollayer.MSystemSignalGroup;  
    import aquintos.mm.eea.signalpoollayer.MSignalGatewayRoutingEntry;  
    import aquintos.mm.eea.mapping.MAbstractLayerMappings;  
    import java.util.regex.Pattern;  
    import aquintos.mm.metricmm.datatypes.MApplicationRecordType;  
    import aquintos.mm.eea.enumerations.MEthernetPhysicalLayerTypeEnumEnum;  
    import aquintos.mm.eea.signalpoollayer.datatransformation.MSomeIpTransformer;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MServiceNeeds;  
    import aquintos.mm.eea.signalpoollayer.MFrameGatewayRoutingEntry;  
    import aquintos.mm.eea.signalpoollayer.nwmanagement.MCanNmCluster;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MServiceDependency;  
    import aquintos.mm.di.MSectionGraphNode;  
    import aquintos.mm.metricmm.datatypes.computationmethods.MAbstractConversionSpecification;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MVariableWrite;  
    import aquintos.mm.eea.signalpoollayer.nwmanagement.MUdpNmECU;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MRTEEvent;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MOperation;  
    import aquintos.mm.metricmm.util.AttributeDefinitionUtility;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MAbstractPortType;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MModeDeclarationGroupElementOwner;  
    import aquintos.mm.eea.mapping.MReqHWLogMapping;  
    import aquintos.mm.eea.componentslayer.MECU;  
    import aquintos.mm.metricmm.datatypes.MMinMaxGeneric;  
    import aquintos.mm.eea.signalpoollayer.tplayer.MCanTpConnection;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MDataElement;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MInformationUnit;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MRecordSpecification;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MArraySpecification;  
    import aquintos.mm.metricmm.datatypes.MApplicationBooleanType;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MReceiverComSpec;  
    import aquintos.mm.metricmm.enumerations.MByteOrderKind;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MInternalBehavior;  
    import aquintos.mm.eea.signalpoollayer.nwmanagement.MAbstractNmNode;  
    import aquintos.mm.metricmm.datatypes.MApplicationIntegerType;  
    import aquintos.mm.eea.signalpoollayer.MSignalIPDU;  
    import aquintos.mm.eea.signalpoollayer.MAbstractTransmittableSignal;  
    import aquintos.mm.metricmm.datatypes.MHasInvalidValue;  
    import java.util.Optional;  
    import aquintos.mm.metricmm.datatypes.computationmethods.MAbstractComputationMethodUser;  
    import aquintos.mm.eea.componentslayer.MECUInterface;  
    import aquintos.mm.metricmm.enumerations.MIntervalTypeKindEnum;  
    import aquintos.mm.eea.core.MProductLine;  
    import aquintos.mm.metricmm.datatypes.computationmethods.MVerbalTableConversion;  
    import com.itiv.generalStore.utilities.mofmodel.MDFObjectUtil;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MSenderPortType;  
    import aquintos.mm.metricmm.datatypes.MApplicationTypeImplementationTypeMapping;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MAbstractAtomicSWComponentType;  
    import aquintos.mm.metricmm.datatypes.MApplicationDataType;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MAbstractSWType;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MDataTypedInformationUnit;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MClassicAtomicSWComponentType;  
    import aquintos.mm.eea.componentslayer.MSchematicPin;  
    import aquintos.mm.eea.signalpoollayer.MDynamicPartAlternative;  
    import aquintos.mm.eea.core.MEEDiagram;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MMode;  
    import aquintos.mm.commoncore.MGenericAttribute;  
    import aquintos.mm.metricmm.datatypes.computationmethods.MLinearVerbalTableConversion;  
    import aquintos.mm.eea.signalpoollayer.MPDUFrameAssignment;  
    import aquintos.mm.eea.signalpoollayer.ethernet.socketcommunication.MSocketConnectionIpduIdentifier;  
    import aquintos.mm.eea.signalpoollayer.pdutypes.MGeneralPurposeIPDU;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MTimingEvent;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MVariableAccess;  
    import aquintos.mm.eea.functionnetworklayer.fninstance.MAtomicSWComponent;  
    import aquintos.mm.eea.signalpoollayer.datatransformation.MDataTransformation;  
    import java.util.regex.Matcher;  
    import aquintos.mm.eea.signalpoollayer.ethernet.switchconfiguration.MCouplingPort;  
    import aquintos.mm.metricmm.datatypes.implementationdatatypes.MImplementationRecord;  
    import aquintos.mm.metricmm.enumerations.MBaseTypeEncodingEnumEnum;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MCompositionType;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MPortPrototypeReadAccess;  
    import aquintos.mm.eea.componentslayer.MInternalComponentArtefact;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MBooleanLiteral;  
    import aquintos.utilities.collections.HashSet;  
    import aquintos.mm.eea.signalpoollayer.nwmanagement.MUdpNmCluster;  
    import aquintos.mm.eea.componentslayer.signaltransmission.MPDUTransmission;  
    import aquintos.mm.eea.signalpoollayer.tplayer.MCanTpNode;  
    import aquintos.mm.eea.signalpoollayer.MSignal;  
    import aquintos.mm.eea.functionnetworklayer.fninstance.MAbstractRPortTxMappableArtefact;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MDataRead;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MClientPortType;  
    import aquintos.mm.eea.signalpoollayer.MLINCommunication;  
    import aquintos.mm.eea.signalpoollayer.MDynamicPart;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MPrimitiveSpecification;  
    import aquintos.mm.eea.functionnetworklayer.fninstance.MAbstractPPortTxMappableArtefact;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MDataReceivedEvent;  
    import aquintos.mm.eea.signalpoollayer.MAbstractSignal;  
    import aquintos.mm.metricmm.datatypes.implementationdatatypes.MImplementationDataType;  
    import aquintos.mm.eea.componentslayer.MElectronicComposite;  
    import aquintos.mm.eea.connections.MBusSystem;  
    import aquintos.mm.eea.signalpoollayer.MAbstractDataTypeMappingTarget;  
    import aquintos.mm.metricmm.datatypes.MApplicationArrayType;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MClientServerInterface;  
    import aquintos.mm.eea.signalpoollayer.MPDU;  
    import aquintos.mm.eea.signalpoollayer.ethernet.socketcommunication.MSocketConnectionBundle;  
    import aquintos.mm.metricmm.datatypes.MApplicationRecordElement;  
    import aquintos.mm.eea.componentslayer.MAbstractInternalComponentArtefactOwner;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MPortGroupType;  
    import aquintos.mm.eea.componentslayer.MHWSWMappedArtefact;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MPortType;  
    import aquintos.mm.eea.signalpoollayer.datatransformation.MEndToEndTransformer;  
    import aquintos.mm.eea.signalpoollayer.MGateway;  
    import aquintos.mm.eea.signalpoollayer.MAbstractSignalMappingTarget;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MSoftwareTypeContainer;  
    import aquintos.mm.eea.functionnetworklayer.swprototypes.MSWPortPrototype;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MComplexDeviceDriverComponentType;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MTypedPerInstanceMemory;  
    import aquintos.mm.metricmm.datatypes.MApplicationFloatType;  
    import java.util.stream.Collectors;  
    import aquintos.mm.eea.signalpoollayer.MSignalReceiverAttribute;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MApplicationSWComponentType;  
    import aquintos.mm.eea.signalpoollayer.MSignalGroup;  
    import aquintos.mm.metricmm.enumerations.MByteOrderKindEnum;  
    import aquintos.mm.di.MChildAreaGraphNode;  
    import aquintos.mm.metricmm.datatypes.basetypes.MBaseType;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MValueSpecification;  
    import aquintos.mm.metricmm.datatypes.computationmethods.MComputationMethod;  
    import aquintos.mm.eea.signalpoollayer.nwmanagement.MUdpNmNode;  
    import aquintos.mm.metricmm.datatypes.implementationdatatypes.MImplementationArrayIndex;  
    import aquintos.mm.eea.signalpoollayer.tplayer.MCanTpEcu;  
    import aquintos.mm.eea.signalpoollayer.MIPDU;  
    import aquintos.mm.eea.signalpoollayer.MMultiplexedIPDU;  
    import aquintos.mm.eea.functionnetworklayer.swprototypes.MAtomicSWComponentPrototype;  
    import aquintos.mm.eea.connections.MCluster;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MServerPortType;  
    import aquintos.mm.eea.signalpoollayer.MCANIdentifierEntry;  
    import aquintos.mm.eea.enumerations.MContainerIPDUHeaderTypeEnumEnum;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MInterfaceAssignment;  
    import aquintos.mm.metricmm.datatypes.MAddressingMethod;  
    import aquintos.mm.eea.signalpoollayer.MAbstractPort;  
    import aquintos.mm.eea.signalpoollayer.MCommunicationArtefact;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MVariableRead;  
    import aquintos.mm.eea.functionnetworklayer.fninstance.MAssembly;  
    import aquintos.mm.metricmm.datatypes.MApplicationTypedArtefact;  
    import aquintos.mm.eea.mapping.MPPortTransmissionMapping;  
    import aquintos.mm.eea.signalpoollayer.MSystemSignal;  
    import aquintos.mm.eea.signalpoollayer.MChannelCommunication;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MRunnableEntity;  
    import aquintos.mm.eea.signalpoollayer.timing.MCyclicTiming;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MFloatLiteral;  
    import aquintos.mm.eea.mapping.MDataTypeSystemSignalMapping;  
    import aquintos.mm.eea.signalpoollayer.portconfigurations.MAbstractControllerConfiguration;  
    import aquintos.mm.eea.signalpoollayer.ethernet.ethernetcommunication.MVlan;  
    import aquintos.mm.eea.signalpoollayer.nwmanagement.MAbstractNmCluster;  
    import java.util.ArrayList;  
    import aquintos.mm.eea.signalpoollayer.MCANCommunication;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MLongLiteral;  
    import aquintos.mm.metricmm.datatypes.MGenericInternalDataConstraint;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MAbstractInterfaceAssignmentOwner;  
    import aquintos.mm.commoncore.MAbstractNameAttributeArtefact;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MReceiverPortType;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MModeDeclarationGroup;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MSenderReceiverPortType;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MDoubleLiteral;  
    import aquintos.mm.eea.functionnetworklayer.swprototypes.MAbstractSWPrototypeArtefact;  
    import aquintos.mm.eea.signalpoollayer.timing.MAbstractTiming;  
    import aquintos.mm.metricmm.datatypes.arcoreartefact.MARCoreArtefact;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MInterface;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MAtomicSWComponentType;  
    import aquintos.mm.metricmm.datatypes.implementationdatatypes.MImplementationRecordElement;  
    import aquintos.mm.eea.signalpoollayer.MAbstractChannelCommunicationContentOwner;  
    import aquintos.mm.eea.signalpoollayer.datatransformation.MTransformerAssignment;  
    import aquintos.mm.eea.componentslayer.MConventionalConnector;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MSenderReceiverInterface;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MClientServerPortType;  
    import aquintos.mm.eea.mapping.MDataTypeMappings;  
    import aquintos.mm.eea.functionnetworklayer.fninstance.MAbstractSWInstance;  
    import aquintos.mm.metricmm.datatypes.implementationdatatypes.MImplementationArray;  
    import aquintos.mm.eea.signalpoollayer.tplayer.MEthernetTpNode;  
    import aquintos.mm.eea.signalpoollayer.MDcmIPDU;  
    import aquintos.mm.eea.mapping.MMappingElement;  
    import java.util.List;  
    import aquintos.mm.eea.signalpoollayer.datatransformation.MTransformerConfiguration;  
    import aquintos.mm.eea.componentslayer.signaltransmission.MFrameTransmission;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MModeSwitchInterface;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MPortTypeOwner;  
    import aquintos.mm.eea.functionnetworklayer.fninstance.MSWPort;  
    import aquintos.mm.commoncore.attributedefinitionextension.MAbstractAttributeValue;  
    import aquintos.mm.metricmm.datatypes.computationmethods.MLinearConversion;  
    import aquintos.mm.eea.signalpoollayer.MIPDUGatewayRoutingEntry;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MSoftwareTypePackage;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MOperationInvokedEvent;  
    import aquintos.mm.eea.signalpoollayer.portconfigurations.MLINControllerConfiguration;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MOperationArgument;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MPPortType;  
    import aquintos.mm.metricmm.datatypes.MApplicationValueType;  
    import aquintos.mm.eea.signalpoollayer.ethernet.socketcommunication.MSocketAddress;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MNvData;  
    import aquintos.mm.eea.componentslayer.MProcessUnit;  
    import aquintos.mm.eea.administration.MLINConnectorType;  
    import aquintos.mm.eea.componentslayer.MMicroprocessor;  
    import aquintos.mm.eea.signalpoollayer.datatransformation.MGenericTransformer;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MRPortType;  
    import aquintos.mm.metricmm.datatypes.implementationdatatypes.MImplementationTypedArtefact;  
    import aquintos.mm.eea.signalpoollayer.nwmanagement.MCanNmECU;  
    import aquintos.mm.metricmm.datatypes.computationmethods.MTableValue;  
    import aquintos.mm.eea.componentslayer.signaltransmission.MSignalTransmission;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MPerInstanceMemory;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MModeDeclarationGroupElement;  
    import aquintos.mm.eea.signalpoollayer.ethernet.socketcommunication.MHasPduSocketConnectionIpduIdentifier;  
    import aquintos.mm.eea.signalpoollayer.MSignalIPDUAssignment;  
    import aquintos.mm.eea.core.MEEAttribute;  
    import aquintos.mm.eea.signalpoollayer.tplayer.MDoIpTpConnection;  
    import aquintos.mm.eea.signalpoollayer.tplayer.MAbstractTpConnection;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MExclusiveArea;  
    import aquintos.mm.eea.componentslayer.MEthernetECUInterface;  
    import aquintos.mm.eea.signalpoollayer.MContainerIPDU;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MSensorActuatorSWComponentType;  
    import ru.novosoft.mdf.ext.MDFObject;  
    import aquintos.mm.metricmm.datatypes.MAbstractApplicationDataTypeMapping;  
    import aquintos.mm.eea.signalpoollayer.nwmanagement.MCanNmNode;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MDataSendCompletedEvent;  
    import aquintos.mm.commoncore.attributedefinitionextension.MAbstractEnumEntry;  
    import aquintos.mm.di.MDiagramElement;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MModeSwitchPoint;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MModeAccessPoint;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MInitEvent;  
    import aquintos.mm.eea.administration.MBusConnectorType;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MStringLiteral;  
    import aquintos.mm.eea.componentslayer.MDetailedElectricElectronic;  
    import aquintos.mm.eea.signalpoollayer.MLINSchedule;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.internalbehavior.MOperationInvoke;  
    import aquintos.mm.eea.administration.MBusType;  
    import aquintos.mm.metricmm.datatypes.implementationdatatypes.MImplementationValue;  
    import aquintos.mm.eea.signalpoollayer.portconfigurations.MEthernetControllerConfiguration;  
    import aquintos.mm.eea.signalpoollayer.tplayer.MCanTpChannel;  
    import aquintos.mm.eea.componentslayer.MLogicalConnector;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MSenderDelegationPortType;  
    import aquintos.mm.metricmm.datatypes.valuespecification.MIntegerLiteral;  
    import java.util.Collection;  
    import java.util.Collections;  
    import aquintos.mm.eea.signalpoollayer.tplayer.MLinTpConnection;  
    import aquintos.mm.eea.componentslayer.signaltransmission.MLINFrameTransmission;  
    import aquintos.mm.eea.componentslayer.MSignalConnector;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MReceiverDelegationPortType;  
    import aquintos.mm.eea.functionnetworklayer.fntypes.MSenderComSpec;  
    import aquintos.mm.eea.enumerations.MLINChecksumTypeEnumEnum;  
    import aquintos.mm.metricmm.datatypes.MDataTypeUnit;  
    import aquintos.mm.eea.signalpoollayer.ethernet.socketcommunication.MSocketConnection;  
    import aquintos.mm.eea.functionnetworklayer.fninstance.MAbstractSWPort;  
    import aquintos.mm.eea.componentslayer.MBusConnector;  
    import aquintos.mm.eea.mapping.MRPortTransmissionMapping;  
    import aquintos.mm.impl.m2m.rm3.core.logic.IM2MLogicClass;  

public class MALUtil implements aquintos.mm.impl.m2m.rm3.core.logic.IM2MLogicClass {

//Attributes



//methods
public static boolean checkIfSenderPortHasValidReciverPortConnected(MSWPort source) {
if (source.getSwPortPrototype().getPortType() instanceof MSenderPortType) {
if(source.getSwPortPrototype().getPortType().getInterfaceAssignment().getAssignedInterface() instanceof MSenderReceiverInterface){
      HashSet<MSWPort> portSet = new HashSet<>();
      boolean findReceiverPortValue = findReceiverPort(source, portSet);
      return !findReceiverPortValue;
    }
	return false;
	}
    return false;
  } 
   	
public static boolean findReceiverPort(MSWPort source1, HashSet<MSWPort> portSet1) {
portSet1.add(source1);
    Collection<MAssembly> assemblies = source1.getAssemblies();
    for (MAssembly assembly : assemblies) {
      List<MAbstractSWPort> connectedPorts = assembly.getConnectedPorts();
      for (MAbstractSWPort connectedPort : connectedPorts) {
        if (!portSet1.contains(connectedPort) && connectedPort instanceof MSWPort) {
          MSWPort mswPort = (MSWPort) connectedPort;
          if (mswPort.getSwPortPrototype().getPortType() instanceof MReceiverPortType) {
            return true;
          } else {
            boolean found = findReceiverPort(mswPort, portSet1);
            if (found) {
              return true;
            }
          }
        }
      }
    }
    return false;
  } 
   	
public static boolean checkIfReceiverPortHasValidSenderPortConnected(MSWPort source) {
if (source.getSwPortPrototype().getPortType() instanceof MReceiverPortType) {
if(source.getSwPortPrototype().getPortType().getInterfaceAssignment().getAssignedInterface() instanceof MSenderReceiverInterface){
      HashSet<MSWPort> portSet = new HashSet<>();
      boolean findSenderPortValue = findSenderPort(source, portSet);
      return !findSenderPortValue;
    }
	return false;
	}
    return false;
  } 
   	
public static boolean findSenderPort(MSWPort source1, HashSet<MSWPort> portSet1) {
portSet1.add(source1);
    Collection<MAssembly> assemblies = source1.getAssemblies();
    for (MAssembly assembly : assemblies) {
      List<MAbstractSWPort> connectedPorts = assembly.getConnectedPorts();
      for (MAbstractSWPort connectedPort : connectedPorts) {
        if (!portSet1.contains(connectedPort) && connectedPort instanceof MSWPort) {
          MSWPort mswPort = (MSWPort) connectedPort;
          if (mswPort.getSwPortPrototype().getPortType() instanceof MSenderPortType) {
            return true;
          } else {
            boolean found = findSenderPort(mswPort, portSet1);
            if (found) {
              return true;
            }
          }
        }
      }
    }
    return false;
  } 
   	
public static boolean checkIfModeValuesAreDuplicate(MModeDeclarationGroup modeDeclarationGroup) {
List<MMode> modes = modeDeclarationGroup.getModes();
    HashSet<Integer> modeValues = new HashSet<>();
    for (MMode mode : modes) {
      int value = mode.getValue();
      if (!modeValues.contains(value)) {
        modeValues.add(value);
      }
      else {
        return true;
      }
    }
	return false;
  } 
   	
public static boolean checkIfArtifactsBelongToSamePL(MECUInterface ECUInterface, MAbstractControllerConfiguration controller, MBusConnector signalConnector) {
MProductLine controllerPL = null;
MProductLine ecuInterfacePL = null;
MProductLine connectorPL = null;
    Set<MDFObject> allParents_controller = MDFObjectUtil.getAllParents(controller);
    for(MDFObject controllerParent :allParents_controller) {
      if(controllerParent instanceof MProductLine) {
        controllerPL = (MProductLine) controllerParent;
      }
    }
    Set<MDFObject> allParents_ecuInterface = MDFObjectUtil.getAllParents(ECUInterface);
    for (MDFObject ecuInterfacePArent : allParents_ecuInterface) {
      if (ecuInterfacePArent instanceof MProductLine) {
        ecuInterfacePL = (MProductLine) ecuInterfacePArent;
      }
    }

    Set<MDFObject> allParents_connector = MDFObjectUtil.getAllParents(signalConnector);
    for (MDFObject connectorParent : allParents_connector) {
      if (connectorParent instanceof MProductLine) {
        connectorPL = (MProductLine) connectorParent;
      }
    }
    if (ecuInterfacePL != null && controllerPL != null && connectorPL != null) {
      if (ecuInterfacePL != controllerPL || ecuInterfacePL != connectorPL) {
        return true;
      }

    }
return false;
  } 
   	
public static boolean isOneMasterAndAlteastOneSlavePresent(MChannelCommunication channelCommunication) {
boolean masterPresent = false;
    boolean slavePresent = false;
    List<MECUInterface> ecuInterfaces = channelCommunication.getEcuInterfaces();
    for(MECUInterface ecuInterface : ecuInterfaces) {
      MAbstractControllerConfiguration controllerConfigurationOfECUInterface = ecuInterface.getControllerConfigurationOfECUInterface();
      if (controllerConfigurationOfECUInterface instanceof MLINControllerConfiguration) {
        if (((MLINControllerConfiguration) controllerConfigurationOfECUInterface).isMaster() == true) {
          if (masterPresent == false) {
            masterPresent = true;
          } else {
            return true;
          }
        } else {
          slavePresent = true;
        }
      }
    }
    if (masterPresent == false || slavePresent == false) {
      return true;
    }
return false;
  } 
   	
public static boolean checkIfConfiguredNADValueIsDuplicateWithinALINChannel(MChannelCommunication channelCommunication) {
HashSet<Integer> allConfiguredNadValues = new HashSet<>();
    List<MECUInterface> ecuInterfaces = channelCommunication.getEcuInterfaces();
    for (MECUInterface ecuInterface : ecuInterfaces) {
      MAbstractControllerConfiguration controllerConfigurationOfECUInterface = ecuInterface.getControllerConfigurationOfECUInterface();
      if (controllerConfigurationOfECUInterface instanceof MLINControllerConfiguration) {
        int configuredNAD = ((MLINControllerConfiguration) controllerConfigurationOfECUInterface).getConfiguredNAD();
        if(configuredNAD!=0){
        if (!allConfiguredNadValues.contains(configuredNAD)) {
          allConfiguredNadValues.add(configuredNAD);
        }
        else {
          return true;
        }
}
      }
}
return false;
  } 
   	
public static boolean calibrationAccessInOperationForClientServerInterface(MOperationArgument operationArgument) {
Set<MDFObject> allParents_operation = MDFObjectUtil.getAllParents(operationArgument);
    for(MDFObject swPackageOperation :allParents_operation) {
      if(swPackageOperation instanceof MSoftwareTypePackage) {
	  MSoftwareTypePackage swPackage =(MSoftwareTypePackage)swPackageOperation;
	  if((swPackage.getName().equals("BswM Interfaces"))||(swPackage.getName().equals("Network Management"))||(swPackage.getName().equals("NvM Interfaces"))||(swPackage.getName().equals("Operating System Interfaces"))||(swPackage.getName().equals("SomeIP"))){
	if(operationArgument.getCalibrationAccess()!=null){
		return true;
	}
}
else if((swPackage.getName().equals("Cdd 2.0 Interfaces"))||(swPackage.getName().equals("IO Interfaces"))){
if(operationArgument.getCalibrationAccess()!=null){
String calibrationAccessValue = operationArgument.getCalibrationAccess().toString();
if(!calibrationAccessValue.equals("NOT_ACCESSIBLE")){
		return true;
	}
}
else{
return true;
}
}
}
}
return false;
  } 
   	
public static boolean checkTransitionValueOfModeDeclarationGroup(MModeDeclarationGroup modeDeclarationGroup) {
List<MMode> modes = modeDeclarationGroup.getModes();
    List<Integer> list = new ArrayList<>();
    for (MMode mode : modes) {
      int value = mode.getValue();
      if (!list.contains(value)) {
        list.add(value);
      }
    }
    Collections.sort(list);
    int size = list.size();
    int integer = list.get(size - 1);
    if ((modeDeclarationGroup.getOnTransitionValue()) != integer + 1) {
     return true;
    }
		return false;
  } 
   	
public static boolean checkConditionsForNmCoordinator(MCanNmECU canNmECU) {
Collection<MAbstractNmNode> nmNodes = canNmECU.getNmNodes();
    for (MAbstractNmNode nmNode : nmNodes) {
      if (nmNode instanceof MCanNmNode) {
	  String NmCoordinatorRole = nmNode.getNmCoordinatorRole().toString();
        if (NmCoordinatorRole.equals("ACTIVE")) {
          if (!canNmECU.getNmActiveCoordinator() == true) {
return true;
          }
        }
        if (NmCoordinatorRole.equals("PASSIVE")) {
          if (canNmECU.getNmActiveCoordinator() == true) {
            return true;
          }
        }
      }
    }

		return false;
  } 
   	
public static boolean checkServerImplementationPolicyInOperationArgument(MOperationArgument operationArgument) {
Set<MDFObject> allParents_operation = MDFObjectUtil.getAllParents(operationArgument);
    for(MDFObject swPackageOperation :allParents_operation) {
      if(swPackageOperation instanceof MSoftwareTypePackage) {
    MSoftwareTypePackage swPackage =(MSoftwareTypePackage)swPackageOperation;
    if((swPackage.getName().equals("BswM Interfaces"))||(swPackage.getName().equals("Cdd 2.0 Interfaces"))||(swPackage.getName().equals("IO Interfaces"))){
      if (operationArgument.getServerArgumentImplPolicy() != null) {
        if (!operationArgument.getServerArgumentImplPolicy().toString().equals("USE_PARAMETER_TYPE")) {
          return true;
        }
      }
      else {
       return true;
      }
    } else if ((swPackage.getName().equals("Network Management")) || (swPackage.getName().equals("Operating System Interfaces"))
               || (swPackage.getName().equals("SomeIP")) || (swPackage.getName().equals("NvM Interfaces"))) {
      if (operationArgument.getServerArgumentImplPolicy() != null) {
        return true;
      }
    }
      }
    }
    return false;
  } 
   	
public static boolean checkConditionsForNmPassiveModeEnabled(MAbstractNmNode NmNode) {
if (NmNode instanceof MCanNmNode) {
    MCanNmNode node = (MCanNmNode) NmNode;
    double nmMsgCycleOffset = node.getNmMsgCycleOffset();
    boolean isPassiveModeEnabled = node.getNmPassiveModeEnabled();
if(nmMsgCycleOffset == 0.0 && node.getNmMsgCycleOffsetChangedMarker()==true){
if(isPassiveModeEnabled==true){
return true;
}
}
    else if (nmMsgCycleOffset > 0.0 && nmMsgCycleOffset < 65.535) {
	if(isPassiveModeEnabled==true){
return true;
}
}
else if(nmMsgCycleOffset > 65.535){
return true;
}
}
else if(NmNode instanceof MUdpNmNode) {
    MUdpNmNode node = (MUdpNmNode) NmNode;
    double nmMsgCycleOffset = node.getNmMsgCycleOffset();
    boolean isPassiveModeEnabled = node.getNmPassiveModeEnabled();
if(nmMsgCycleOffset == 0.0 && node.getNmMsgCycleOffsetChangedMarker()==true){
if(isPassiveModeEnabled==true){
return true;
}
}
    else if (nmMsgCycleOffset > 0.0 && nmMsgCycleOffset < 65.535) {
	if(isPassiveModeEnabled==true){
return true;
}
}
else if(nmMsgCycleOffset > 65.535){
return true;
}
}
return false;
  } 
   	
public static boolean CheckResumePositionAndRunModeInLINCommunication(MLINCommunication communication) {
Boolean resumePosition_startFromBeginning_present = false;
    Boolean runMode_runContinuous_present = false;
    List<MLINSchedule> linSchedules = communication.getLinSchedules();
    for (MLINSchedule linSchedule : linSchedules) {
      if (resumePosition_startFromBeginning_present == false || runMode_runContinuous_present == false) {
        if (linSchedule.getResumePosition() != null) {
        if (linSchedule.getResumePosition().toString().equals("startFromBeginning")) {
          resumePosition_startFromBeginning_present=true;
        }
      }
      if (linSchedule.getRunMode() != null) {
        if (linSchedule.getRunMode().toString().equals("runContinuous")) {
          runMode_runContinuous_present = true;
        }
      }
      }
    }
    if (!linSchedules.isEmpty()) {
    if (resumePosition_startFromBeginning_present == false || runMode_runContinuous_present == false) {
      return true;
    }
  }
return false;
  } 
   	
public static boolean checkIfModeSwitchPortAndInternalBehaviourBelongsToSameSWC(MPortType port) {
if (port instanceof MSenderPortType) {
      Collection<MModeSwitchPoint> modeSwitchPoints = ((MSenderPortType) port).getModeSwitchPoint();
      if (!modeSwitchPoints.isEmpty()) {
        for (MModeSwitchPoint modeSwitchPoint : modeSwitchPoints) {
          MRunnableEntity runnableEntity = modeSwitchPoint.getRunnableEntity();
          MInternalBehavior internalBehavior = runnableEntity.getInternalBehavior();
          if (internalBehavior.getInternalBehaviorOwner() != port.getPortTypeOwner()) {
            return true;
          }
        }
      }
    } else {
      Collection<MModeAccessPoint> modeAccessPoints = port.getModeAccessPoints();
      if (!modeAccessPoints.isEmpty()) {
        for (MModeAccessPoint modeAccessPoint : modeAccessPoints) {
          MRunnableEntity runnable = modeAccessPoint.getRunnable();
          MInternalBehavior internalBehavior = runnable.getInternalBehavior();
          if (internalBehavior.getInternalBehaviorOwner() != port.getPortTypeOwner()) {
            return true;
          }
        }
      }
    }
	return false;
  } 
   	
public static boolean checkIfTheInterfaceIscommonInterface(MSenderReceiverInterface assignedInterface, MPortType sourcePortType) {
if (!sourcePortType.getName().equals(assignedInterface.getName())) {
        List<MInterfaceAssignment> portAssignments = assignedInterface.getPortAssignments();
        Set<String> portAssignmentNames = new HashSet<>();
        for (MInterfaceAssignment portAssignment : portAssignments) {
          MAbstractInterfaceAssignmentOwner assignedFromPort = portAssignment.getAssignedFromPort();
          if (assignedFromPort instanceof MSenderPortType) {
            portAssignmentNames.add(assignedFromPort.getName());
          }
        }
        if (portAssignmentNames.size()== 1) {
          return true;
        }
      }
return false;
  } 
   	
public static boolean countMismatchBetweenModesAndLinSchedules(MLINCommunication linCommunication, MModeDeclarationGroup modeDeclarationGrp, MChannelCommunication channel) {
String str = modeDeclarationGrp.getName();
int index = str.indexOf("_LIN");
String extracted = "";

if (index != -1) {
    extracted = str.substring(0, index);
	extracted = extracted.replace("_", "");
} else {
      extracted = str;
    }
String channelNameWithoutUnderscores = channel.getName().replace("_", "");
if (channelNameWithoutUnderscores.startsWith(extracted)) {
    List<MMode> modes = modeDeclarationGrp.getModes();
    List<MLINSchedule> linSchedules = linCommunication.getLinSchedules();
    List<MLINSchedule> nonDiagLinSchedules = new ArrayList<>();

    for (MLINSchedule linSchedule : linSchedules) {
        if (!linSchedule.getName().startsWith("Diag_")) {
            nonDiagLinSchedules.add(linSchedule);
        }
    }

    if (modes.size() != nonDiagLinSchedules.size()) {
        return true;
    }
}

return false;
  } 
   	
public static boolean checkConditionsInClusterForNmPassiveModeEnabled(MAbstractNmCluster nmCluster, MAbstractNmNode NmNode) {
if (nmCluster instanceof MCanNmCluster && NmNode instanceof MCanNmNode) {
    MCanNmCluster cluster = (MCanNmCluster) nmCluster;
    List<MAbstractNmNode> nmNodes = cluster.getNmNodes();
    Double nmMsgCycleTime = cluster.getNmMsgCycleTime();
    Double nmNetworkTimeoutTime = cluster.getNmNetworkTimeoutTime();

    if (nmMsgCycleTime > 65.535 || nmNetworkTimeoutTime > 65.535) {
      return true;
    }

    boolean isCycleTimeValid = nmMsgCycleTime > 0.000 && nmMsgCycleTime < 65.535;
    boolean isTimeoutTimeValid = nmNetworkTimeoutTime > 0.000 && nmNetworkTimeoutTime < 65.535;

    if (isCycleTimeValid || isTimeoutTimeValid) {
      boolean hasPassiveModeDisabled = nmNodes.stream().anyMatch(node -> !node.getNmPassiveModeEnabled());

      if (!hasPassiveModeDisabled) {
        return true;
      }
    }
}else if (nmCluster instanceof MUdpNmCluster && NmNode instanceof MUdpNmNode) {
    MUdpNmCluster cluster = (MUdpNmCluster) nmCluster;
	List<MAbstractNmNode> nmNodes = cluster.getNmNodes();
	Double nmMsgCycleTime = cluster.getNmMsgCycleTime();
    Double nmNetworkTimeoutTime = cluster.getNmNetworkTimeoutTime();

    if (nmMsgCycleTime > 65.535 || nmNetworkTimeoutTime > 65.535) {
      return true;
    }

    boolean isCycleTimeValid = nmMsgCycleTime > 0.000 && nmMsgCycleTime < 65.535;
    boolean isTimeoutTimeValid = nmNetworkTimeoutTime > 0.000 && nmNetworkTimeoutTime < 65.535;

    if (isCycleTimeValid || isTimeoutTimeValid) {
      boolean hasPassiveModeDisabled = nmNodes.stream().anyMatch(node -> !node.getNmPassiveModeEnabled());

      if (!hasPassiveModeDisabled) {
        return true;
      }
    }
}
return false;
  } 
   	
public static boolean NameMismatchBetweenNodeAndLINCommunication(MChannelCommunication channel, MModeDeclarationGroup modeDeclarationGrp) {
String str = modeDeclarationGrp.getName();
int index = str.indexOf("_LIN");
String extracted = "";

if (index != -1) {
    extracted = str.substring(0, index);
	extracted = extracted.replace("_", "");
} else {
      extracted = str;
	  return true;
    }
String channelNameWithoutUnderscores = channel.getName().replace("_", "");
if (!channelNameWithoutUnderscores.startsWith(extracted)) {
    return true;
}

return false;
  } 
   	
public static boolean ModeDeclarationHasChannelCommunication(MModeDeclarationGroup modeDeclarationGrp) {
List<MChannelCommunication> allChannelComm = new ArrayList<>();
    List<MModeDeclarationGroupElement> modeDeclarationElements = modeDeclarationGrp.getModeDeclarationElement();
    for (MModeDeclarationGroupElement modeDeclarationElement : modeDeclarationElements) {
      MModeDeclarationGroupElementOwner modeDeclarationGroupElementOwner = modeDeclarationElement.getModeDeclarationGroupElementOwner();
      if (modeDeclarationGroupElementOwner instanceof MModeSwitchInterface) {
        List<MInterfaceAssignment> portAssignments = ((MModeSwitchInterface) modeDeclarationGroupElementOwner).getPortAssignments();
        for (MInterfaceAssignment portAssignment : portAssignments) {
          MAbstractInterfaceAssignmentOwner assignedFromPort = portAssignment.getAssignedFromPort();
          if (assignedFromPort instanceof MPortType) {
            MPortTypeOwner portTypeOwner = ((MPortType) assignedFromPort).getPortTypeOwner();
            if (portTypeOwner instanceof MAbstractAtomicSWComponentType) {
              List<MAtomicSWComponentPrototype> atomicSWComponentPrototypes = ((MAbstractAtomicSWComponentType) portTypeOwner).getAtomicSWComponentPrototypes();
              for (MAtomicSWComponentPrototype atomicSWComponentPrototype : atomicSWComponentPrototypes) {
                List<MAtomicSWComponent> atomicSWComponents = atomicSWComponentPrototype.getAtomicSWComponents();
                for (MAtomicSWComponent atomicSWComponent : atomicSWComponents) {
                  List<MSWComponentMapping> swComponentMappings = atomicSWComponent.getSwComponentMappings();
                  for (MSWComponentMapping swComponentMapping : swComponentMappings) {
                    MHWSWMappedArtefact mappedHWSWArtefact = swComponentMapping.getMappedHWSWArtefact();
                    if (mappedHWSWArtefact instanceof MMicroprocessor) {
                      MAbstractInternalComponentArtefactOwner internalComponentOwner = ((MMicroprocessor) mappedHWSWArtefact).getInternalComponentOwner();
                      if (internalComponentOwner instanceof MECU) {
                        List<MLogicalConnector> eeLogicalConnectors = ((MECU) internalComponentOwner).getEeLogicalConnectors();
                        for (MLogicalConnector eeLogicalConnector : eeLogicalConnectors) {
                          if (eeLogicalConnector instanceof MBusConnector) {
                            MBusConnectorType busConnectorType = ((MBusConnector) eeLogicalConnector).getBusConnectorType();
                            if (busConnectorType instanceof MLINConnectorType) {
                              Collection<MAbstractControllerConfiguration> endPointConfigurations = ((MBusConnector) eeLogicalConnector).getEndPointConfigurations();
                              for (MAbstractControllerConfiguration endPointConfiguration : endPointConfigurations) {
                                if (endPointConfiguration instanceof MLINControllerConfiguration) {
                                  Collection<MECUInterface> configuredEcuInterfaces = ((MLINControllerConfiguration) endPointConfiguration).getConfiguredEcuInterface();
                                for (MECUInterface configuredEcuInterface : configuredEcuInterfaces) {
                                  MAbstractChannelCommunicationContentOwner channelCommunication = configuredEcuInterface.getChannelCommunication();
                                  if(channelCommunication instanceof MChannelCommunication) {
                                    allChannelComm.add((MChannelCommunication) channelCommunication);
                                  }
                                }
                                }
                              }
                            }
                          }
                        }
                      }
                    }

                  }
                }
              }
            }
          }
        }

      }
    }
    if (!allChannelComm.isEmpty()) {
      String str = modeDeclarationGrp.getName();
      int index = str.indexOf("_LIN");
      String extracted = "";

      if (index != -1) {
        extracted = str.substring(0, index);

      }
      else {
        extracted = str.replaceAll("_", "");
      }
      for (MChannelCommunication channelCom : allChannelComm) {
        String name = channelCom.getName();
        name = name.replaceAll("_", "");
        if (name.startsWith(extracted)) {
          return false;
        } else {
          return true;
        }
      }
    }
return false;
  } 
   	
public static boolean checkIfSRInterfaceHasBothSenderAndReceiverPortsAssigned(MSenderReceiverInterface senderReceiverInterface) {
boolean senderPortFlag=false;
boolean receiverPortFlag=false;
  List<MInterfaceAssignment> portAssignments = senderReceiverInterface.getPortAssignments();

  for (MInterfaceAssignment mInterfaceAssignment : portAssignments) {
    MAbstractInterfaceAssignmentOwner assignedFromPort = mInterfaceAssignment.getAssignedFromPort();
    if(assignedFromPort instanceof MSenderPortType) {
     if( !(((MSenderPortType) assignedFromPort).getPortTypeOwner() instanceof MCompositionType)) {
       senderPortFlag=true;
     }
    }
    if(assignedFromPort instanceof MReceiverPortType) {
      if( !(((MReceiverPortType) assignedFromPort).getPortTypeOwner() instanceof MCompositionType)) {
        receiverPortFlag=true;
      }
     }
  }


  return !(senderPortFlag &&receiverPortFlag) ;
  } 
   	
public static boolean checkIfInitialValueOfSignalMatchesWithThatOfDataElement(MDataElement dataElement, MSignal signal) {
MValueSpecification dataElementInitValue = dataElement.getInitValue();
        MValueSpecification signalInitValue = signal.getRawInitValue();
        double factor = 0;
        double offset = 0;
        MComputationMethod usedComputationMethod = signal.getUsedComputationMethod();
        if (usedComputationMethod != null) {
          MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
          if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
            factor = ((MLinearVerbalTableConversion) internalToPhysicalConversion).getFactor();
            offset = ((MLinearVerbalTableConversion) internalToPhysicalConversion).getOffset();
          } else if (internalToPhysicalConversion instanceof MLinearConversion) {
            factor = ((MLinearConversion) internalToPhysicalConversion).getFactor();
            offset = ((MLinearConversion) internalToPhysicalConversion).getOffset();
          }
          if (dataElementInitValue != null && signalInitValue != null) {
            if (dataElementInitValue instanceof MIntegerLiteral && signalInitValue instanceof MIntegerLiteral) {
              MIntegerLiteral dliteral = (MIntegerLiteral) dataElementInitValue;
              MIntegerLiteral sliteral = (MIntegerLiteral) signalInitValue;
              int value = sliteral.getValue();
              int newSignalinitValue = 0;
              newSignalinitValue = (int) ((value * factor) + offset);
              if (dliteral.getValue() != newSignalinitValue) {
                return true;

              }
            } else if (dataElementInitValue instanceof MFloatLiteral && signalInitValue instanceof MFloatLiteral) {
              MFloatLiteral dliteral = (MFloatLiteral) dataElementInitValue;
              MFloatLiteral sliteral = (MFloatLiteral) signalInitValue;
              float value = sliteral.getValue();
              float newSignalinitValue = 0;
              newSignalinitValue = (float) ((value * factor) + offset);
              if (dliteral.getValue() != newSignalinitValue) {
                return true;

              }
            } else if (dataElementInitValue instanceof MBooleanLiteral && signalInitValue instanceof MBooleanLiteral) {
              MBooleanLiteral dliteral = (MBooleanLiteral) dataElementInitValue;
              MBooleanLiteral sliteral = (MBooleanLiteral) signalInitValue;
              if (dliteral.getValue() != sliteral.getValue()) {
               return true;

              }
            } else if (dataElementInitValue instanceof MFloatLiteral && signalInitValue instanceof MIntegerLiteral) {
              MFloatLiteral dliteral = (MFloatLiteral) dataElementInitValue;
              MIntegerLiteral sliteral = (MIntegerLiteral) signalInitValue;
              int value = sliteral.getValue();
              float newSignalinitValue = 0;
              newSignalinitValue = (float) ((value * factor) + offset);
              newSignalinitValue = (float) (Math.floor(newSignalinitValue * 1000) / 1000);
              float truncatedDliteralValue = (float) (Math.floor(dliteral.getValue() * 1000) / 1000);
              if (truncatedDliteralValue != newSignalinitValue) {
                return true;

              }
            } else if (dataElementInitValue instanceof MIntegerLiteral && signalInitValue instanceof MBooleanLiteral) {
              MIntegerLiteral dliteral = (MIntegerLiteral) dataElementInitValue;
              MBooleanLiteral sliteral = (MBooleanLiteral) signalInitValue;
              int updatedSliteralValue = 0;
              boolean value = sliteral.getValue();
              if (value == true) {
                updatedSliteralValue = 1;
              }
              updatedSliteralValue = (int) ((updatedSliteralValue * factor) + offset);
              if (dliteral.getValue() != updatedSliteralValue) {
                return true;

              }
            }
          }
        }
		  return false;
  } 
   	
public static boolean checkIfVariableAccessDataElementOfInterfaceSameAsThatOfPortInterface(MDataTypedInformationUnit infoUnit, MInterface assignedInterface) {
MInterface targetInterface=null;
  if (infoUnit instanceof MDataElement) {
    MDataElement element = (MDataElement) infoUnit;
    targetInterface = element.getSrInterface();
  }
  if (infoUnit instanceof MNvData) {
    MNvData element = (MNvData) infoUnit;
    targetInterface = element.getNvDataInterface();
  }
  if (infoUnit instanceof MOperation) {
    MOperation element = (MOperation) infoUnit;
    targetInterface = element.getCsInterface();
  }


  return targetInterface!=assignedInterface;
  } 
   	
public static boolean checkIfSendingDataAccessIsSameAsThatOfPPortMapped(MInternalBehavior internalBehavior, MClassicAtomicSWComponentType swcType) {
return (swcType.getOwnedPorts().stream().filter(s -> s instanceof MPPortType).count() - swcType.getOwnedPorts().stream().filter(s -> s instanceof MServerPortType).count()) !=

(internalBehavior.getRunnables().stream().flatMap(list -> list.getVariableAccess().stream().filter(v -> v instanceof MVariableWrite)).count()

 + internalBehavior.getRunnables().stream().flatMap(list -> list.getModeSwitchPoints().stream().filter(v -> v instanceof MModeSwitchPoint)).count());
  } 
   	
public static boolean checkIfReceivingDataAccessIsSameAsThatOfRPortMapped(MClassicAtomicSWComponentType swcType, MInternalBehavior internalBehavior) {
return (swcType.getOwnedPorts().stream().filter(s -> s instanceof MRPortType).count()) != (internalBehavior.getRunnables().stream().flatMap(list -> list.getVariableAccess().stream().filter(v -> v instanceof MVariableRead)).count()
    + internalBehavior.getRunnables().stream().flatMap(list -> list.getModeAccessPoints().stream().filter(v -> v instanceof MModeAccessPoint)).count()
    );
  } 
   	
public static boolean checkIfDuplicateAssembliesCreatedForPort(MSWPort swPort) {
Collection<MAssembly> assemblies = swPort.getAssemblies();
  for (MAssembly mAssembly1 : assemblies) {
    List<MAbstractSWPort> connectedPorts = mAssembly1.getConnectedPorts();
    for (MAssembly mAssembly : assemblies) {
      if(mAssembly1!=mAssembly) {
        if(connectedPorts.containsAll(mAssembly.getConnectedPorts())) {
          return true;
        }
      }
    }
  }
  return false;
  } 
   	
public static boolean checkIfInternalPortsIsAssignedWithSignal(MSWPort swPort) {
Collection<MAssembly> assemblies = swPort.getAssemblies();
  for (MAssembly mAssembly : assemblies) {
    List<MAbstractSWPort> connectedPorts = mAssembly.getConnectedPorts();
    for (MAbstractSWPort port : connectedPorts) {
      if (port != swPort && port instanceof MSWPort) {
        MSWPort port2 = (MSWPort) port;
        if (port2.getSwPortPrototype().getPortType() instanceof MSenderReceiverPortType) {

        }
        port2.getAssemblies();
      }

    }
  }
  return false;
  } 
   	
public static boolean checkIfInternalPortIsHavingSystemSignalMapping(MSWPort sourcePort, MMicroprocessor mappedHW) {
List<MAssembly> assembliesList = new ArrayList<>();
    getAllAssemblies(sourcePort, assembliesList);

    List<MSWPort> collect = assembliesList.stream().flatMap(assembly -> assembly.getConnectedPorts().stream().map(MSWPort.class::cast)).collect(Collectors.toList()).stream().filter(port -> port.getSwInstance().getClass().toString().contains("MAtomicSWComponent")).collect(Collectors.toList());
    MAbstractSWInstance swInstance = sourcePort.getSwInstance();
    List<MSWComponentMapping> swComponentMappings = swInstance.getSwComponentMappings();
    MHWSWMappedArtefact sourceHWArtefact = swComponentMappings.get(0).getMappedHWSWArtefact();
    boolean receiverFlag=false;
    if (sourcePort.getSwPortPrototype().getPortType() instanceof MSenderPortType) {
      for (MSWPort mswPort : collect) {
        if (mswPort != sourcePort && mswPort.getSwPortPrototype().getPortType() instanceof MReceiverPortType) {
          receiverFlag=true;
          MAbstractSWInstance tagetSWInstance = mswPort.getSwInstance();
          List<MSWComponentMapping> tagetSwComponentMappings = tagetSWInstance.getSwComponentMappings();
          MHWSWMappedArtefact tagetHWArtefact = tagetSwComponentMappings.get(0).getMappedHWSWArtefact();
          if (sourceHWArtefact != tagetHWArtefact) {
            return false;
          }
        }
      }
      if(!receiverFlag){
        return false;
        }
    }
    boolean senderFlag=false;
    if (sourcePort.getSwPortPrototype().getPortType() instanceof MReceiverPortType) {
      for (MSWPort mswPort : collect) {
        if (mswPort != sourcePort && mswPort.getSwPortPrototype().getPortType() instanceof MSenderPortType) {
          senderFlag=true;
          MAbstractSWInstance tagetSWInstance = mswPort.getSwInstance();
          List<MSWComponentMapping> tagetSwComponentMappings = tagetSWInstance.getSwComponentMappings();
          MHWSWMappedArtefact tagetHWArtefact = tagetSwComponentMappings.get(0).getMappedHWSWArtefact();
          if (sourceHWArtefact != tagetHWArtefact) {
            return false;
          }
        }
      }
      if(!senderFlag){
        return false;
        }
    }
    return true;
  } 
   	
public static List<MAssembly> getAllAssemblies(MSWPort sourceSWPort, List<MAssembly> assembliesList) {

    Collection<MAssembly> assemblies = sourceSWPort.getAssemblies();
    for (MAssembly mAssembly : assemblies) {
    
      if (!assembliesList.contains(mAssembly)) {
        assembliesList.add(mAssembly);
        List<MAbstractSWPort> connectedPorts = mAssembly.getConnectedPorts();
        for (MAbstractSWPort absPort : connectedPorts) {
          if (absPort != sourceSWPort && absPort instanceof MSWPort) {
            getAllAssemblies((MSWPort) absPort, assembliesList);
          }
        }
      }
    }
    return assembliesList;
  } 
   	
public static boolean checkIfCommTimeoutRxIsConnnectedFromSWCofSameECU(MSWPort sourcePort, MMicroprocessor mappedHW) {
List<MAssembly> assembliesList = new ArrayList<>();
    getAllAssemblies(sourcePort, assembliesList);

    List<MSWPort> collect = assembliesList.stream().flatMap(assembly -> assembly.getConnectedPorts().stream().map(MSWPort.class::cast)).collect(Collectors.toList()).stream().filter(port -> port.getSwInstance().getClass().toString().contains("MAtomicSWComponent")).collect(Collectors.toList());
    if (sourcePort.getSwPortPrototype().getPortType() instanceof MReceiverPortType) {
      for (MSWPort mswPort : collect) {
        if (mswPort != sourcePort && mswPort.getSwPortPrototype().getPortType() instanceof MSenderPortType) {
          MAbstractSWInstance tagetSWInstance = mswPort.getSwInstance();
          List<MSWComponentMapping> tagetSwComponentMappings = tagetSWInstance.getSwComponentMappings();
          MHWSWMappedArtefact tagetHWArtefact = tagetSwComponentMappings.get(0).getMappedHWSWArtefact();
          if (mappedHW == tagetHWArtefact) {
            return true;
          }
        }
      }
    }


    return false;
  } 
   	
public static boolean checkIfContainerPduTransmissionIsHavingAllContainedPduTransmissions(MPDUTransmission source, MContainerIPDU containerPdu, MChannelCommunication channel) {
return (source.getContainedPduTransmissions().containsAll(containerPdu.getContainedPDUs().stream().flatMap(pdu -> pdu.getIPDUTransmissions().stream().filter(pduTx -> pduTx.getIPDUTransmissionContainer().equals(channel))).collect(Collectors.toList()))
    && containerPdu.getContainedPDUs().stream().flatMap(pdu -> pdu.getIPDUTransmissions().stream().filter(pduTx -> pduTx.getIPDUTransmissionContainer().equals(channel))).collect(Collectors.toList()).containsAll(source.getContainedPduTransmissions())
    );
  } 
   	
public static boolean checkIfExecuteDespiteDataUnavailabilityIsSetTrueForProfile1DataTransformation(MDataTransformation source, String profileName) {
return source.getTransformerAssignment().stream().filter(transAssign -> (transAssign.getTransformer() instanceof MEndToEndTransformer
    && ((MEndToEndTransformer) transAssign.getTransformer()).getProfileName().toUpperCase().equals(profileName))).findAny().isPresent();
  } 
   	
public static boolean checkTimingOfE2ENonGroupPortsIsValid(MTimingEvent sourceTiming, MPortType sourcePortType, MApplicationSWComponentType swcType, String portName) {
List<MPortType> ownedPorts = swcType.getOwnedPorts();
    for (MPortType mPortType : ownedPorts) {
      if (sourcePortType != mPortType) {
        MSystemSignalGroup mSystemSignalGroup = mPortType.getSwPortPrototypes().get(0).getSwPorts().get(0).getTransmittableSignals().stream().filter(MSystemSignalGroup.class::isInstance).map(MSystemSignalGroup.class::cast).findFirst().get();
        if (mSystemSignalGroup.getSystemSignals().stream().filter(element -> element.getName().equals(portName)).findAny().isPresent()) {
          MSignalIPDU pdu = (MSignalIPDU)mSystemSignalGroup.getSignalGroups().iterator().next().getSignalIPDUAssignments().get(0).getSignalIPDU();


          double cycleTime = pdu.getEventControlledTimings().isEmpty() ? pdu.getCyclicTimings().get(0).getTimePeriod()
                                                                              : pdu.getEventControlledTimings().iterator().next().getRepetitionPeriod();

          if (sourceTiming.getPeriod() * 1000 != cycleTime) {
            return true;
          }
        }
      }
    }
    return false;
  } 
   	
public static boolean checkIfNetworkInputSWCNameIsValid(MApplicationSWComponentType swc) {
if (swc.getName().toUpperCase().contains("ZA1") || swc.getName().toUpperCase().contains("ZB") || swc.getName().toUpperCase().contains("ZC1")) {
      if(!swc.getOwnedPorts().stream().filter(port -> port instanceof MSenderPortType).findAny().isPresent()
      && swc.getOwnedPorts().stream().filter(port -> port instanceof MReceiverPortType).findAny().isPresent()) {
        return (!swc.getName().endsWith("NetworkInputs"));
      }
      if( swc.getOwnedPorts().stream().filter(port -> port instanceof MSenderPortType).findAny().isPresent()
          && !swc.getOwnedPorts().stream().filter(port -> port instanceof MReceiverPortType).findAny().isPresent()) {
        return (!swc.getName().endsWith("NetworkOutputs"));
      }
    }
      return false;
  } 
   	
public static boolean checkIfLiteralsAreAssignedWithValues(MPrimitiveSpecification literal) {
if(literal instanceof MIntegerLiteral) {
  MIntegerLiteral lit = (MIntegerLiteral) literal;
  return lit.getValueDefaultMarker() ;
}
if (literal instanceof MFloatLiteral) {
  MFloatLiteral lit = (MFloatLiteral) literal;
  return lit.getValueDefaultMarker() ;
}
if (literal instanceof MDoubleLiteral) {
  MDoubleLiteral lit = (MDoubleLiteral) literal;
  return lit.getValueDefaultMarker() ;
}
if (literal instanceof MBooleanLiteral) {
  MBooleanLiteral lit = (MBooleanLiteral) literal;
  return lit.getValueDefaultMarker() ;
}
if (literal instanceof MStringLiteral) {
  MStringLiteral lit = (MStringLiteral) literal;
  return lit.getValue()==null || lit.getValueDefaultMarker() ;
}

  return false;
  } 
   	
public static boolean checkIfSWRequiredPortHasValidRPortMapping(MSWPort source, MAbstractSignalMappingTarget signal) {
if (source.getRportTransmissionMappings() == null || source.getRportTransmissionMappings().isEmpty()) {
    return true;
  }

  if (signal instanceof MSystemSignal) {
    MSystemSignal systemSignal = (MSystemSignal) signal;
   if( source.getRportTransmissionMappings().stream().filter(mappings-> systemSignal.getSignals().contains(mappings.getMappedSignalTransmissions().iterator().next().getSignalType())).count()<=0) {
     return true;
   }

  }

return false;
  } 
   	
public static boolean checkIfSWProvidedPortHasValidPPortMapping(MSWPort source, MAbstractSignalMappingTarget signal, MECU ecuInput) {
if (source.getPportTransmissionMappings() == null || source.getPportTransmissionMappings().isEmpty()) {
    return true;
  }

  if (signal instanceof MSystemSignal) {
    Set<MSignalTransmission> eligibleSignalTransmissions=new HashSet<>();
    MSystemSignal systemSignal = (MSystemSignal) signal;
    Collection<MSignal> signals = systemSignal.getSignals();
    for (MSignal mSignal : signals) {
      List<MSignalTransmission> signalTransmissions2 = mSignal.getSignalTransmissions();
      for (MSignalTransmission sigTx : signalTransmissions2) {
        Collection<MECUInterface> sendingECUInterface = sigTx.getSendingECUInterface();
        for (MECUInterface ecuIf : sendingECUInterface) {
          MSignalConnector connector = ecuIf.getConnector();
          if(connector !=null) {
            if (connector.getElectronicComposite() == ecuInput) {
              eligibleSignalTransmissions.add(sigTx);
            }
          }
        }
      }
    }
    Set<MSignalTransmission> portMappedsignalTransmissions = new HashSet<>();
    List<MPPortTransmissionMapping> pportTransmissionMappings = source.getPportTransmissionMappings();
    for (MPPortTransmissionMapping mpPortTransmissionMapping : pportTransmissionMappings) {
      portMappedsignalTransmissions.addAll(mpPortTransmissionMapping.getMappedSignalTransmissions());
    }

    if (!eligibleSignalTransmissions.containsAll(portMappedsignalTransmissions) || !portMappedsignalTransmissions.containsAll(eligibleSignalTransmissions)) {
      return true;
    }


  }

  return false;
  } 
   	
public static boolean checkIfPDUHasFrameAssignment(MIPDU pdu) {
if(!(pdu instanceof MContainerIPDU) && !(pdu instanceof MGeneralPurposeIPDU) && !(pdu instanceof MDcmIPDU)) {
    if(pdu instanceof MSignalIPDU) {
      boolean dynamicPartempty = ((MSignalIPDU) pdu).getDynamicPartAlternatives().isEmpty();
      long nonVlanCount= pdu.getIPDUTransmissions().stream().filter(tx->
      !(((MChannelCommunication)tx.getIPDUTransmissionContainer()).getBusRoutingArtefactOwner() instanceof MVlan)).count();
     long vlanCount= pdu.getIPDUTransmissions().stream().filter(tx->
      ((MChannelCommunication)tx.getIPDUTransmissionContainer()).getBusRoutingArtefactOwner() instanceof MVlan).count();
     if(dynamicPartempty && (nonVlanCount>0 || vlanCount==0)) {
       return true;
     }

    }
  }return false;
  } 
   	
public static boolean checkIfOperationInvokesOfSameTimeoutValue(MRunnableEntity source) {
long count = source.getVariableAccess().stream().filter(MOperationInvoke.class::isInstance).map(MOperationInvoke.class::cast).mapToDouble(op -> op.getTimeout()).distinct().count();
return count>1;
  } 
   	
public static boolean checkIfNameIsValid(MAbstractNameAttributeArtefact  source) {
boolean retVal = false;
		if (isReferrable(source)) {
			if(source.getName()==null){
                        retVal=true;
                     }else
                    if(!source.getName().matches("^[a-zA-Z0-9_]{1,128}$")){
                       retVal=true;
                      }}
		     
		return retVal;
  } 
   	
public static boolean checkIfGroupPortHasSignalPortAsRx(MApplicationSWComponentType swc, MApplicationRecordType adt) {
List<MApplicationRecordElement> applicationRecordElements = adt.getApplicationRecordElements();
    List<MPortType> receiverPorts = swc.getOwnedPorts().stream().filter(MReceiverPortType.class::isInstance).collect(Collectors.toList());
    List<String> portNames = receiverPorts.stream().map(port -> port.getName()).collect(Collectors.toList());
    for (MApplicationRecordElement recordElement : applicationRecordElements) {
   if (!portNames.contains(recordElement.getName()) && !recordElement.getName().toUpperCase().contains("COUNTER") && !recordElement.getName().toUpperCase().contains("DUMMY") && !recordElement.getName().toUpperCase().contains("CHECKSUM")) {
        return true;
      }
    }return false;
  } 
   	
public static boolean checkIfComMappingsAreValid(MSystemSignalGroup systemSignalGroup, MSignal signal) {
List<MSystemSignal> systemSignals = systemSignalGroup.getSystemSignals();
  Set<MSignal> signalSet=new HashSet<>();
  for (MSystemSignal mSystemSignal : systemSignals) {
    Collection<MSignal> signals = mSystemSignal.getSignals();
    signalSet.addAll(signals);
  }

  if(!signalSet.contains(signal)) {
    return true;
  }
  return false;
  } 
   	
public static boolean checkIfArrayTypeMappingCountSameAsNvmPort(MApplicationArrayType applicationArrayType) {
Set<MInternalBehavior> internalBehaviors = new HashSet<>();
  Collection<MApplicationTypedArtefact> applicationTypedArtefacts = applicationArrayType.getApplicationTypedArtefacts();
  for (MApplicationTypedArtefact mApplicationTypedArtefact : applicationTypedArtefacts) {
    if (mApplicationTypedArtefact instanceof MTypedPerInstanceMemory) {
      internalBehaviors.add(((MTypedPerInstanceMemory) mApplicationTypedArtefact).getInternalBehavior());
    }
  }
  return internalBehaviors.size() != applicationArrayType.getApplicationTypeImplementationTypeMappings().size();
  } 
   	
public static boolean checkIfECUInterfacesAreValidBasedOnGatewayAndPortMappings(MSignalTransmission signalTransmission) {
Set<MECUInterface> ecuInterfaces = new HashSet<>();
    Set<MSignalGatewayRoutingEntry> signalGatewayRoutingEntries = new HashSet<>();
    Set<MIPDUGatewayRoutingEntry> pduGatewayRoutingEntries = new HashSet<>();
    Set<MECU> ecusBasedOnECUInterfaces = new HashSet<>();
    Set<MECU> ecusBasedOnGatewayRoutings = new HashSet<>();
    Set<MECU> ecusBasedOnPortMappings = new HashSet<>();
    Collection<MECUInterface> sendingECUInterface = signalTransmission.getSendingECUInterface();
    Collection<MECUInterface> receivingECUInterface = signalTransmission.getReceivingECUInterface();
    List<MSignalGatewayRoutingEntry> routingEntriesIn = signalTransmission.getRoutingEntriesIn();
    Collection<MSignalGatewayRoutingEntry> routingEntriesOut = signalTransmission.getRoutingEntriesOut();
    List<MPPortTransmissionMapping> pportTransmissionMappings = signalTransmission.getPportTransmissionMappings();
    List<MRPortTransmissionMapping> rportTransmissionMappings = signalTransmission.getRportTransmissionMappings();
    Collection<MPDUTransmission> pduTransmissions = signalTransmission.getPduTransmissions();

    ecuInterfaces.addAll(receivingECUInterface);
    ecuInterfaces.addAll(sendingECUInterface);
    signalGatewayRoutingEntries.addAll(routingEntriesOut);
    signalGatewayRoutingEntries.addAll(routingEntriesIn);
    List<MIPDUGatewayRoutingEntry> pduRoutingEntriesIn = null;
    Collection<MIPDUGatewayRoutingEntry> pduRoutingEntriesOut = null;
    //Get ECUs based on PDU Transmission Gateway routing entry
    for (MPDUTransmission mpduTransmission : pduTransmissions) {
      pduRoutingEntriesIn = mpduTransmission.getRoutingEntriesIn();
      pduRoutingEntriesOut = mpduTransmission.getRoutingEntriesOut();
      pduGatewayRoutingEntries.addAll(pduRoutingEntriesIn);
      pduGatewayRoutingEntries.addAll(pduRoutingEntriesOut);
    }
    for (MIPDUGatewayRoutingEntry gatewayRoutingEntry : pduGatewayRoutingEntries) {
      MGateway gateway = gatewayRoutingEntry.getGatewayLookUp();
      MProcessUnit processUnit = gateway.getProcessUnit();
      MECU internalComponentOwner = (MECU) processUnit.getInternalComponentOwner();
      ecusBasedOnGatewayRoutings.add(internalComponentOwner);
    }

    // Get ECUs based on ECU Interfaces
    for (MECUInterface ecuIf : ecuInterfaces) {
      MSignalConnector connector = ecuIf.getConnector();
      if (connector != null) {
        MECU ecu = (MECU) connector.getElectronicComposite();
        ecusBasedOnECUInterfaces.add(ecu);
      }
    }

    // Get ECUs based on Gateway routing entry
    for (MSignalGatewayRoutingEntry gatewayRoutingEntry : signalGatewayRoutingEntries) {
      MGateway gateway = gatewayRoutingEntry.getGatewayLookUp();
      MProcessUnit processUnit = gateway.getProcessUnit();
      MECU internalComponentOwner = (MECU) processUnit.getInternalComponentOwner();
      ecusBasedOnGatewayRoutings.add(internalComponentOwner);
    }

    // Get ECUs based on Port mappings
    for (MRPortTransmissionMapping rPortMapping : rportTransmissionMappings) {
      MSWPort mappedRPort = (MSWPort) rPortMapping.getMappedRPort();
      MAbstractSWInstance swInstance = mappedRPort.getSwInstance();
      List<MSWComponentMapping> swComponentMappings = swInstance.getSwComponentMappings();
      for (MSWComponentMapping swComponentMapping : swComponentMappings) {
        MHWSWMappedArtefact mappedHWSWArtefact = swComponentMapping.getMappedHWSWArtefact();
        if (mappedHWSWArtefact instanceof MProcessUnit) {
          MECU internalComponentOwner = (MECU) ((MProcessUnit) mappedHWSWArtefact).getInternalComponentOwner();
          ecusBasedOnPortMappings.add(internalComponentOwner);
        }
      }
    }

    for (MPPortTransmissionMapping pPortMapping : pportTransmissionMappings) {
      MSWPort mappedRPort = (MSWPort) pPortMapping.getMappedPPort();
      MAbstractSWInstance swInstance = mappedRPort.getSwInstance();
      List<MSWComponentMapping> swComponentMappings = swInstance.getSwComponentMappings();
      for (MSWComponentMapping swComponentMapping : swComponentMappings) {
        MHWSWMappedArtefact mappedHWSWArtefact = swComponentMapping.getMappedHWSWArtefact();
        if (mappedHWSWArtefact instanceof MProcessUnit) {
          MECU internalComponentOwner = (MECU) ((MProcessUnit) mappedHWSWArtefact).getInternalComponentOwner();
          ecusBasedOnPortMappings.add(internalComponentOwner);
        }
      }
    }

    for (MECU sourceECU : ecusBasedOnECUInterfaces) {
      if (!ecusBasedOnGatewayRoutings.contains(sourceECU) && !ecusBasedOnPortMappings.contains(sourceECU)) {
        return true;
      }
    }
    return false;
  } 
   	
public static boolean checkIfECUInterfacesOnPDUTxAreValidBasedOnGatewayAndPortMappings(MPDUTransmission pduTransmission) {
Set<MECUInterface> ecuInterfaces = new HashSet<>();
    Set<MSignalGatewayRoutingEntry> signalGatewayRoutingEntries = new HashSet<>();
    Set<MIPDUGatewayRoutingEntry> pduGatewayRoutingEntries = new HashSet<>();
    Set<MECU> ecusBasedOnECUInterfaces = new HashSet<>();
    Set<MECU> ecusBasedOnGatewayRoutings = new HashSet<>();
    Set<MECU> ecusBasedOnPortMappings = new HashSet<>();
    Collection<MECUInterface> sendingECUInterface = pduTransmission.getSendingECUInterface();
    Collection<MECUInterface> receivingECUInterface = pduTransmission.getReceivingECUInterface();
    List<MIPDUGatewayRoutingEntry> pduRoutingEntriesIn = pduTransmission.getRoutingEntriesIn();
    Collection<MIPDUGatewayRoutingEntry> pduRoutingEntriesOut = pduTransmission.getRoutingEntriesOut();
    List<MSignalTransmission> containedSignalTransmissions = pduTransmission.getContainedSignalTransmissions();
    pduGatewayRoutingEntries.addAll(pduRoutingEntriesIn);
    pduGatewayRoutingEntries.addAll(pduRoutingEntriesOut);
    ecuInterfaces.addAll(receivingECUInterface);
    ecuInterfaces.addAll(sendingECUInterface);
    List<MPPortTransmissionMapping> pportTransmissionMappings = new ArrayList<>();
    List<MRPortTransmissionMapping> rportTransmissionMappings = new ArrayList<>();
    //Get ECUs based on Signal Transmission Gateway routing entry
    for (MSignalTransmission signalTransmission : containedSignalTransmissions) {
      pportTransmissionMappings.addAll(signalTransmission.getPportTransmissionMappings());
      rportTransmissionMappings.addAll(signalTransmission.getRportTransmissionMappings());
      List<MSignalGatewayRoutingEntry> routingEntriesIn = signalTransmission.getRoutingEntriesIn();
      Collection<MSignalGatewayRoutingEntry> routingEntriesOut = signalTransmission.getRoutingEntriesOut();
      signalGatewayRoutingEntries.addAll(routingEntriesOut);
      signalGatewayRoutingEntries.addAll(routingEntriesIn);
    }

    //Get ECUs based on PDU Transmission Gateway routing entry

    for (MIPDUGatewayRoutingEntry gatewayRoutingEntry : pduGatewayRoutingEntries) {
      MGateway gateway = gatewayRoutingEntry.getGatewayLookUp();
      MProcessUnit processUnit = gateway.getProcessUnit();
      MECU internalComponentOwner = (MECU) processUnit.getInternalComponentOwner();
      ecusBasedOnGatewayRoutings.add(internalComponentOwner);
    }

    // Get ECUs based on ECU Interfaces
    for (MECUInterface ecuIf : ecuInterfaces) {
      MSignalConnector connector = ecuIf.getConnector();
      if (connector != null) {
        MECU ecu = (MECU) connector.getElectronicComposite();
        ecusBasedOnECUInterfaces.add(ecu);
      }
    }

    // Get ECUs based on Gateway routing entry
    for (MSignalGatewayRoutingEntry gatewayRoutingEntry : signalGatewayRoutingEntries) {
      MGateway gateway = gatewayRoutingEntry.getGatewayLookUp();
      MProcessUnit processUnit = gateway.getProcessUnit();
      MECU internalComponentOwner = (MECU) processUnit.getInternalComponentOwner();
      ecusBasedOnGatewayRoutings.add(internalComponentOwner);
    }

    // Get ECUs based on Port mappings
    for (MRPortTransmissionMapping rPortMapping : rportTransmissionMappings) {
      MSWPort mappedRPort = (MSWPort) rPortMapping.getMappedRPort();
      MAbstractSWInstance swInstance = mappedRPort.getSwInstance();
      List<MSWComponentMapping> swComponentMappings = swInstance.getSwComponentMappings();
      for (MSWComponentMapping swComponentMapping : swComponentMappings) {
        MHWSWMappedArtefact mappedHWSWArtefact = swComponentMapping.getMappedHWSWArtefact();
        if (mappedHWSWArtefact instanceof MProcessUnit) {
          MECU internalComponentOwner = (MECU) ((MProcessUnit) mappedHWSWArtefact).getInternalComponentOwner();
          ecusBasedOnPortMappings.add(internalComponentOwner);
        }
      }
    }

    for (MPPortTransmissionMapping pPortMapping : pportTransmissionMappings) {
      MSWPort mappedRPort = (MSWPort) pPortMapping.getMappedPPort();
      MAbstractSWInstance swInstance = mappedRPort.getSwInstance();
      List<MSWComponentMapping> swComponentMappings = swInstance.getSwComponentMappings();
      for (MSWComponentMapping swComponentMapping : swComponentMappings) {
        MHWSWMappedArtefact mappedHWSWArtefact = swComponentMapping.getMappedHWSWArtefact();
        if (mappedHWSWArtefact instanceof MProcessUnit) {
          MECU internalComponentOwner = (MECU) ((MProcessUnit) mappedHWSWArtefact).getInternalComponentOwner();
          ecusBasedOnPortMappings.add(internalComponentOwner);
        }
      }
    }

    for (MECU sourceECU : ecusBasedOnECUInterfaces) {
      if (!ecusBasedOnGatewayRoutings.contains(sourceECU) && !ecusBasedOnPortMappings.contains(sourceECU)) {
        return true;
      }
    }
    return false;
  } 
   	
public static boolean checkIfInitialValueOfSignalMatchesWithThatOfDataElementForGroupSignal(MDataElement dataElement, MSignal signal) {
MValueSpecification dataElementInitValue = dataElement.getInitValue();
MValueSpecification dataElementInitValueRecordSpec = dataElement.getInitValue();
        MValueSpecification signalInitValue = signal.getRawInitValue();
        double factor = 0;
        double offset = 0;
        MComputationMethod usedComputationMethod = signal.getUsedComputationMethod();
        if (usedComputationMethod != null) {
          MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
          if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
            factor = ((MLinearVerbalTableConversion) internalToPhysicalConversion).getFactor();
            offset = ((MLinearVerbalTableConversion) internalToPhysicalConversion).getOffset();
          } else if (internalToPhysicalConversion instanceof MLinearConversion) {
            factor = ((MLinearConversion) internalToPhysicalConversion).getFactor();
            offset = ((MLinearConversion) internalToPhysicalConversion).getOffset();
          }
          if(dataElementInitValueRecordSpec instanceof MRecordSpecification){
            MRecordSpecification dmrs = (MRecordSpecification) dataElementInitValueRecordSpec;
       Optional<MValueSpecification> isExist = dmrs.getRecordElements().stream().filter(a -> a.getName().equals(signal.getName())).findAny();
       if(isExist.isPresent()) {
         MValueSpecification dmv = isExist.get();
       dataElementInitValue=dmv;
       }
           }
          if (dataElementInitValue != null && signalInitValue != null) {
            if (dataElementInitValue instanceof MIntegerLiteral && signalInitValue instanceof MIntegerLiteral) {
              MIntegerLiteral dliteral = (MIntegerLiteral) dataElementInitValue;
              MIntegerLiteral sliteral = (MIntegerLiteral) signalInitValue;
              int value = sliteral.getValue();
              int newSignalinitValue = 0;
              newSignalinitValue = (int) ((value * factor) + offset);
              if (dliteral.getValue() != newSignalinitValue) {
                return true;

              }
            } else if (dataElementInitValue instanceof MFloatLiteral && signalInitValue instanceof MFloatLiteral) {
              MFloatLiteral dliteral = (MFloatLiteral) dataElementInitValue;
              MFloatLiteral sliteral = (MFloatLiteral) signalInitValue;
              float value = sliteral.getValue();
              float newSignalinitValue = 0;
              newSignalinitValue = (float) ((value * factor) + offset);
              if (dliteral.getValue() != newSignalinitValue) {
                return true;

              }
            } else if (dataElementInitValue instanceof MBooleanLiteral && signalInitValue instanceof MBooleanLiteral) {
              MBooleanLiteral dliteral = (MBooleanLiteral) dataElementInitValue;
              MBooleanLiteral sliteral = (MBooleanLiteral) signalInitValue;
              if (dliteral.getValue() != sliteral.getValue()) {
               return true;

              }
            } else if (dataElementInitValue instanceof MFloatLiteral && signalInitValue instanceof MIntegerLiteral) {
              MFloatLiteral dliteral = (MFloatLiteral) dataElementInitValue;
              MIntegerLiteral sliteral = (MIntegerLiteral) signalInitValue;
              int value = sliteral.getValue();
              float newSignalinitValue = 0;
              newSignalinitValue = (float) ((value * factor) + offset);
              newSignalinitValue = (float) (Math.floor(newSignalinitValue * 1000) / 1000);
              float truncatedDliteralValue = (float) (Math.floor(dliteral.getValue() * 1000) / 1000);
              if (truncatedDliteralValue != newSignalinitValue) {
                return true;

              }
            } else if (dataElementInitValue instanceof MIntegerLiteral && signalInitValue instanceof MBooleanLiteral) {
              MIntegerLiteral dliteral = (MIntegerLiteral) dataElementInitValue;
              MBooleanLiteral sliteral = (MBooleanLiteral) signalInitValue;
              int updatedSliteralValue = 0;
              boolean value = sliteral.getValue();
              if (value == true) {
                updatedSliteralValue = 1;
              }
              updatedSliteralValue = (int) ((updatedSliteralValue * factor) + offset);
              if (dliteral.getValue() != updatedSliteralValue) {
                return true;

              }
            }
          }
        }
		  return false;
  } 
   	
public static boolean isByteorderOPAQUE(MBaseType basetype) {
MByteOrderKind byteOrder = basetype.getByteOrder();
	  if(byteOrder.equals(MByteOrderKindEnum.OPAQUE))
	  {
		  return true;
	  }
	  return false;
  } 
   	
public static boolean isSignalIPduByteorderOPAQUE(MSignalIPDUAssignment SignalIPDUAssignment) {
MByteOrderKind byteOrder = SignalIPDUAssignment.getByteOrder();
	  if(byteOrder.equals(MByteOrderKindEnum.OPAQUE))
	  {
		  return true;
	  }
	  return false;
  } 
   	
public static boolean isPortApiOn(MReceiverPortType MReceiverPortType) {
MSWPortPrototype mswPortPrototype = MReceiverPortType.getSwPortPrototypes().iterator().next();
		 MSWPort mswPort = mswPortPrototype.getSwPorts().iterator().next();
		 List<MRPortTransmissionMapping> rportTransmissionMappings = mswPort.getRportTransmissionMappings();
		 if(!rportTransmissionMappings.isEmpty())
		 {
			for (MRPortTransmissionMapping mrPortTransmissionMapping : rportTransmissionMappings) {
				Collection<MSignalTransmission> mappedSignalTransmissions = mrPortTransmissionMapping.getMappedSignalTransmissions();
				if(!mappedSignalTransmissions.isEmpty())
				{
					for (MSignalTransmission mSignalTransmission : mappedSignalTransmissions) {
						MAbstractTransmittableSignal signalType = mSignalTransmission.getSignalType();
						if (signalType instanceof MSignalGroup) {
							MSignalGroup signalgrp = (MSignalGroup) signalType;
							if(signalgrp.getTransformationProperties().isEmpty() && MReceiverPortType.getErrorHandling() != null)
							{
								return true;
							}
						}
					}
				}
			}
		 }
		return false;
  } 
   	
public static boolean isCompatibleMapping(MApplicationValueType MApplicationValueType) {
int calmin = 0;
		int calmax = 0;
		MComputationMethod usedComputationMethod = MApplicationValueType.getUsedComputationMethod();
		MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod
				.getInternalToPhysicalConversion();
		if (internalToPhysicalConversion instanceof MLinearConversion) {
			MLinearConversion linear = (MLinearConversion) internalToPhysicalConversion;
			double factor = linear.getFactor();
			double offset = linear.getOffset();
			int min = Integer.parseInt(linear.getMin());
			int max = Integer.parseInt(linear.getMax());
			calmin = (int) ((min - offset) / factor);
			calmax = (int) ((max - offset) / factor);
		} else if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
			MLinearVerbalTableConversion linearverbal = (MLinearVerbalTableConversion) internalToPhysicalConversion;
			double factor = linearverbal.getFactor();
			double offset = linearverbal.getOffset();
			int min = Integer.parseInt(linearverbal.getMin());
			int max = Integer.parseInt(linearverbal.getMax());
			calmin = (int) ((min - offset)/ factor);
			calmax = (int) ((max - offset) / factor);
		} else if (internalToPhysicalConversion instanceof MVerbalTableConversion) {
			MVerbalTableConversion Verbaltable = (MVerbalTableConversion) internalToPhysicalConversion;
			calmin = Integer.parseInt(Verbaltable.getMin());
			calmax = Integer.parseInt(Verbaltable.getMax());
		}
		List<MApplicationTypeImplementationTypeMapping> applicationTypeImplementationTypeMappings = MApplicationValueType
				.getApplicationTypeImplementationTypeMappings();
		if (!applicationTypeImplementationTypeMappings.isEmpty()) {
			for (MApplicationTypeImplementationTypeMapping mApplicationTypeImplementationTypeMapping : applicationTypeImplementationTypeMappings) {
				MImplementationDataType implementationDataType = mApplicationTypeImplementationTypeMapping
						.getImplementationDataType();
				if (implementationDataType instanceof MImplementationValue) {
					MImplementationValue impvalue = (MImplementationValue) implementationDataType;
					MGenericInternalDataConstraint internalConstraint = impvalue.getInternalConstraint();
					int dcmax = Integer.parseInt(internalConstraint.getMax());
					if (calmax > dcmax) {
						return true;
					}
				}
			}
		}
		return false;
  } 
   	
public static boolean IsValidComputationMethod(MComputationMethod CompMethod) {
MAbstractConversionSpecification internalToPhysicalConversion = CompMethod.getInternalToPhysicalConversion();
		if (internalToPhysicalConversion instanceof MLinearConversion) {
			MLinearConversion linear = (MLinearConversion) internalToPhysicalConversion;
			if (linear.getFactor() == 0.0 || linear.getOffsetChangedMarker() == false || linear.getMin() == null
					|| linear.getMax() == null || linear.getMinChangedMarker() == false
					|| linear.getMaxChangedMarker() == false || linear.getFactorChangedMarker() == false) {
				return true;
			}
			else {
				return false;
			}
		} else if (internalToPhysicalConversion instanceof MVerbalTableConversion) {
			MVerbalTableConversion Verbaltable = (MVerbalTableConversion) internalToPhysicalConversion;
			if (Verbaltable.getMin() == null || Verbaltable.getMax() == null
					|| Verbaltable.getMinChangedMarker() == false || Verbaltable.getMaxChangedMarker() == false) {
				return true;
			} else {
				return false;
			}
		} else if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
			MLinearVerbalTableConversion scalelinear = (MLinearVerbalTableConversion) internalToPhysicalConversion;
			if (scalelinear.getFactor() == 0.0 || scalelinear.getOffsetChangedMarker() == false || scalelinear.getMin() == null
					|| scalelinear.getMax() == null || scalelinear.getMinChangedMarker() == false
					|| scalelinear.getMaxChangedMarker() == false || scalelinear.getFactorChangedMarker() == false) {
				return true;
			} else {
				return false;
			}
		}
		MAbstractConversionSpecification physicalToInternalConversion = CompMethod.getPhysicalToInternalConversion();
		 if (physicalToInternalConversion instanceof MLinearVerbalTableConversion) {
				MLinearVerbalTableConversion scalelinear = (MLinearVerbalTableConversion) physicalToInternalConversion;
				if (scalelinear.getFactor() == 0.0 || scalelinear.getOffsetChangedMarker() == false || scalelinear.getMin() == null
						|| scalelinear.getMax() == null || scalelinear.getMinChangedMarker() == false
						|| scalelinear.getMaxChangedMarker() == false || scalelinear.getFactorChangedMarker() == false) {
					return true;
				} else {
					return false;
				}
		}
		return false;
  } 
   	
public static boolean IsSameEcu(MPDUTransmission PDUTx) {
MECUInterface mecuInterface = PDUTx.getSendingECUInterface().iterator().next();
		Collection<MSocketConnectionIpduIdentifier> socketConnectionIdentifier = PDUTx.getSocketConnectionIdentifier();
		if (!socketConnectionIdentifier.isEmpty()) {
			for (MSocketConnectionIpduIdentifier mSocketConnectionIpduIdentifier : socketConnectionIdentifier) {
				MHasPduSocketConnectionIpduIdentifier pduSocketConnectionIpduIdentifier = mSocketConnectionIpduIdentifier
						.getPduSocketConnectionIpduIdentifier();
				if (pduSocketConnectionIpduIdentifier instanceof MSocketConnection) {
					MSocketConnection msocketconnection = (MSocketConnection) pduSocketConnectionIpduIdentifier;
					MSocketConnectionBundle connectionBundles = msocketconnection.getConnectionBundles();
					MSocketAddress mSocketAddress = connectionBundles.getServerPort();
					MEthernetECUInterface ethECUInterface = mSocketAddress.getEthECUInterface();
					if (!ethECUInterface.equals(mecuInterface)) {
						return false;
					}
				}
			}
		}
		return true;
  } 
   	
public static boolean isRunnableWithoutTiming(MRunnableEntity MRunnableEntity) {
List<MRTEEvent> startedByEvent = MRunnableEntity.getStartedByEvent();
		if (!startedByEvent.isEmpty()) {
			for (MRTEEvent mrteEvent : startedByEvent) {
				if (mrteEvent instanceof MTimingEvent) {
					MTimingEvent timing = (MTimingEvent) mrteEvent;
					return true;
				} else if (mrteEvent instanceof MInitEvent) {
					MInitEvent init = (MInitEvent) mrteEvent;
					return true;
				} else if (mrteEvent instanceof MOperationInvokedEvent) {
					MOperationInvokedEvent opt = (MOperationInvokedEvent) mrteEvent;
					return true;
				} else if (mrteEvent instanceof MDataReceivedEvent) {
					MDataReceivedEvent ndre = (MDataReceivedEvent) mrteEvent;
					return true;
				} if (mrteEvent instanceof MDataSendCompletedEvent) {
					MDataSendCompletedEvent ndsce = (MDataSendCompletedEvent) mrteEvent;
					return true;
				}
				else {
					return false;
				}
			}
		}
		return false;
  } 
   	
public static boolean IsValidInitialValueforE2E(MSignal param1) {
int bitLength = param1.getBitLength();
		if (param1.getName().contains("Dummy") && !param1.getSignalGroup().isEmpty()) {
			MValueSpecification rawInitValue = param1.getRawInitValue();
			if (rawInitValue instanceof MIntegerLiteral) {
				MIntegerLiteral integerlit = (MIntegerLiteral) rawInitValue;
				int value = integerlit.getValue();
				int Length = (int) (Math.pow(2, bitLength) - 1);
				if (Length != value) {
					return true;
				}
			}
		}
		return false;
  } 
   	
public static boolean IsCompatible(MApplicationBooleanType Applicationdatatype) {
List<MApplicationTypeImplementationTypeMapping> applicationTypeImplementationTypeMappings = Applicationdatatype
				.getApplicationTypeImplementationTypeMappings();
		if (!applicationTypeImplementationTypeMappings.isEmpty()) {
			for (MApplicationTypeImplementationTypeMapping mApplicationTypeImplementationTypeMapping : applicationTypeImplementationTypeMappings) {
				MImplementationDataType implementationDataType = mApplicationTypeImplementationTypeMapping
						.getImplementationDataType();
				if (implementationDataType instanceof MImplementationValue) {
					MImplementationValue imp = (MImplementationValue) implementationDataType;
					Collection<MBaseType> baseType = imp.getBaseType();
					if (!baseType.isEmpty()) {
						for (MBaseType mBaseType : baseType) {
							if (!mBaseType.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.BOOLEAN)) {
								return true;
							}
						}
					}
				}
			}
		}
		return false;
  } 
   	
public static boolean IsValidGateway(MSignal MSignal) {
Collection<MSignalGroup> signalGroup = MSignal.getSignalGroup();
		if (!signalGroup.isEmpty()) {
			for (MSignalGroup mSignalGroup : signalGroup) {
				List<MSignalTransmission> signalTransmissions = MSignal.getSignalTransmissions();
				List<MSignalTransmission> signalTransmissions2 = mSignalGroup.getSignalTransmissions();
				if (signalTransmissions.size() != signalTransmissions2.size()) {
					return true;
				}
			}
		}
		return false;
  } 
   	
public static boolean IsValidConstraint(MImplementationValue MImplementationValue) {
MGenericInternalDataConstraint internalConstraint = MImplementationValue.getInternalConstraint();
		String max = internalConstraint.getMax();
		Collection<MBaseType> baseType = MImplementationValue.getBaseType();
		for (MBaseType mBaseType : baseType) {
			int bitLength = mBaseType.getBitLength();
			int value1 = (int) (Math.pow(2.0, bitLength) - 1);
			String actuallength = String.valueOf(value1);
			if (!actuallength.equals(max) && bitLength < 32) {
				return true;
			}
		}
		return false;
  } 
   	
public static boolean isRunnablewithrightperiod(MAtomicSWComponentType inputObject) {
double eventtimeperiod = 0.0;
		double pdutimeperiod = 0.0;
		if (inputObject instanceof MApplicationSWComponentType) {
			MApplicationSWComponentType ComponentType = (MApplicationSWComponentType) inputObject;
			List<MPortType> ownedPorts = ComponentType.getOwnedPorts();
			if (!ownedPorts.isEmpty()) {
				MInternalBehavior internalBehavior = ComponentType.getInternalBehavior();
				List<MRTEEvent> events = internalBehavior.getEvents();
				if (!events.isEmpty()) {
					for (MRTEEvent mrteEvent : events) {
						if (mrteEvent instanceof MTimingEvent) {
							MTimingEvent mTimingEvent = (MTimingEvent) mrteEvent;
							double period = mTimingEvent.getPeriod();
							period = period * 1000;
							if (eventtimeperiod < period) {
								eventtimeperiod = period;
							}
						}
					}
				}
				MAtomicSWComponentPrototype ComponentPrototype = ComponentType.getAtomicSWComponentPrototypes()
						.iterator().next();
				MAtomicSWComponent mAtomicSWComponent = ComponentPrototype.getAtomicSWComponents().iterator().next();
				List<MSWPort> ports = mAtomicSWComponent.getPorts();
				if (!ports.isEmpty()) {
					for (MSWPort mswPort : ports) {
						List<MAbstractSignalMappingTarget> transmittableSignals = mswPort.getTransmittableSignals();
						if (!transmittableSignals.isEmpty()) {
							for (MAbstractSignalMappingTarget mAbstractSignalMappingTarget : transmittableSignals) {
								if (mAbstractSignalMappingTarget instanceof MSystemSignal) {
									MSystemSignal mSystemSignal = (MSystemSignal) mAbstractSignalMappingTarget;
									MSignal mSignal = mSystemSignal.getSignals().iterator().next();
									List<MSignalIPDUAssignment> signalIPDUAssignments = mSignal
											.getSignalIPDUAssignments();
									if (!signalIPDUAssignments.isEmpty()) {
										for (MSignalIPDUAssignment mSignalIPDUAssignment : signalIPDUAssignments) {
											MSignalIPDU signalIPDU = (MSignalIPDU) mSignalIPDUAssignment
													.getSignalIPDU();
											List<MCyclicTiming> cyclicTimings = signalIPDU.getCyclicTimings();
											if (!cyclicTimings.isEmpty()) {
												for (MCyclicTiming mCyclicTiming : cyclicTimings) {
													double pduPeriod = mCyclicTiming.getTimePeriod();
													if (pdutimeperiod < pduPeriod) {
														pdutimeperiod = pduPeriod;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			if (eventtimeperiod != pdutimeperiod) {
				return true;
			}
		} else if (inputObject instanceof MSensorActuatorSWComponentType) {
			MSensorActuatorSWComponentType ComponentType = (MSensorActuatorSWComponentType) inputObject;
			List<MPortType> ownedPorts = ComponentType.getOwnedPorts();
			if (!ownedPorts.isEmpty()) {
				MInternalBehavior internalBehavior = ComponentType.getInternalBehavior();
				List<MRTEEvent> events = internalBehavior.getEvents();
				if (!events.isEmpty()) {
					for (MRTEEvent mrteEvent : events) {
						if (mrteEvent instanceof MTimingEvent) {
							MTimingEvent mTimingEvent = (MTimingEvent) mrteEvent;
							double period = mTimingEvent.getPeriod();
							period = period * 1000;
							if (eventtimeperiod < period) {
								eventtimeperiod = period;
							}
						}
					}
				}
				MAtomicSWComponentPrototype ComponentPrototype = ComponentType.getAtomicSWComponentPrototypes()
						.iterator().next();
				MAtomicSWComponent mAtomicSWComponent = ComponentPrototype.getAtomicSWComponents().iterator().next();
				List<MSWPort> ports = mAtomicSWComponent.getPorts();
				if (!ports.isEmpty()) {
					for (MSWPort mswPort : ports) {
						List<MAbstractSignalMappingTarget> transmittableSignals = mswPort.getTransmittableSignals();
						if (!transmittableSignals.isEmpty()) {
							for (MAbstractSignalMappingTarget mAbstractSignalMappingTarget : transmittableSignals) {
								if (mAbstractSignalMappingTarget instanceof MSystemSignal) {
									MSystemSignal mSystemSignal = (MSystemSignal) mAbstractSignalMappingTarget;
									MSignal mSignal = mSystemSignal.getSignals().iterator().next();
									List<MSignalIPDUAssignment> signalIPDUAssignments = mSignal
											.getSignalIPDUAssignments();
									if (!signalIPDUAssignments.isEmpty()) {
										for (MSignalIPDUAssignment mSignalIPDUAssignment : signalIPDUAssignments) {
											MSignalIPDU signalIPDU = (MSignalIPDU) mSignalIPDUAssignment
													.getSignalIPDU();
											List<MCyclicTiming> cyclicTimings = signalIPDU.getCyclicTimings();
											if (!cyclicTimings.isEmpty()) {
												for (MCyclicTiming mCyclicTiming : cyclicTimings) {
													double pduPeriod = mCyclicTiming.getTimePeriod();
													if (pdutimeperiod < pduPeriod) {
														pdutimeperiod = pduPeriod;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			if (eventtimeperiod != pdutimeperiod) {
				return true;
			}
		} else if (inputObject instanceof MComplexDeviceDriverComponentType) {
			MComplexDeviceDriverComponentType ComponentType = (MComplexDeviceDriverComponentType) inputObject;
			List<MPortType> ownedPorts = ComponentType.getOwnedPorts();
			if (!ownedPorts.isEmpty()) {
				MInternalBehavior internalBehavior = ComponentType.getInternalBehavior();
				List<MRTEEvent> events = internalBehavior.getEvents();
				if (!events.isEmpty()) {
					for (MRTEEvent mrteEvent : events) {
						if (mrteEvent instanceof MTimingEvent) {
							MTimingEvent mTimingEvent = (MTimingEvent) mrteEvent;
							double period = mTimingEvent.getPeriod();
							period = period * 1000;
							if (eventtimeperiod < period) {
								eventtimeperiod = period;
							}
						}
					}
				}
				MAtomicSWComponentPrototype ComponentPrototype = ComponentType.getAtomicSWComponentPrototypes()
						.iterator().next();
				MAtomicSWComponent mAtomicSWComponent = ComponentPrototype.getAtomicSWComponents().iterator().next();
				List<MSWPort> ports = mAtomicSWComponent.getPorts();
				if (!ports.isEmpty()) {
					for (MSWPort mswPort : ports) {
						List<MAbstractSignalMappingTarget> transmittableSignals = mswPort.getTransmittableSignals();
						if (!transmittableSignals.isEmpty()) {
							for (MAbstractSignalMappingTarget mAbstractSignalMappingTarget : transmittableSignals) {
								if (mAbstractSignalMappingTarget instanceof MSystemSignal) {
									MSystemSignal mSystemSignal = (MSystemSignal) mAbstractSignalMappingTarget;
									MSignal mSignal = mSystemSignal.getSignals().iterator().next();
									List<MSignalIPDUAssignment> signalIPDUAssignments = mSignal
											.getSignalIPDUAssignments();
									if (!signalIPDUAssignments.isEmpty()) {
										for (MSignalIPDUAssignment mSignalIPDUAssignment : signalIPDUAssignments) {
											MSignalIPDU signalIPDU = (MSignalIPDU) mSignalIPDUAssignment
													.getSignalIPDU();
											List<MCyclicTiming> cyclicTimings = signalIPDU.getCyclicTimings();
											if (!cyclicTimings.isEmpty()) {
												for (MCyclicTiming mCyclicTiming : cyclicTimings) {
													double pduPeriod = mCyclicTiming.getTimePeriod();
													if (pdutimeperiod < pduPeriod) {
														pdutimeperiod = pduPeriod;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			if (eventtimeperiod != pdutimeperiod) {
				return true;
			}
		}
		return false;
  } 
   	
public static boolean isCorrectSize(MSignal signal) {
long Arraysize = 0;
long Arraysizesub = 0;
		int bitLength = 0;
		int length = 0;
		long Totalbaselength = 0;
		long Totalrecbaselength = 0;
		bitLength = signal.getBitLength();
		if (signal.getDataTransformation() != null) {
			MImplementationDataType implementationType = signal.getImplementationType();
			if (implementationType instanceof MImplementationArray) {
				MImplementationArray Array = (MImplementationArray) implementationType;
				Arraysize = Array.getArraySize();
				MImplementationDataType arrayElementDataType = Array.getArrayElementDataType();
				if (arrayElementDataType instanceof MImplementationArray) {
					MImplementationArray Arraysubelement = (MImplementationArray) arrayElementDataType;
					Arraysizesub = Arraysubelement.getArraySize();
					MImplementationDataType arrayElementDataType1 = Arraysubelement.getArrayElementDataType();
					if (arrayElementDataType1 instanceof MImplementationValue) {
						MImplementationValue Arraysubelement1 = (MImplementationValue) arrayElementDataType1;
						Collection<MBaseType> baseType = Arraysubelement1.getBaseType();
						for (MBaseType mBaseType : baseType) {
							length = mBaseType.getBitLength();
						}
						Totalbaselength = length * Arraysizesub;
					}
				} else if (arrayElementDataType instanceof MImplementationValue) {
					MImplementationValue Arraysubelement = (MImplementationValue) arrayElementDataType;
					Collection<MBaseType> baseType = Arraysubelement.getBaseType();
					for (MBaseType mBaseType : baseType) {
						length = mBaseType.getBitLength();
					}
					Totalbaselength = length;
				}
				Totalbaselength = Totalbaselength * Arraysize;
			} else if (implementationType instanceof MImplementationValue) {
				MImplementationValue Value = (MImplementationValue) implementationType;
				Collection<MBaseType> baseType = Value.getBaseType();
				for (MBaseType mBaseType : baseType) {
					length = mBaseType.getBitLength();
				}
				Totalbaselength = length;
			} else if (implementationType instanceof MImplementationRecord) {
				MImplementationRecord Record = (MImplementationRecord) implementationType;
				List<MImplementationRecordElement> implementationRecordElements = Record
						.getImplementationRecordElements();
				for (MImplementationRecordElement mImplementationRecordElement : implementationRecordElements) {
					MImplementationDataType implementationType1 = mImplementationRecordElement.getImplementationType();
					if (implementationType1 instanceof MImplementationArray) {
						MImplementationArray Array = (MImplementationArray) implementationType1;
						Arraysize = Array.getArraySize();
						MImplementationDataType arrayElementDataType = Array.getArrayElementDataType();
						if (arrayElementDataType instanceof MImplementationArray) {
							MImplementationArray Arraysubelement = (MImplementationArray) arrayElementDataType;
							Arraysizesub = Arraysubelement.getArraySize();
							MImplementationDataType arrayElementDataType1 = Arraysubelement.getArrayElementDataType();
							if (arrayElementDataType1 instanceof MImplementationValue) {
								MImplementationValue Arraysubelement1 = (MImplementationValue) arrayElementDataType1;
								Collection<MBaseType> baseType = Arraysubelement1.getBaseType();
								for (MBaseType mBaseType : baseType) {
									length = mBaseType.getBitLength();
								}
								Totalrecbaselength = length * Arraysizesub;
							}
						} else if (arrayElementDataType instanceof MImplementationValue) {
							MImplementationValue Arraysubelement = (MImplementationValue) arrayElementDataType;
							Collection<MBaseType> baseType = Arraysubelement.getBaseType();
							for (MBaseType mBaseType : baseType) {
								length = mBaseType.getBitLength();
							}
							Totalrecbaselength = length;
						}
						Totalrecbaselength = Totalrecbaselength * Arraysize;
					} else if (implementationType1 instanceof MImplementationValue) {
						MImplementationValue Value = (MImplementationValue) implementationType1;
						Collection<MBaseType> baseType = Value.getBaseType();
						for (MBaseType mBaseType : baseType) {
							length = mBaseType.getBitLength();
						}
						Totalrecbaselength = length;
					}
					Totalbaselength = Totalbaselength + Totalrecbaselength;
				}
			}
			if (bitLength != Totalbaselength) {
				return false;
			}
		}
		return true;
  } 
   	
public static boolean isContainerReceived(MContainerIPDU SourceObject) {
ArrayList<MECU> ContainedPduTxeculist = new ArrayList<>();
		ArrayList<MECU> PduTxeculist = new ArrayList<>();
		List<MPDUTransmission> ipduTransmissions = SourceObject.getIPDUTransmissions();
		if (!ipduTransmissions.isEmpty()) {
			for (MPDUTransmission mpduTransmission : ipduTransmissions) {
				Collection<MECUInterface> sendingECUInterface = mpduTransmission.getSendingECUInterface();
				Collection<MECUInterface> receivingECUInterface = mpduTransmission.getReceivingECUInterface();
				if (!receivingECUInterface.isEmpty()) {
					for (MECUInterface mecuInterface : receivingECUInterface) {
					  MSignalConnector connector = mecuInterface.getConnector();
						if (connector instanceof MBusConnector) {
							MBusConnector bus = (MBusConnector) connector;
							MDetailedElectricElectronic electronicComposite = bus.getElectronicComposite();
							if (electronicComposite instanceof MECU) {
								MECU sourceecu = (MECU) electronicComposite;
								if (!PduTxeculist.contains(sourceecu)) {
									PduTxeculist.add(sourceecu);
								}
							}
						}
					}
				}
				if (!sendingECUInterface.isEmpty()) {
					for (MECUInterface mecuInterface : sendingECUInterface) {
					  MSignalConnector connector = mecuInterface.getConnector();
						if (connector instanceof MBusConnector) {
							MBusConnector bus = (MBusConnector) connector;
							MDetailedElectricElectronic electronicComposite = bus.getElectronicComposite();
							if (electronicComposite instanceof MECU) {
								MECU sourceecu = (MECU) electronicComposite;
								if (!PduTxeculist.contains(sourceecu)) {
									PduTxeculist.add(sourceecu);
								}
							}
						}
					}
				}
			}
		}
		Collection<MPDUTransmission> containedPDUTransmissions = SourceObject.getContainedPDUTransmissions();
		if (!containedPDUTransmissions.isEmpty()) {
			for (MPDUTransmission mpduTransmission : containedPDUTransmissions) {
				Collection<MECUInterface> sendingECUInterface = mpduTransmission.getSendingECUInterface();
				Collection<MECUInterface> receivingECUInterface = mpduTransmission.getReceivingECUInterface();
				if (!receivingECUInterface.isEmpty()) {
					for (MECUInterface mecuInterface : receivingECUInterface) {
					  MSignalConnector connector = mecuInterface.getConnector();
						if (connector instanceof MBusConnector) {
							MBusConnector bus = (MBusConnector) connector;
							MDetailedElectricElectronic electronicComposite = bus.getElectronicComposite();
							if (electronicComposite instanceof MECU) {
								MECU sourceecu = (MECU) electronicComposite;
								if (!ContainedPduTxeculist.contains(sourceecu)) {
									ContainedPduTxeculist.add(sourceecu);
									}
							}
						}
					}
				}
				if (!sendingECUInterface.isEmpty()) {
					for (MECUInterface mecuInterface : sendingECUInterface) {
					  MSignalConnector connector = mecuInterface.getConnector();
						if (connector instanceof MBusConnector) {
							MBusConnector bus = (MBusConnector) connector;
							MDetailedElectricElectronic electronicComposite = bus.getElectronicComposite();
							if (electronicComposite instanceof MECU) {
								MECU sourceecu = (MECU) electronicComposite;
								if (!ContainedPduTxeculist.contains(sourceecu)) {
									ContainedPduTxeculist.add(sourceecu);
								}
							}
						}
					}
				}

			}
		}
		for (MECU ecu : ContainedPduTxeculist) {
			if (!PduTxeculist.contains(ecu)) {
				return true;
			}
		}
		ContainedPduTxeculist.clear();
		PduTxeculist.clear();
		return false;
  } 
   	
public static boolean isConnetedToSameComposition(MSWPort senderport) {
MSWPortPrototype swPortPrototype = senderport.getSwPortPrototype();
		MAbstractPortType portType = swPortPrototype.getPortType();
		if (portType instanceof MSenderPortType) {
			MSenderPortType msenderport = (MSenderPortType) portType;
			Collection<MAssembly> assemblies = senderport.getAssemblies();
			if (!assemblies.isEmpty()) {
				for (MAssembly mAssembly : assemblies) {
					List<MAbstractSWPort> connectedPorts = mAssembly.getConnectedPorts();
					if (!connectedPorts.isEmpty()) {
						for (MAbstractSWPort mAbstractSWPort : connectedPorts) {
							if (mAbstractSWPort instanceof MSWPort) {
								MSWPort delegation = (MSWPort) mAbstractSWPort;
								MSWPortPrototype swPortPrototype1 = delegation.getSwPortPrototype();
								MAbstractPortType portType1 = swPortPrototype1.getPortType();
								if (portType1 instanceof MSenderDelegationPortType) {
									MSenderDelegationPortType msenderdelegation = (MSenderDelegationPortType) portType1;
									Collection<MAssembly> assemblies2 = delegation.getAssemblies();
									if (!assemblies2.isEmpty()) {
										for (MAssembly mAssembly1 : assemblies2) {
											List<MAbstractSWPort> connectedPorts1 = mAssembly1.getConnectedPorts();
											if (!connectedPorts1.isEmpty()) {
												for (MAbstractSWPort mAbstractSWPort1 : connectedPorts1) {
													if (mAbstractSWPort1 instanceof MSWPort) {
														MSWPort delegation1 = (MSWPort) mAbstractSWPort1;
														MSWPortPrototype swPortPrototype11 = delegation1
																.getSwPortPrototype();
														MAbstractPortType portType11 = swPortPrototype11.getPortType();
														if (portType11 instanceof MReceiverDelegationPortType) {
															MReceiverDelegationPortType mreceiverdelegation = (MReceiverDelegationPortType) portType11;
															Collection<MAssembly> assemblies21 = delegation1
																	.getAssemblies();
															if (!assemblies21.isEmpty()) {
																for (MAssembly mAssembly11 : assemblies21) {
																	List<MAbstractSWPort> connectedPorts11 = mAssembly11
																			.getConnectedPorts();
																	if (!connectedPorts11.isEmpty()) {
																		for (MAbstractSWPort mAbstractSWPort11 : connectedPorts11) {
																			if (mAbstractSWPort11 instanceof MSWPort) {
																				MSWPort receiverport = (MSWPort) mAbstractSWPort11;
																				MSWPortPrototype swPortPrototype111 = receiverport
																						.getSwPortPrototype();
																				MAbstractPortType portType111 = swPortPrototype111
																						.getPortType();
																				if (portType111 instanceof MReceiverPortType) {
																					MReceiverPortType mreceiverport = (MReceiverPortType) portType111;
																					MAbstractSWInstance swInstance = receiverport
																							.getSwInstance();
																					MAbstractSWInstance swInstance2 = senderport
																							.getSwInstance();
																					if (swInstance2 instanceof MAtomicSWComponent
																							&& swInstance instanceof MAtomicSWComponent) {
																						MAtomicSWComponent recSwc = (MAtomicSWComponent) swInstance2;
																						MAtomicSWComponent senSwc = (MAtomicSWComponent) swInstance;
																						if (recSwc
																								.getSwComponentContainer()
																								.equals(senSwc
																										.getSwComponentContainer())) {
																							return true;
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return false;
  } 
   	
public static boolean isContainersizevalid(MContainerIPDU container) {
int headerLength = 0;
    int containedPDUtotallength = 0;

    Collection<MPDU> containedPDUs = container.getContainedPDUs();
    int containerPDULength = container.getBitLength();
    if (container.getHeaderType() != null && container.getHeaderType().equals(MContainerIPDUHeaderTypeEnumEnum.LONG_HEADER)) {
      headerLength = 64;
    }
    for (MPDU mpdu : containedPDUs) {
      if (mpdu instanceof MSignalIPDU) {
        MSignalIPDU signalpdu = (MSignalIPDU) mpdu;
        containedPDUtotallength = containedPDUtotallength + signalpdu.getBitLength() + headerLength;
      }
    }
    if (containedPDUtotallength > containerPDULength) {
      return true;
    }

    return false;
  } 
   	
public static boolean ImpVsBaseType(MImplementationValue inputArtefact) {
MGenericInternalDataConstraint internalConstraint = inputArtefact.getInternalConstraint();
		Collection<MBaseType> baseTypelist = inputArtefact.getBaseType();
		if (!baseTypelist.isEmpty()) {
			for (MBaseType mBaseType : baseTypelist) {
				int bitLength = mBaseType.getBitLength();
				int max = (int) Math.pow(2, bitLength) - 1;
				int constraintMax = Integer.parseInt(internalConstraint.getMax());
				if (constraintMax != max) {
					return true;
				}
			}
		}
		return false;
  } 
   	
public static boolean isPDUEcuExistInSignalGrpSignaltx(MSignalTransmission param2, MPDUTransmission param1) {
Collection<MECUInterface> sigReceivingEcuList = param2.getReceivingECUInterface();
Collection<MECUInterface> pduReceivingEcuList = param1.getReceivingECUInterface();
  for (MECUInterface ecu : pduReceivingEcuList) {
    Optional<MECUInterface> exist = sigReceivingEcuList.stream().filter(a -> a.getName().equals(ecu.getName())).findAny();
      if(!exist.isPresent()) {
        return true;
      }
    }

return false;
  } 
   	
public static boolean isPDUTmsReceivedByECU(MSignalTransmission param2, MPDUTransmission param1) {
Collection<MECUInterface> sigReceivingEcuList = param2.getReceivingECUInterface();
Collection<MECUInterface> pduReceivingEcuList = param1.getReceivingECUInterface();

  for(MECUInterface ecu :sigReceivingEcuList) {
    boolean exist = pduReceivingEcuList.stream().anyMatch(a->a.getName().equals(ecu.getName()));
    if(!exist) {
      return true;
    }
  }
return false;
  } 
   	
public static boolean isFrameTrmsReceived(MFrameTransmission param2, MPDUTransmission param1) {
Collection<MECUInterface> pduReceivingEcuList = param1.getReceivingECUInterface();
  Collection<MECUInterface> frameReceivingEcuList = param2.getReceivingECUInterface();

  for (MECUInterface ecu : pduReceivingEcuList) {
    boolean exist = frameReceivingEcuList.stream().anyMatch(a -> a.getName().equals(ecu.getName()));
    if (!exist) {
      return true;
    }
  }
return false;
  } 
   	
public static boolean isSignalReceived(MSignal SourceObject) {
ArrayList<MECU> Porteculist = new ArrayList<>();
		ArrayList<MECU> SigTxeculist = new ArrayList<>();
		Collection<MAbstractPort> portInstances = SourceObject.getPortInstances();
		if (!portInstances.isEmpty()) {
			for (MAbstractPort mAbstractPort : portInstances) {
				if (mAbstractPort instanceof MSWPort) {
					MSWPort mswport = (MSWPort) mAbstractPort;
					MAbstractSWInstance swInstance = mswport.getSwInstance();
					if (swInstance instanceof MAtomicSWComponent) {
						MAtomicSWComponent matomicswc = (MAtomicSWComponent) swInstance;
						List<MSWComponentMapping> swComponentMappings = matomicswc.getSwComponentMappings();
						if (!swComponentMappings.isEmpty()) {
							for (MSWComponentMapping mswComponentMapping : swComponentMappings) {
								MHWSWMappedArtefact mappedHWSWArtefact = mswComponentMapping.getMappedHWSWArtefact();
								if (mappedHWSWArtefact instanceof MMicroprocessor) {
								  MMicroprocessor mmicro = (MMicroprocessor) mappedHWSWArtefact;
									MAbstractInternalComponentArtefactOwner internalComponentOwner = mmicro
											.getInternalComponentOwner();
									if (internalComponentOwner instanceof MECU) {
										MECU ecu = (MECU) internalComponentOwner;
										if (!Porteculist.contains(ecu)) {
											Porteculist.add(ecu);
										}
										List<MRPortTransmissionMapping> rportTransmissionMappings = mswport
												.getRportTransmissionMappings();
										if (!rportTransmissionMappings.isEmpty()) {
											for (MRPortTransmissionMapping mrPortTransmissionMapping : rportTransmissionMappings) {
												Collection<MSignalTransmission> mappedSignalTransmissions = mrPortTransmissionMapping
														.getMappedSignalTransmissions();
												if (!mappedSignalTransmissions.isEmpty()) {
													for (MSignalTransmission mSignalTransmission : mappedSignalTransmissions) {
														Collection<MECUInterface> receivingECUInterface = mSignalTransmission
																.getReceivingECUInterface();
														if (!receivingECUInterface.isEmpty()) {
															for (MECUInterface mecuInterface : receivingECUInterface) {
                                MSignalConnector connector = mecuInterface
																		.getConnector();
																if (connector instanceof MBusConnector) {
																	MBusConnector bus = (MBusConnector) connector;
																	MDetailedElectricElectronic electronicComposite = bus
																			.getElectronicComposite();
																	if (electronicComposite instanceof MECU) {
																		MECU sourceecu = (MECU) electronicComposite;
																		if (sourceecu.equals(ecu)) {
																			if (!SigTxeculist.contains(ecu)) {
																				SigTxeculist.add(ecu);
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
										List<MPPortTransmissionMapping> pportTransmissionMappings = mswport
												.getPportTransmissionMappings();
										if (!pportTransmissionMappings.isEmpty()) {
											for (MPPortTransmissionMapping mpPortTransmissionMapping : pportTransmissionMappings) {
												Collection<MSignalTransmission> mappedSignalTransmissions = mpPortTransmissionMapping
														.getMappedSignalTransmissions();
												if (!mappedSignalTransmissions.isEmpty()) {
													for (MSignalTransmission mSignalTransmission : mappedSignalTransmissions) {
														Collection<MECUInterface> sendingECUInterface = mSignalTransmission
																.getSendingECUInterface();
														if (!sendingECUInterface.isEmpty()) {
															for (MECUInterface mecuInterface : sendingECUInterface) {
															  MSignalConnector connector = mecuInterface
																		.getConnector();
																if (connector instanceof MBusConnector) {
																	MBusConnector bus = (MBusConnector) connector;
																	MDetailedElectricElectronic electronicComposite = bus
																			.getElectronicComposite();
																	if (electronicComposite instanceof MECU) {
																		MECU sourceecu = (MECU) electronicComposite;
																		if (sourceecu.equals(ecu)) {
																			if (!SigTxeculist.contains(ecu)) {
																				SigTxeculist.add(ecu);
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		for (MECU ecu : Porteculist) {
			if (!SigTxeculist.contains(ecu)) {
				return true;
			}
		}
		Porteculist.clear();
		SigTxeculist.clear();
		return false;
  } 
   	
public static boolean isReferrable(MAbstractNameAttributeArtefact source) {
//List for all classed, that are referrable in AUTOSAR
	  if ( (!source.getClass().toString().contains("BoundaryIntegration") && !source.getClass().toString().contains("CoreIntegration"))&& (MECUInterface.class.isInstance(source) || MAbstractTransmittableSignal.class.isInstance(source)
        || MCommunicationArtefact.class.isInstance(source) || MPDUFrameAssignment.class.isInstance(source)
        || MSignalIPDUAssignment.class.isInstance(source) || MAbstractTiming.class.isInstance(source) || MFrameTransmission.class.isInstance(source)
        || MPDUTransmission.class.isInstance(source) || MSignalTransmission.class.isInstance(source)
        || MFrameGatewayRoutingEntry.class.isInstance(source) || MSignalGatewayRoutingEntry.class.isInstance(source)
        || MLINSchedule.class.isInstance(source) || MBusConnectorType.class.isInstance(source) || MBusType.class.isInstance(source)
        || MElectronicComposite.class.isInstance(source) || MProcessUnit.class.isInstance(source) || MBusSystem.class.isInstance(source)
        || MCluster.class.isInstance(source) || MInterface.class.isInstance(source) || MDataType.class.isInstance(source)
        || MDataTypeUnit.class.isInstance(source) || MAbstractSWType.class.isInstance(source) || MAbstractPortType.class.isInstance(source)
        || MAbstractSWPrototypeArtefact.class.isInstance(source) || MInternalBehavior.class.isInstance(source)
        || MRunnableEntity.class.isInstance(source) || MVariableAccess.class.isInstance(source) || MModeSwitchPoint.class.isInstance(source)
        || MRTEEvent.class.isInstance(source) || MExclusiveArea.class.isInstance(source) || MPerInstanceMemory.class.isInstance(source)
        || MServiceNeeds.class.isInstance(source) || MServiceDependency.class.isInstance(source) || MPortGroupType.class.isInstance(source)
        || MInformationUnit.class.isInstance(source) || MComputationMethod.class.isInstance(source)
        || MApplicationRecordElement.class.isInstance(source) || MImplementationRecordElement.class.isInstance(source)
        || MAddressingMethod.class.isInstance(source) || MUdpNmECU.class.isInstance(source) || MUdpNmNode.class.isInstance(source)
        || MCanNmNode.class.isInstance(source) || MCanNmECU.class.isInstance(source) || MCanNmCluster.class.isInstance(source)
        || MCanTpChannel.class.isInstance(source) || MCanTpConnection.class.isInstance(source) || MCanTpEcu.class.isInstance(source)
        || MCanTpNode.class.isInstance(source) || MLinearVerbalTableConversion.class.isInstance(source) || MLinearConversion.class.isInstance(source)
        || MVerbalTableConversion.class.isInstance(source) || MImplementationArrayIndex.class.isInstance(source)
        || MIntegerLiteral.class.isInstance(source) || MDataTypeUnit.class.isInstance(source) || MTransformerConfiguration.class.isInstance(source)
        || MDataTransformation.class.isInstance(source) || MTransformerAssignment.class.isInstance(source)
        || MEndToEndTransformer.class.isInstance(source) || MGenericTransformer.class.isInstance(source)
        || MSomeIpTransformer.class.isInstance(source) || MCANCommunication.class.isInstance(source)
        || MSignalReceiverAttribute.class.isInstance(source) || MCANIdentifierEntry.class.isInstance(source)
        || MMappingElement.class.isInstance(source) || MAbstractLayerMappings.class.isInstance(source)
)
			)
	  {
			return true;
		}
		else {
			return false;
		}
  } 
   	
public static boolean isValidName(MAbstractNameAttributeArtefact source) {
boolean retVal = false;
		if (isReferrable(source)) {
			if (source.getName() == null) {
				retVal = true;
			} else if (!source.getName().matches("^[a-zA-Z0-9_]{1,128}$")) {
				retVal = true;
			}
		}
		return retVal;
  } 
   	
public static boolean isLINMaster(MBusConnector busConnector) {
Collection<MAbstractControllerConfiguration> portConfigurations = busConnector.getEndPointConfigurations();

	  if (portConfigurations != null) {
		  for (MAbstractControllerConfiguration portConfiguration : portConfigurations) {
			  if (portConfiguration instanceof MLINControllerConfiguration) {
				if (((MLINControllerConfiguration)portConfiguration).isMaster()) {
					  return true;
				  }
			}
		  }
	  }
	  return false;
  } 
   	
public static boolean isLINSlave(MBusConnector busConnector) {
Collection<MAbstractControllerConfiguration> portConfigurations = busConnector.getEndPointConfigurations();

	  if (portConfigurations != null) {
		  for (MAbstractControllerConfiguration portConfiguration : portConfigurations) {
			  if (portConfiguration instanceof MLINControllerConfiguration) {
				if (!((MLINControllerConfiguration)portConfiguration).isMaster()) {
					  return true;
				  }
			}
		  }
	  }
	  return false;
  } 
   	
public static boolean hasRportMappingForRecInterfaces(aquintos.mm.eea.componentslayer.signaltransmission.MSignalTransmission signalTransmission) {
Collection<MECUInterface> receivingInterfaces = signalTransmission.getReceivingECUInterface();
	  if (receivingInterfaces == null || receivingInterfaces.isEmpty())
	 {
		return true; // we can't do anything unless we know where this is going.
	}
	  boolean found;
	  for (MECUInterface receivingInterface : receivingInterfaces) { // all receiving interfaces should
		  found = false;
		  List<MRPortTransmissionMapping> rportMappings = signalTransmission.getRportTransmissionMappings();
		  if (rportMappings == null || rportMappings.isEmpty())
		 {
			return false; // if we are received, we should have a mapping
		}

		  for (MRPortTransmissionMapping rportMapping : rportMappings) {
			  MAbstractRPortTxMappableArtefact port = rportMapping.getMappedRPort();
			  if (port == null || !(port instanceof MSWPort)) {
				continue;
			}
			  MAbstractSWInstance component = ((MSWPort) port).getSwInstance();
			  if (component == null) {
				continue;
			}
			  List<MSWComponentMapping> hwmappings = component.getSwComponentMappings();
			  if (hwmappings == null) {
				continue;
			}
			  for (MSWComponentMapping hwMapping : hwmappings) {
				  MHWSWMappedArtefact processor = hwMapping.getMappedHWSWArtefact();
				  if (processor == null || ! (processor instanceof MInternalComponentArtefact)) {
					continue;
				}
				  MAbstractInternalComponentArtefactOwner parent = ((MInternalComponentArtefact)processor).getInternalComponentOwner();
				  if (parent == null || !(parent instanceof MDetailedElectricElectronic)) {
					continue;
				}
				  List<MLogicalConnector> logicalConnectors = ((MDetailedElectricElectronic)parent).getEeLogicalConnectors();
				  if (logicalConnectors == null) {
					continue;
				}
				  for (MLogicalConnector logicalConnector : logicalConnectors) {
					  if (! (logicalConnector instanceof MBusConnector)) {
						continue;
					}
					  List<MECUInterface> interfaces = ((MBusConnector) logicalConnector).getEcuInterfaces();
					  if (interfaces == null) {
						continue;
					}
					  if (interfaces.contains(receivingInterface)) {
						  found = true;
						  break;
					  }
				  }
			  }
		  }
		  if (! found) {
			return false;
		}
	  }
	  return true;
  } 
   	
public static boolean hasSportMappingForSendInterfaces(aquintos.mm.eea.componentslayer.signaltransmission.MSignalTransmission signalTransmission) {
Collection<MECUInterface> sendingInterfaces = signalTransmission.getSendingECUInterface();
	  if (sendingInterfaces == null || sendingInterfaces.isEmpty())
	 {
		return true; // we can't do anything unless we know where this is going.
	}
	  boolean found;
	  for (MECUInterface sendingInterface : sendingInterfaces) { // all receiving interfaces should
		  found = false;
		  List<MPPortTransmissionMapping> pportMappings = signalTransmission.getPportTransmissionMappings();
		  if (pportMappings == null || pportMappings.isEmpty())
		 {
			return false; // if we are received, we should have a mapping
		}

		  for (MPPortTransmissionMapping pportMapping : pportMappings) {
			  MAbstractPPortTxMappableArtefact port = pportMapping.getMappedPPort();
			  if (port == null || !(port instanceof MSWPort)) {
				continue;
			}
			  MAbstractSWInstance component = ((MSWPort) port).getSwInstance();
			  if (component == null) {
				continue;
			}
			  List<MSWComponentMapping> hwmappings = component.getSwComponentMappings();
			  if (hwmappings == null) {
				continue;
			}
			  for (MSWComponentMapping hwMapping : hwmappings) {
				  MHWSWMappedArtefact processor = hwMapping.getMappedHWSWArtefact();
				  if (processor == null || ! (processor instanceof MInternalComponentArtefact)) {
					continue;
				}
				  MAbstractInternalComponentArtefactOwner parent = ((MInternalComponentArtefact)processor).getInternalComponentOwner();
				  if (parent == null || !(parent instanceof MDetailedElectricElectronic)) {
					continue;
				}
				  List<MLogicalConnector> logicalConnectors = ((MDetailedElectricElectronic)parent).getEeLogicalConnectors();
				  if (logicalConnectors == null) {
					continue;
				}
				  for (MLogicalConnector logicalConnector : logicalConnectors) {
					  if (! (logicalConnector instanceof MBusConnector)) {
						continue;
					}
					  List<MECUInterface> interfaces = ((MBusConnector) logicalConnector).getEcuInterfaces();
					  if (interfaces == null) {
						continue;
					}
						if (interfaces.contains(sendingInterface)) {
						  found = true;
						  break;
					  }
				  }
			  }
		  }
		  if (! found) {
			return false;
		}
	  }
	  return true;
  } 
   	
public static boolean hasRecInterfaceForRportMapping(aquintos.mm.eea.componentslayer.signaltransmission.MSignalTransmission signalTransmission) {
Collection<MECUInterface> receivingInterfaces = signalTransmission.getReceivingECUInterface();

	  boolean found;
	  List<MRPortTransmissionMapping> rportMappings = signalTransmission.getRportTransmissionMappings();
	  if (rportMappings == null || rportMappings.isEmpty())
	  {
		  return true; // nothing to check
	  }

	  for (MRPortTransmissionMapping rportMapping : rportMappings) {
		  found = false;
		  MAbstractRPortTxMappableArtefact port = rportMapping.getMappedRPort();
		  if (port == null || !(port instanceof MSWPort)) {
			  continue;
		  }
		  MAbstractSWInstance component = ((MSWPort) port).getSwInstance();
		  if (component == null) {
			  continue;
		  }
		  List<MSWComponentMapping> hwmappings = component.getSwComponentMappings();
		  if (hwmappings == null) {
			  continue;
		  }
		  for (MSWComponentMapping hwMapping : hwmappings) {
			  MHWSWMappedArtefact processor = hwMapping.getMappedHWSWArtefact();
			  if (processor == null || ! (processor instanceof MInternalComponentArtefact)) {
				  continue;
			  }
			  MAbstractInternalComponentArtefactOwner parent = ((MInternalComponentArtefact)processor).getInternalComponentOwner();
			  if (parent == null || !(parent instanceof MDetailedElectricElectronic)) {
				  continue;
			  }
			  List<MLogicalConnector> logicalConnectors = ((MDetailedElectricElectronic)parent).getEeLogicalConnectors();
			  if (logicalConnectors == null) {
				  continue;
			  }
			  for (MLogicalConnector logicalConnector : logicalConnectors) {
				  if (! (logicalConnector instanceof MBusConnector)) {
					  continue;
				  }
				  List<MECUInterface> interfaces = ((MBusConnector) logicalConnector).getEcuInterfaces();
				  if (interfaces == null) {
					  continue;
				  }
				  if (receivingInterfaces == null) {
					continue;
				}
				  for (MECUInterface receivingInterface : receivingInterfaces) {
					if (interfaces.contains(receivingInterface)) {
						  found = true;
						  break;
					  }
				}
			  }
		  }
		  if (! found) {
			  return false;
		  }
	  }
	  return true;
  } 
   	
public static boolean hasSendInterfaceForSportMapping(aquintos.mm.eea.componentslayer.signaltransmission.MSignalTransmission signalTransmission) {
Collection<MECUInterface> sendingInterfaces = signalTransmission.getSendingECUInterface();

	  boolean found;
		List<MPPortTransmissionMapping> pportMappings = signalTransmission.getPportTransmissionMappings();
	  {
		  if (pportMappings==null || pportMappings.isEmpty())
		 {
			return true; // nothing to check
		}
	  }

		for (MPPortTransmissionMapping pportMapping : pportMappings) {
		  found = false;
			MAbstractPPortTxMappableArtefact port = pportMapping.getMappedPPort();
		  if (port == null || !(port instanceof MSWPort)) {
			  continue;
		  }
		  MAbstractSWInstance component = ((MSWPort) port).getSwInstance();
		  if (component == null) {
			  continue;
		  }
		  List<MSWComponentMapping> hwmappings = component.getSwComponentMappings();
		  if (hwmappings == null) {
			  continue;
		  }
		  for (MSWComponentMapping hwMapping : hwmappings) {
			  MHWSWMappedArtefact processor = hwMapping.getMappedHWSWArtefact();
			  if (processor == null || ! (processor instanceof MInternalComponentArtefact)) {
				  continue;
			  }
			  MAbstractInternalComponentArtefactOwner parent = ((MInternalComponentArtefact)processor).getInternalComponentOwner();
			  if (parent == null || !(parent instanceof MDetailedElectricElectronic)) {
				  continue;
			  }
			  List<MLogicalConnector> logicalConnectors = ((MDetailedElectricElectronic)parent).getEeLogicalConnectors();
			  if (logicalConnectors == null) {
				  continue;
			  }
			  for (MLogicalConnector logicalConnector : logicalConnectors) {
				  if (! (logicalConnector instanceof MBusConnector)) {
					  continue;
				  }
				  List<MECUInterface> interfaces = ((MBusConnector) logicalConnector).getEcuInterfaces();
				  if (interfaces == null) {
					  continue;
				  }
					if (sendingInterfaces == null) {
						continue;
					}
					for (MECUInterface sendingInterface : sendingInterfaces) {
					if (interfaces.contains(sendingInterface)) {
						  found = true;
						  break;
					  }
				}
			  }
		  }
		  if (! found) {
			  return false;
		  }
	  }
	  return true;
  } 
   	
public static boolean isARCoreArtefact(aquintos.mm.commoncore.attributedefinitionextension.MAbstractImExArtefact artefact) {
return (artefact instanceof MARCoreArtefact );
  } 
   	
public static void initialize() {

  } 
   	
public static void cleanUp() {

  } 
   	
public static boolean isProvider(MConventionalConnector connector) {
if (connector == null ) {
	return false;
}
	  List<MGenericAttribute> attributes = connector.getGenericAttributes();
	  if (attributes == null) {
		return false;
	}
	  for (MGenericAttribute attribute : attributes) {
		  if (attribute.getName()!= null && attribute.getName().contains ("Provider")) {
			return true;
		}
	  }
	  return false;
  } 
   	
public static boolean isConsumer(MConventionalConnector connector) {
if (connector == null ) {
	return false;
}
	  List<MGenericAttribute> attributes = connector.getGenericAttributes();
	  if (attributes == null) {
		return false;
	}
	  for (MGenericAttribute attribute : attributes) {
		  if (attribute.getName()!= null && attribute.getName().contains ("Consumer")) {
			return true;
		}
	  }
	  return false;
  } 
   	
public static boolean hasMaxContinuous(MConventionalConnector connector) {
if (connector == null ) {
	return false;
}
	  List<MGenericAttribute> attributes = connector.getGenericAttributes();
	  if (attributes == null) {
		return false;
	}
	  for (MGenericAttribute attribute : attributes) {
		  if (((MEEAttribute)attribute).getName()!= null && (attribute.getName().contains ("Consumer") ||attribute.getName().contains ("Provider"))) {
			  return hasMaxContinuous ((MEEAttribute)attribute);
		  }
	  }
	  return false;
  } 
   	
public static boolean hasNominal(MEEAttribute attribute) {
List<MGenericAttribute> attributes2 = attribute.getGenericAttributes();
			  if (attributes2 == null) {
				return false;
			}
			  for (MGenericAttribute attribute2 : attributes2) {
				  if (((MEEAttribute)attribute2).getName() != null && attribute2.getName().contains("Current_Nominal")
						  && attribute2.getValue() != null) {
					return true;
				}
	  }
	  return false;
  } 
   	
public static boolean hasMaxContinuous(MEEAttribute attribute) {
List<MGenericAttribute> attributes2 = attribute.getGenericAttributes();
			  if (attributes2 == null) {
				return false;
			}
			  for (MGenericAttribute attribute2 : attributes2) {
				  if (((MEEAttribute)attribute2).getName() != null && attribute2.getName().contains("Current_Max_Continuous")
						  && attribute2.getValue() != null) {
					return true;
				}
	  }
	  return false;
  } 
   	
public static boolean hasNominal(MConventionalConnector connector) {
if (connector == null ) {
	return false;
}
	  List<MGenericAttribute> attributes = connector.getGenericAttributes();
	  if (attributes == null) {
		return false;
	}
	  for (MGenericAttribute attribute : attributes) {
		  if (((MEEAttribute)attribute).getName()!= null && (attribute.getName().contains ("Consumer") ||attribute.getName().contains ("Provider"))) {
			  return hasNominal ((MEEAttribute) attribute);
		  }
	  }
	  return false;
  } 
   	
public static boolean isSignal(MConventionalConnector connector) {
if (connector == null ) {
	return false;
}
	  List<MGenericAttribute> attributes = connector.getGenericAttributes();
	  if (attributes == null) {
		return false;
	}
	  for (MGenericAttribute attribute : attributes) {
		  if (attribute.getName()!= null && attribute.getName().contains ("Signal")) {
			return true;
		}
	  }
	  return false;
  } 
   	
public static boolean hasOrderedSchematicPins(MBusConnector connector) {
List<MSchematicPin> schematicPinsList = connector.getSchematicPins();
	    if(schematicPinsList == null) {
	    	return false;
	    }
		boolean sorted = true;
		if (schematicPinsList.size() > 1) {
			for (int i = 1; i < schematicPinsList.size(); i++) {
				String name1 = getExtension(schematicPinsList.get(i - 1));
				if (name1 == null) {
					name1 = schematicPinsList.get(i - 1).getAliasName();
				}
				if (name1 == null || name1.length() == 0) {
					name1 = schematicPinsList.get(i - 1).getName();
				}

				String name2 = getExtension(schematicPinsList.get(i));
				if (name2 == null) {
					name2 = schematicPinsList.get(i).getAliasName();
				}
				if (name2 == null || name2.length() == 0) {
					name2 = schematicPinsList.get(i).getName();
				}
				if ((name1 != null) && (name2 != null)) {
				  if (name1.compareTo(name2) > 0) {
				    sorted = false;
				  }
				}
			}
	  }
	  return sorted;
  } 
   	
public static String getExtension(MSchematicPin param1) {
String extension = null;
	    Collection<MAbstractAttributeValue> attributes = param1.getOwnedAttributeValues();
	    if (attributes != null) {
	      for (MAbstractAttributeValue attribute : attributes) {
	    	if(attribute.getAttributeDefinition() != null){
		        String name = attribute.getAttributeDefinition().getName();
		        if (name != null && name.contains("Functional Role")) {
		          MAbstractEnumEntry role = AttributeDefinitionUtility.getValueAsEnumLiteral(attribute);
		          if (role != null && (role instanceof MStringLiteral)) {
		            extension = ((MStringLiteral) role).getValue();
		            if (extension != null) { // finish after the first success
		              return extension;
		            }
		          }
		        }
	    	}
	      }
	    }
	    return null;
  } 
   	
public static boolean isHasInvalidValue(MApplicationDataType param1) {
return param1 instanceof MHasInvalidValue;
  } 
   	
public static boolean isMPDUGWExistInMultipartPDU(MDynamicPart dynamicPart, MMultiplexedIPDU multiplexedPdu) {
List<MPDUTransmission> multiplexedPDUTransmissions = multiplexedPdu.getIPDUTransmissions();
    List<MDynamicPartAlternative> dynamicPartAlternatives = dynamicPart.getDynamicPartAlternatives();
    for (MPDUTransmission multiplexedPDUTransmission : multiplexedPDUTransmissions) {
      MAbstractChannelCommunicationContentOwner multiplexedPDUTransmissionContainer = multiplexedPDUTransmission.getIPDUTransmissionContainer();

      for (MDynamicPartAlternative dynamicPartAlternative : dynamicPartAlternatives) {
        MSignalIPDU dynamicPartPDU = dynamicPartAlternative.getIpdu();
        List<MPDUTransmission> dynamicPartPduTransmissions = dynamicPartPDU.getIPDUTransmissions();
        for (MPDUTransmission dynamicPartPduTransmission : dynamicPartPduTransmissions) {
          MAbstractChannelCommunicationContentOwner dynamicPartPduTransmissionContainer = dynamicPartPduTransmission.getIPDUTransmissionContainer();
          if (multiplexedPDUTransmissionContainer == dynamicPartPduTransmissionContainer) {
            if (multiplexedPDUTransmission.getRoutingEntriesIn().size() != dynamicPartPduTransmission.getRoutingEntriesIn().size()) {
              return true;
            }
            if (multiplexedPDUTransmission.getRoutingEntriesOut().size() != dynamicPartPduTransmission.getRoutingEntriesOut().size()) {
              return true;
            }
          }

        }
      }

    }

  return false;
  } 
   	
public static boolean isOffsetAndFactorEqual(MComputationMethod networkCm, MComputationMethod softwareCm) {
MAbstractConversionSpecification nwPti = networkCm.getPhysicalToInternalConversion();
    MAbstractConversionSpecification swItp = softwareCm.getInternalToPhysicalConversion();
    if (nwPti instanceof MLinearVerbalTableConversion) {
      MLinearVerbalTableConversion nwlinearverbalTable = (MLinearVerbalTableConversion) nwPti;
      if (swItp instanceof MLinearConversion) {
        MLinearConversion swlinear = (MLinearConversion) swItp;
        if (swlinear.getFactor() != nwlinearverbalTable.getFactor() || swlinear.getOffset() != nwlinearverbalTable.getOffset()) {
          return true;
        }
      }
      if (swItp instanceof MLinearVerbalTableConversion) {
        MLinearVerbalTableConversion swlinearverbal = (MLinearVerbalTableConversion) swItp;
        if (swlinearverbal.getFactor() != nwlinearverbalTable.getFactor() || swlinearverbal.getOffset() != nwlinearverbalTable.getOffset()) {
          return true;
        }
      }

      if (nwlinearverbalTable.getFactor() != 1.0 || nwlinearverbalTable.getOffset() != 0.0) {
        if (!(swItp instanceof MLinearVerbalTableConversion) && swItp instanceof MVerbalTableConversion) {
          return true;
        }
      }

    } else if (nwPti instanceof MVerbalTableConversion) {
      if (swItp instanceof MLinearConversion) {
        MLinearConversion swlinear = (MLinearConversion) swItp;
        MLinearConversion nwlinear = (MLinearConversion) nwPti;
        if (swlinear.getFactor() != nwlinear.getFactor() || swlinear.getOffset() != nwlinear.getOffset()) {
          return true;
          }
        }

        if (swItp instanceof MLinearVerbalTableConversion) {
          MLinearVerbalTableConversion nwlinearverbal = (MLinearVerbalTableConversion) nwPti;
          MLinearVerbalTableConversion swlinearverbal = (MLinearVerbalTableConversion) swItp;
          if (swlinearverbal.getFactor() != nwlinearverbal.getFactor() || swlinearverbal.getOffset() != nwlinearverbal.getOffset()) {
            return true;
          }
        }
      }
      return false;
  } 
   	
public static boolean isNwAndSWCompMethodMinMaxEqual(MComputationMethod param2, MApplicationDataType param3) {
MComputationMethod nwCompMethod = null;
  MSignal signal = null;
  if (param3 instanceof MApplicationValueType) {
    MApplicationValueType mavtype = (MApplicationValueType) param3;
    Optional<MSignal> sigExist = mavtype.getApplicationTypedArtefacts().stream().filter(MSignal.class::isInstance).map(MSignal.class::cast).findAny();
    if (sigExist.isPresent()) {
      signal = sigExist.get();
      nwCompMethod = signal.getUsedComputationMethod();
    }

    Optional<MApplicationRecordElement> reExist = mavtype.getApplicationTypedArtefacts().stream().filter(MApplicationRecordElement.class::isInstance).map(MApplicationRecordElement.class::cast).findAny();
    if (reExist.isPresent()) {
      MApplicationRecordElement re = reExist.get();
      List<MAbstractApplicationDataTypeMapping> amapping = re.getApplicationDataTypeMappings();
      for (MAbstractApplicationDataTypeMapping mapping : amapping) {
        if (mapping instanceof MDataTypeSystemSignalMapping) {
          MDataTypeSystemSignalMapping mdm = (MDataTypeSystemSignalMapping) mapping;
          MAbstractDataTypeMappingTarget msignal = mdm.getMappedSignal();
          if (msignal instanceof MSystemSignal) {
            MSystemSignal ssignal = (MSystemSignal) msignal;
            Collection<MSignal> sigList = ssignal.getSignals();
            for (MSignal sig : sigList) {
              signal = sig;
              nwCompMethod = sig.getUsedComputationMethod();
            }
          }
        }

      }
    }
  }

  if (param3 instanceof MApplicationBooleanType) {
    MApplicationBooleanType abtype = (MApplicationBooleanType) param3;
    Optional<MSignal> sigExist = abtype.getApplicationTypedArtefacts().stream().filter(MSignal.class::isInstance).map(MSignal.class::cast).findAny();
    if (sigExist.isPresent()) {
      signal = sigExist.get();
      nwCompMethod = signal.getUsedComputationMethod();
    }
  }

  List<MSignalTransmission> sigList = signal.getSignalTransmissions();
  List<MECUInterface> listEcu = new ArrayList<>();
  for (MSignalTransmission stx : sigList) {
    Collection<MECUInterface> rxECUList = stx.getReceivingECUInterface();
    Collection<MECUInterface> txECUList = stx.getSendingECUInterface();
    listEcu.addAll(rxECUList);
    listEcu.addAll(txECUList);
  }

  Optional<MECUInterface> isDomainEcu = listEcu.stream().filter(e -> e.getName().contains("Domain_Controller")).findAny();
  if(isDomainEcu.isPresent()) {
    return isMinMaxEqualGrpSignalCompSwAndNwCompMethod(nwCompMethod, param2);
  }
return false;
  } 
   	
public static boolean isPhsicalValueWithinRange(MComputationMethod param1, MSignal param3) {
int calMax = 0, calMin = 0;
int bitLength = param3.getBitLength();
MAbstractConversionSpecification nwitp = param1.getInternalToPhysicalConversion();
MAbstractConversionSpecification nwpti = param1.getPhysicalToInternalConversion();
if (nwitp instanceof MLinearVerbalTableConversion) {
  MLinearVerbalTableConversion mlv = (MLinearVerbalTableConversion) nwitp;
  MLinearVerbalTableConversion nwptiLtv = (MLinearVerbalTableConversion) nwpti;
  int rawMax = (int) (Math.pow(2, bitLength) - 1);
  int rawMaxAssigned =(int) Double.parseDouble(mlv.getMax());
  int rawMin = (int) Double.parseDouble(mlv.getMin());
  calMax = (int) (rawMax * mlv.getFactor() + mlv.getOffset());
  calMin = (int) (rawMin * mlv.getFactor() + mlv.getOffset());
  int ptiMin = (int) Double.parseDouble(nwptiLtv.getMin());
  int ptiMax = (int) Double.parseDouble(nwptiLtv.getMax());
  if (ptiMin <= calMin &&  ptiMax <= calMax && rawMin>=0 &&rawMaxAssigned<= rawMax) {
    return false;
  }else {
    return true;
  }
}
if (nwitp instanceof MLinearConversion) {
  MLinearConversion mlv = (MLinearConversion) nwitp;
  MLinearConversion nwptiLtv = (MLinearConversion) nwpti;
  int rawMax = (int) (Math.pow(2, bitLength) - 1);
  int rawMin = (int) Double.parseDouble(mlv.getMin());
  calMax = (int) (rawMax * mlv.getFactor() + mlv.getOffset());
  int rawMaxAssigned =(int) Double.parseDouble(mlv.getMax());
  calMin = (int) (rawMin * mlv.getFactor() + mlv.getOffset());
  int ptiMin = (int) Double.parseDouble(nwptiLtv.getMin());
  int ptiMax = (int) Double.parseDouble(nwptiLtv.getMax());
  if (ptiMin <= calMin &&  ptiMax <= calMax&& rawMin>=0 &&rawMaxAssigned<= rawMax) {
    return false;
  }else {
    return true;
  }
}

if (nwitp instanceof MVerbalTableConversion) {
  MVerbalTableConversion mlv = (MVerbalTableConversion) nwitp;
  MVerbalTableConversion nwptiLtv = (MVerbalTableConversion) nwpti;
  int rawMax = (int) (Math.pow(2, bitLength) - 1);
  int rawMin = (int) Double.parseDouble(mlv.getMin());
  int rawMaxAssigned =(int) Double.parseDouble(mlv.getMax());
  int ptiMin = (int) Double.parseDouble(nwptiLtv.getMin());
  int ptiMax = (int) Double.parseDouble(nwptiLtv.getMax());
  if (ptiMin <= rawMin &&  ptiMax <= rawMax&& rawMin>=0 &&rawMaxAssigned<= rawMax) {
    return false;
  }else {
    return true;
  }
}

return false;
  } 
   	
public static boolean isIPKPortExistInAswc(MSWPortPrototype param2, MAtomicSWComponent param1) {
boolean isExist = false;
List<MSWPort> mswPortList = param1.getPorts();
String portName = param2.getName().substring(0,param2.getName().lastIndexOf("_"));
List<MSWPort> listRp = new ArrayList<>();
for (MSWPort mswPort : mswPortList) {
  MSWPortPrototype swpType = mswPort.getSwPortPrototype();
  MAbstractPortType ptype = swpType.getPortType();
  if (ptype instanceof MReceiverPortType) {
    MReceiverPortType rType = (MReceiverPortType) ptype;
    List<MSWPortPrototype> mswRPortList = rType.getSwPortPrototypes();
    for (MSWPortPrototype rtype : mswRPortList) {
      List<MSWPort> mswList = rtype.getSwPorts();
      for (MSWPort port : mswList) {
        if (port.getTransmittableSignals().size() > 0) {
          listRp.add(port);
        }
      }
    }
  }
}

for (MSWPort port : listRp) {
  List<MAbstractSignalMappingTarget> txSg = port.getTransmittableSignals();
  for (MAbstractSignalMappingTarget mswg : txSg) {
    if (mswg instanceof MSystemSignalGroup) {
      MSystemSignalGroup sg = (MSystemSignalGroup) mswg;
      for (MSystemSignal msg : sg.getSystemSignals()) {
        if (msg.getName().contains(portName)) {
        return false;
      }
    }
  } else if (mswg instanceof MSystemSignal) {
    MSystemSignal sg = (MSystemSignal) mswg;
    if (sg.getName().contains(portName)) {
      return false;
    }
    }
  }
}
if(!isExist) {
  return true;
}
return false;
  } 
   	
public static boolean isInitialValuePartOfTableValue(MSignal param2, MComputationMethod param1) {
int value = 0;
  boolean isExist = false, notEmpty = false;
  MValueSpecification initValue = param2.getRawInitValue();
  if (initValue instanceof MIntegerLiteral) {
    MIntegerLiteral literal = (MIntegerLiteral) initValue;
    value = literal.getValue();
  }

  MAbstractConversionSpecification internalToPhysicalConversion = param1.getInternalToPhysicalConversion();
  if (!(internalToPhysicalConversion instanceof MLinearVerbalTableConversion) || internalToPhysicalConversion instanceof MVerbalTableConversion) {
    MVerbalTableConversion conversion = (MVerbalTableConversion) internalToPhysicalConversion;
    List<MTableValue> tableValues = conversion.getTableValues();
    if (!tableValues.isEmpty() && conversion.getTableValues().size() > 0) {
      notEmpty = true;
      for (MTableValue mTableValue : tableValues) {
        int parseInt = Integer.parseInt(mTableValue.getXIndex());
        if (parseInt == value) {
          return false;
        }
      }
    }
  }
  if (notEmpty && !isExist) {
    return true;
  }
return false;
  } 
   	
public static boolean IsContECUIfNotAlignedWithSPDUECUIf(MPDUTransmission param2, MContainerIPDU param1) {
ArrayList<MECU> ContainedPduTxeculist = new ArrayList<>();
		ArrayList<MECU> PduTxeculist = new ArrayList<>();
		List<MPDUTransmission> ipduTransmissions = param1.getIPDUTransmissions();
		if (!ipduTransmissions.isEmpty()) {
			for (MPDUTransmission mpduTransmission : ipduTransmissions) {
				Collection<MECUInterface> sendingECUInterface = mpduTransmission.getSendingECUInterface();
				Collection<MECUInterface> receivingECUInterface = mpduTransmission.getReceivingECUInterface();
				if (!receivingECUInterface.isEmpty()) {
					for (MECUInterface mecuInterface : receivingECUInterface) {
					  MSignalConnector connector = mecuInterface.getConnector();
						if (connector instanceof MBusConnector) {
							MBusConnector bus = (MBusConnector) connector;
							MDetailedElectricElectronic electronicComposite = bus.getElectronicComposite();
							if (electronicComposite instanceof MECU) {
								MECU sourceecu = (MECU) electronicComposite;
								if (!PduTxeculist.contains(sourceecu)) {
									PduTxeculist.add(sourceecu);
								}
							}
						}
					}
				}
				if (!sendingECUInterface.isEmpty()) {
					for (MECUInterface mecuInterface : sendingECUInterface) {
					  MSignalConnector connector = mecuInterface.getConnector();
						if (connector instanceof MBusConnector) {
							MBusConnector bus = (MBusConnector) connector;
							MDetailedElectricElectronic electronicComposite = bus.getElectronicComposite();
							if (electronicComposite instanceof MECU) {
								MECU sourceecu = (MECU) electronicComposite;
								if (!PduTxeculist.contains(sourceecu)) {
									PduTxeculist.add(sourceecu);
								}
							}
						}
					}
				}
			}
		}
		Collection<MPDUTransmission> containedPDUTransmissions = param1.getContainedPDUTransmissions();
		if (!containedPDUTransmissions.isEmpty()) {
			for (MPDUTransmission mpduTransmission : containedPDUTransmissions) {
				Collection<MECUInterface> sendingECUInterface = mpduTransmission.getSendingECUInterface();
				Collection<MECUInterface> receivingECUInterface = mpduTransmission.getReceivingECUInterface();
				if (!receivingECUInterface.isEmpty()) {
					for (MECUInterface mecuInterface : receivingECUInterface) {
					  MSignalConnector connector = mecuInterface.getConnector();
						if (connector instanceof MBusConnector) {
							MBusConnector bus = (MBusConnector) connector;
							MDetailedElectricElectronic electronicComposite = bus.getElectronicComposite();
							if (electronicComposite instanceof MECU) {
								MECU sourceecu = (MECU) electronicComposite;
								if (!ContainedPduTxeculist.contains(sourceecu)) {
									ContainedPduTxeculist.add(sourceecu);
									}
							}
						}
					}
				}
				if (!sendingECUInterface.isEmpty()) {
					for (MECUInterface mecuInterface : sendingECUInterface) {
					  MSignalConnector connector = mecuInterface.getConnector();
						if (connector instanceof MBusConnector) {
							MBusConnector bus = (MBusConnector) connector;
							MDetailedElectricElectronic electronicComposite = bus.getElectronicComposite();
							if (electronicComposite instanceof MECU) {
								MECU sourceecu = (MECU) electronicComposite;
								if (!ContainedPduTxeculist.contains(sourceecu)) {
									ContainedPduTxeculist.add(sourceecu);
								}
							}
						}
					}
				}

			}
		}
		for (MECU ecu : PduTxeculist) {
			if (!ContainedPduTxeculist.contains(ecu)) {
				return true;
			}
		}
		ContainedPduTxeculist.clear();
		PduTxeculist.clear();
		return false;
  } 
   	
public static boolean isNwAndSwOffsetAndFactorEqual(MComputationMethod param2, MApplicationDataType param3) {
MComputationMethod nwCompMethod = null;
  MSignal signal = null;
  if (param3 instanceof MApplicationValueType) {
    MApplicationValueType mavtype = (MApplicationValueType) param3;
    Optional<MSignal> sigExist = mavtype.getApplicationTypedArtefacts().stream().filter(MSignal.class::isInstance).map(MSignal.class::cast).findAny();
    if (sigExist.isPresent()) {
      signal = sigExist.get();
      nwCompMethod = signal.getUsedComputationMethod();
    }

    Optional<MApplicationRecordElement> reExist = mavtype.getApplicationTypedArtefacts().stream().filter(MApplicationRecordElement.class::isInstance).map(MApplicationRecordElement.class::cast).findAny();
    if (reExist.isPresent()) {
      MApplicationRecordElement re = reExist.get();
      List<MAbstractApplicationDataTypeMapping> amapping = re.getApplicationDataTypeMappings();
      for (MAbstractApplicationDataTypeMapping mapping : amapping) {
        if (mapping instanceof MDataTypeSystemSignalMapping) {
          MDataTypeSystemSignalMapping mdm = (MDataTypeSystemSignalMapping) mapping;
          MAbstractDataTypeMappingTarget msignal = mdm.getMappedSignal();
          if (msignal instanceof MSystemSignal) {
            MSystemSignal ssignal = (MSystemSignal) msignal;
            Collection<MSignal> sigList = ssignal.getSignals();
            for (MSignal sig : sigList) {
              signal = sig;
              nwCompMethod = sig.getUsedComputationMethod();
            }
          }
        }

      }
    }
  }

  if (param3 instanceof MApplicationBooleanType) {
    MApplicationBooleanType abtype = (MApplicationBooleanType) param3;
    Optional<MSignal> sigExist = abtype.getApplicationTypedArtefacts().stream().filter(MSignal.class::isInstance).map(MSignal.class::cast).findAny();
    if (sigExist.isPresent()) {
      signal = sigExist.get();
      nwCompMethod = signal.getUsedComputationMethod();
    }
  }
  List<MSignalTransmission> sigList = signal.getSignalTransmissions();
  List<MECUInterface> listEcu = new ArrayList<>();
  for (MSignalTransmission stx : sigList) {
    Collection<MECUInterface> rxECUList = stx.getReceivingECUInterface();
    Collection<MECUInterface> txECUList = stx.getSendingECUInterface();
    listEcu.addAll(rxECUList);
    listEcu.addAll(txECUList);
  }
  Optional<MECUInterface> isDomainEcu = listEcu.stream().filter(e -> e.getName().contains("Domain_Controller")).findAny();
  if (true) {
    return isOffsetAndFactorEqual(nwCompMethod, param2);
  }
  return false;
  } 
   	
public static boolean IsCompMethodEnumValueSameInNwAndSw(MComputationMethod param2, MApplicationRecordType param1, MSignal param3) {
Optional<MApplicationRecordElement> isReExist = param1.getApplicationRecordElements().stream().filter(a -> param3.getName().contains(a.getName())).findAny();
  if (isReExist.isPresent()) {
    MComputationMethod cm = null;
    MApplicationRecordElement apre = isReExist.get();
    MApplicationDataType atype = apre.getApplicationType();
    if (atype instanceof MApplicationValueType) {
      MApplicationValueType av = (MApplicationValueType) atype;
      cm = av.getUsedComputationMethod();
    } else if (atype instanceof MApplicationBooleanType) {
      MApplicationBooleanType av = (MApplicationBooleanType) atype;
      cm = av.getUsedComputationMethod();
    } else if (atype instanceof MApplicationIntegerType) {
      MApplicationIntegerType av = (MApplicationIntegerType) atype;
      cm = av.getUsedComputationMethod();
    } else if (atype instanceof MApplicationFloatType) {
      MApplicationFloatType av = (MApplicationFloatType) atype;
      cm = av.getUsedComputationMethod();
    }
    if (cm != null && param2 != null) {
      MAbstractConversionSpecification sitp = param2.getInternalToPhysicalConversion();
      MAbstractConversionSpecification ditp = cm.getInternalToPhysicalConversion();
      if (sitp!=null && ditp!=null && sitp instanceof MVerbalTableConversion && ditp instanceof MVerbalTableConversion) {
        MVerbalTableConversion smvtc = (MVerbalTableConversion) sitp;
        MVerbalTableConversion dmvtc = (MVerbalTableConversion) ditp;

        List<MTableValue> sTmv = smvtc.getTableValues();
        List<MTableValue> dTmv = dmvtc.getTableValues();
        if (sTmv.size() == 0 && dTmv.size() == 0) {
          return false;
        }
        if (sTmv.size()!=dTmv.size()) {
          return true;
        }
        for (MTableValue tv : sTmv) {
          String[] tmp = tv.getName().split("_NW");
          Optional<MTableValue> isExist = dTmv.stream().filter(a -> a.getName().equals(tmp[0])).findAny();
          if (!isExist.isPresent()) {
            return true;
          }
        }
      }else if(sitp instanceof MVerbalTableConversion && ditp instanceof MLinearConversion){
        return false;
      }else {
        return true;
      }
    } else {
      return true;
    }

  } else if (param2 != null && !isReExist.isPresent()) {
    return true;
  }
return false;
  } 
   	
public static boolean IsContainerPDUContainsEthCom(MPDU param1) {
if (param1 instanceof MIPDU) {
      MIPDU mipdu = (MIPDU) param1;
      List<MPDUTransmission> ipduTxList = mipdu.getIPDUTransmissions();
      Optional<MPDUTransmission> isExist = ipduTxList.stream().filter(a -> a.getIPDUTransmissionContainer().getName().contains("ETH_")).findAny();
      if(!isExist.isPresent()) {
        return true;
      }
  }
return false;
  } 
   	
public static boolean IsContainedPDUAndTxCountEqual(MPDUTransmission param2, MContainerIPDU param1) {
Collection<MPDU> listConPdu = param1.getContainedPDUs();
  List<MPDUTransmission> conPduTxList = param2.getContainedPduTransmissions();
  if(listConPdu.size()!=conPduTxList.size()) {
    return true;
  }
return false;
  } 
   	
public static boolean isChannelCommSameInNw(MSignal param1) {
List chList = new ArrayList<>();
List<MSignalIPDUAssignment> ipduList = param1.getSignalIPDUAssignments();
for (MSignalIPDUAssignment sia : ipduList) {
  MPDU mpdu = (MPDU) sia.getSignalIPDU();
  List<MPDUTransmission> ipduTxList = mpdu.getIPDUTransmissions();
  for(MPDUTransmission pTx:ipduTxList) {
    MAbstractChannelCommunicationContentOwner ipduContainer = pTx.getIPDUTransmissionContainer();
    if(ipduContainer instanceof MChannelCommunication) {
      MChannelCommunication mc = (MChannelCommunication) ipduContainer;
      chList.add(mc.getName());
    }
  }
}
if(chList.size()>0 && param1.getSignalTransmissions().size()>0) {
      List<MSignalTransmission> sTxList = param1.getSignalTransmissions();
      Optional<MSignalTransmission> isExist = sTxList.stream().filter(a -> chList.contains(a.getSignalTransmissionContainer().getName())).findAny();
      for (MSignalTransmission stx : sTxList) {
        MAbstractChannelCommunicationContentOwner mc = stx.getSignalTransmissionContainer();
        if (mc instanceof MChannelCommunication) {
          MChannelCommunication mch = (MChannelCommunication) mc;
          if (!chList.contains(mch.getName())) {
            return true;
          }
        }
      }
}
return false;
  } 
   	
public static boolean isConPDUECUIfaceAlignedWithContainedPDUECUIface(MContainerIPDU param2, MPDUTransmission param1) {
Collection<MECUInterface> pduRxECUList = param1.getReceivingECUInterface();
  Collection<MECUInterface> pduTxECUList = param1.getSendingECUInterface();
  MPDUTransmission cpTx =  param2.getIPDUTransmissions().size()>0?param2.getIPDUTransmissions().get(0):null;
  if(cpTx!=null) {
    Collection<MECUInterface> cpduTxECUList = cpTx.getSendingECUInterface();
    Collection<MECUInterface> cpduRxECUList = cpTx.getReceivingECUInterface();

    for(MECUInterface txECU:pduTxECUList) {
      Optional<MECUInterface> isExist = cpduTxECUList.stream().filter(a -> a.getName().equals(txECU.getName())).findAny();
      if (!isExist.isPresent()) {
        return true;
      }
    }
    for(MECUInterface rxECU:pduRxECUList) {
      Optional<MECUInterface> isExist = cpduRxECUList.stream().filter(a -> a.getName().equals(rxECU.getName())).findAny();
      if (!isExist.isPresent()) {
        return true;
      }
    }

  }
return false;
  } 
   	
public static boolean isMaxAndMinValueOutOfRange(MComputationMethod param2, MApplicationDataType param3) {
int calMax = 0, calMin = 0;
MComputationMethod nwCompMethod = null;
MSignal signal = null;
if (param3 instanceof MApplicationValueType) {
  MApplicationValueType mavtype = (MApplicationValueType) param3;
  Optional<MSignal> sigExist = mavtype.getApplicationTypedArtefacts().stream().filter(MSignal.class::isInstance).map(MSignal.class::cast).findAny();
  if (sigExist.isPresent()) {
    signal = sigExist.get();
    nwCompMethod = signal.getUsedComputationMethod();
  }

  Optional<MApplicationRecordElement> reExist = mavtype.getApplicationTypedArtefacts().stream().filter(MApplicationRecordElement.class::isInstance).map(MApplicationRecordElement.class::cast).findAny();
  if (reExist.isPresent()) {
    MApplicationRecordElement re = reExist.get();
    List<MAbstractApplicationDataTypeMapping> amapping = re.getApplicationDataTypeMappings();
    for (MAbstractApplicationDataTypeMapping mapping : amapping) {
      if (mapping instanceof MDataTypeSystemSignalMapping) {
        MDataTypeSystemSignalMapping mdm = (MDataTypeSystemSignalMapping) mapping;
        MAbstractDataTypeMappingTarget msignal = mdm.getMappedSignal();
        if (msignal instanceof MSystemSignal) {
          MSystemSignal ssignal = (MSystemSignal) msignal;
          Collection<MSignal> sigList = ssignal.getSignals();
          for (MSignal sig : sigList) {
            signal = sig;
            nwCompMethod = sig.getUsedComputationMethod();
          }
        }
      }

    }
  }
}

if (param3 instanceof MApplicationBooleanType) {
  MApplicationBooleanType abtype = (MApplicationBooleanType) param3;
  Optional<MSignal> sigExist = abtype.getApplicationTypedArtefacts().stream().filter(MSignal.class::isInstance).map(MSignal.class::cast).findAny();
  if (sigExist.isPresent()) {
    signal = sigExist.get();
    nwCompMethod = signal.getUsedComputationMethod();
  }
}
List<MSignalTransmission> sigList = signal.getSignalTransmissions();
List<MECUInterface> listEcu = new ArrayList<>();
for (MSignalTransmission stx : sigList) {
  Collection<MECUInterface> rxECUList = stx.getReceivingECUInterface();
  Collection<MECUInterface> txECUList = stx.getSendingECUInterface();
  listEcu.addAll(rxECUList);
  listEcu.addAll(txECUList);
}

Optional<MECUInterface> isDomainEcu = listEcu.stream().filter(e -> e.getName().contains("Domain_Controller")).findAny();
if(isDomainEcu.isPresent()) {
  int bitLength = signal.getBitLength();
  MAbstractConversionSpecification nwitp = nwCompMethod.getInternalToPhysicalConversion();
  MAbstractConversionSpecification switp = param2.getInternalToPhysicalConversion();
  if (nwitp instanceof MLinearVerbalTableConversion && (switp instanceof MLinearConversion || switp instanceof MVerbalTableConversion)) {
    MLinearVerbalTableConversion mlv = (MLinearVerbalTableConversion) nwitp;

    int rawMax = (int) (Math.pow(2, bitLength) - 1);
    int rawMin = (int) Double.parseDouble(mlv.getMin());

    if (switp instanceof MLinearVerbalTableConversion) {
      calMax = (int) (rawMax * mlv.getFactor() + mlv.getOffset());
      calMin = (int) (rawMin * mlv.getFactor() + mlv.getOffset());
      MLinearVerbalTableConversion swmlv = (MLinearVerbalTableConversion) switp;
      int swptiMin = (int) Double.parseDouble(swmlv.getMin());
      int swptiMax = (int) Double.parseDouble(swmlv.getMax());
      if (swptiMin <= calMin && swptiMax <= calMax) {
        return false;
      } else {
        return true;
      }
    }

    if (switp instanceof MLinearConversion) {
      calMax = (int) (rawMax * mlv.getFactor() + mlv.getOffset());
      calMin = (int) (rawMin * mlv.getFactor() + mlv.getOffset());
      MLinearConversion swmlv = (MLinearConversion) switp;
      int swptiMin = (int) Double.parseDouble(swmlv.getMin());
      int swptiMax = (int) Double.parseDouble(swmlv.getMax());
      if (swptiMin <= calMin && swptiMax <= calMax) {
        return false;
      } else {
        return true;
      }
    }

    if (switp instanceof MVerbalTableConversion) {
      MVerbalTableConversion swmlv = (MVerbalTableConversion) switp;
      int swptiMin = (int) Double.parseDouble(swmlv.getMin());
      int swptiMax = (int) Double.parseDouble(swmlv.getMax());
      if (swptiMin <= rawMin && swptiMax <= rawMax) {
        return false;
      } else {
        return true;
      }
    }
  }
}
return false;
  } 
   	
public static boolean isComSpecsInitValueSameAsDE(MSenderComSpec param1) {
MDataElement mde = param1.getDataElement();
    MValueSpecification conInitVal = param1.getInitValue();
    MValueSpecification deIv = mde.getInitValue();
    if (deIv instanceof MRecordSpecification && !(conInitVal instanceof MRecordSpecification)
        || !(deIv instanceof MRecordSpecification) && conInitVal instanceof MRecordSpecification) {
      return true;
    }
    if (!(deIv instanceof MIntegerLiteral) && conInitVal instanceof MIntegerLiteral
        || deIv instanceof MIntegerLiteral && !(conInitVal instanceof MIntegerLiteral)) {
      return true;
    }

    if (!(deIv instanceof MFloatLiteral) && conInitVal instanceof MFloatLiteral
        || deIv instanceof MFloatLiteral && !(conInitVal instanceof MFloatLiteral)) {
      return true;
    }

    if (!(deIv instanceof MLongLiteral) && conInitVal instanceof MLongLiteral
        || deIv instanceof MLongLiteral && !(conInitVal instanceof MLongLiteral)) {
      return true;
    }

    if(deIv instanceof MIntegerLiteral && conInitVal instanceof MIntegerLiteral) {
      MIntegerLiteral dlit = (MIntegerLiteral)deIv;
      MIntegerLiteral clit = (MIntegerLiteral)conInitVal;
      List<MSenderComSpec> scomList = dlit.getHasInitValue().stream().filter(MSenderComSpec.class::isInstance).map(MSenderComSpec.class::cast).collect(Collectors.toList());
      List<MDataElement> deList = dlit.getHasInitValue().stream().filter(MDataElement.class::isInstance).map(MDataElement.class::cast).collect(Collectors.toList());
      Optional<MSenderComSpec> comSExist = scomList.stream().filter(a -> a.getName().equals(param1.getName())).findAny();
      Optional<MDataElement> deSExist = deList.stream().filter(a -> a.getName().equals(mde.getName())).findAny();
      if (!comSExist.isPresent() || !deSExist.isPresent()) {
        return true;
      }
    }

    if(deIv instanceof MFloatLiteral && conInitVal instanceof MFloatLiteral) {
      MFloatLiteral dlit = (MFloatLiteral)deIv;
      MFloatLiteral clit = (MFloatLiteral)conInitVal;
      List<MSenderComSpec> scomList = dlit.getHasInitValue().stream().filter(MSenderComSpec.class::isInstance).map(MSenderComSpec.class::cast).collect(Collectors.toList());
      List<MDataElement> deList = dlit.getHasInitValue().stream().filter(MDataElement.class::isInstance).map(MDataElement.class::cast).collect(Collectors.toList());
      Optional<MSenderComSpec> comSExist = scomList.stream().filter(a -> a.getName().equals(param1.getName())).findAny();
      Optional<MDataElement> deSExist = deList.stream().filter(a -> a.getName().equals(mde.getName())).findAny();
      if (!comSExist.isPresent() || !deSExist.isPresent()) {
        return true;
      }
    }
      if(deIv instanceof MLongLiteral && conInitVal instanceof MLongLiteral) {
        MLongLiteral dlit = (MLongLiteral)deIv;
        MLongLiteral clit = (MLongLiteral)conInitVal;
        List<MSenderComSpec> scomList = dlit.getHasInitValue().stream().filter(MSenderComSpec.class::isInstance).map(MSenderComSpec.class::cast).collect(Collectors.toList());
        List<MDataElement> deList = dlit.getHasInitValue().stream().filter(MDataElement.class::isInstance).map(MDataElement.class::cast).collect(Collectors.toList());
        Optional<MSenderComSpec> comSExist = scomList.stream().filter(a -> a.getName().equals(param1.getName())).findAny();
        Optional<MDataElement> deSExist = deList.stream().filter(a -> a.getName().equals(mde.getName())).findAny();
        if (!comSExist.isPresent() || !deSExist.isPresent()) {
          return true;
        }
      }

return false;
  } 
   	
public static boolean IsDEInitvalueAndGrpSignalCountSame(MSignalGroup param2, MDataElement param1) {
MValueSpecification deIv = param1.getInitValue();
  MRecordSpecification dmrs = deIv.getRecordSpecification();
  if(dmrs.getRecordElements().size()!=param2.getSignals().size()) {
return true;
  }
  return false;
  } 
   	
public static boolean isReceiverComSpecsInitValueSameAsDE(MReceiverComSpec param1) {
MDataElement mde = param1.getDataElement();
  MValueSpecification conInitVal = param1.getInitValue();
  MValueSpecification deIv = mde.getInitValue();
  if (deIv instanceof MRecordSpecification && !(conInitVal instanceof MRecordSpecification)
      || !(deIv instanceof MRecordSpecification) && conInitVal instanceof MRecordSpecification) {
    return true;
  }
  if (!(deIv instanceof MIntegerLiteral) && conInitVal instanceof MIntegerLiteral
      || deIv instanceof MIntegerLiteral && !(conInitVal instanceof MIntegerLiteral)) {
    return true;
  }

  if (!(deIv instanceof MFloatLiteral) && conInitVal instanceof MFloatLiteral
      || deIv instanceof MFloatLiteral && !(conInitVal instanceof MFloatLiteral)) {
    return true;
  }

  if (!(deIv instanceof MLongLiteral) && conInitVal instanceof MLongLiteral
      || deIv instanceof MLongLiteral && !(conInitVal instanceof MLongLiteral)) {
    return true;
  }

  if (deIv instanceof MIntegerLiteral && conInitVal instanceof MIntegerLiteral) {
    MIntegerLiteral dlit = (MIntegerLiteral) deIv;
    MIntegerLiteral clit = (MIntegerLiteral) conInitVal;
    List<MReceiverComSpec> scomList = dlit.getHasInitValue().stream().filter(MReceiverComSpec.class::isInstance).map(MReceiverComSpec.class::cast).collect(Collectors.toList());
    List<MDataElement> deList = dlit.getHasInitValue().stream().filter(MDataElement.class::isInstance).map(MDataElement.class::cast).collect(Collectors.toList());
    Optional<MReceiverComSpec> comSExist = scomList.stream().filter(a -> a.getName().equals(param1.getName())).findAny();
    Optional<MDataElement> deSExist = deList.stream().filter(a -> a.getName().equals(mde.getName())).findAny();
    if (!comSExist.isPresent() || !deSExist.isPresent()) {
      return true;
    }
  }

  if (deIv instanceof MFloatLiteral && conInitVal instanceof MFloatLiteral) {
    MFloatLiteral dlit = (MFloatLiteral) deIv;
    MFloatLiteral clit = (MFloatLiteral) conInitVal;
    List<MReceiverComSpec> scomList = dlit.getHasInitValue().stream().filter(MReceiverComSpec.class::isInstance).map(MReceiverComSpec.class::cast).collect(Collectors.toList());
    List<MDataElement> deList = dlit.getHasInitValue().stream().filter(MDataElement.class::isInstance).map(MDataElement.class::cast).collect(Collectors.toList());
    Optional<MReceiverComSpec> comSExist = scomList.stream().filter(a -> a.getName().equals(param1.getName())).findAny();
    Optional<MDataElement> deSExist = deList.stream().filter(a -> a.getName().equals(mde.getName())).findAny();
    if (!comSExist.isPresent() || !deSExist.isPresent()) {
      return true;
    }
  }
  if (deIv instanceof MLongLiteral && conInitVal instanceof MLongLiteral) {
    MLongLiteral dlit = (MLongLiteral) deIv;
    MLongLiteral clit = (MLongLiteral) conInitVal;
    List<MReceiverComSpec> scomList = dlit.getHasInitValue().stream().filter(MReceiverComSpec.class::isInstance).map(MReceiverComSpec.class::cast).collect(Collectors.toList());
    List<MDataElement> deList = dlit.getHasInitValue().stream().filter(MDataElement.class::isInstance).map(MDataElement.class::cast).collect(Collectors.toList());
    Optional<MReceiverComSpec> comSExist = scomList.stream().filter(a -> a.getName().equals(param1.getName())).findAny();
    Optional<MDataElement> deSExist = deList.stream().filter(a -> a.getName().equals(mde.getName())).findAny();
    if (!comSExist.isPresent() || !deSExist.isPresent()) {
      return true;
    }
  }
return false;
  } 
   	
public static boolean isMinMaxEqualGrpSignalCompSwAndNwCompMethod(MComputationMethod param2, MComputationMethod param1) {
MAbstractConversionSpecification nwPti = param2.getPhysicalToInternalConversion();
  MAbstractConversionSpecification swItp = param1.getInternalToPhysicalConversion();
  MAbstractConversionSpecification nwPtic = param2.getInternalToPhysicalConversion();
  if (nwPti instanceof MLinearVerbalTableConversion) {
    if(swItp instanceof MLinearConversion) {
    MLinearConversion swlinear = (MLinearConversion) swItp;
    MLinearConversion nwlinear = (MLinearConversion) nwPti;
    if (!swlinear.getMin().equals(nwlinear.getMin()) || !swlinear.getMax().equals(nwlinear.getMax())) {
      return true;
    }
    }
    if(swItp instanceof MLinearVerbalTableConversion) {
      MLinearVerbalTableConversion nwlinearverbal = (MLinearVerbalTableConversion) nwPti;
      MLinearVerbalTableConversion swlinearverbal = (MLinearVerbalTableConversion) swItp;

      String nwMax =  nwlinearverbal.getMax();
      List<MTableValue> tableValues = nwlinearverbal.getTableValues();
      if (tableValues.size() > 0) {
        Optional<MTableValue> st = tableValues.stream().filter(a -> a.getName().contains("SNA_")).findAny();
        if (st.isPresent()) {
          MTableValue tv = st.get();
          String snaMax = tv.getXIndex();

          if(snaMax.contains(".")) {
            double psmax = Double.parseDouble(snaMax);
            if(nwMax.contains(".")) {
              double pnmax = Double.parseDouble(nwMax);
              if(psmax>pnmax) {
                nwMax = snaMax;
              }
            }else {
              int fsmax = Integer.parseInt(snaMax);
              int fnmax = Integer.parseInt(nwMax);
              if(fsmax>fnmax) {
                nwMax = snaMax;
              }
            }
          }
          if(!snaMax.contains(".")) {
            int smax = Integer.parseInt(snaMax);
            if(nwMax.contains(".")) {
              double snmax = Double.parseDouble(nwMax);
              if(smax>snmax) {
                nwMax = snaMax;
              }
            }else {
              int esmax = Integer.parseInt(snaMax);
              int ensmax = Integer.parseInt(nwMax);
              if(esmax>ensmax) {
                nwMax = snaMax;
              }
            }
          }
        }
      }

      if (!swlinearverbal.getMin().equals(nwlinearverbal.getMin()) || !swlinearverbal.getMax().equals(nwMax)) {
        return true;
      }
    }
    if (swItp instanceof MVerbalTableConversion) {
      MVerbalTableConversion swlinearverbal = (MVerbalTableConversion) swItp;
      MVerbalTableConversion nwlinearverbal = (MVerbalTableConversion) nwPti;
      MLinearVerbalTableConversion nwItplinearverbal = (MLinearVerbalTableConversion) nwPtic;
      String nwMax =  nwlinearverbal.getMax();
      List<MTableValue> tableValues = nwlinearverbal.getTableValues();
      if (tableValues.size() > 0) {
        Optional<MTableValue> st = tableValues.stream().filter(a -> a.getName().contains("SNA_")).findAny();
        if (st.isPresent()) {
          MTableValue tv = st.get();
          String snaMax = tv.getXIndex();

          if(snaMax.contains(".")) {
            double psmax = Double.parseDouble(snaMax);
            if(nwMax.contains(".")) {
              double pnmax = Double.parseDouble(nwMax);
              if(psmax>pnmax) {
                nwMax = snaMax;
              }
            }else {
              int fsmax = Integer.parseInt(snaMax);
              int fnmax = Integer.parseInt(nwMax);
              if(fsmax>fnmax) {
                nwMax = snaMax;
              }
            }
          }
          if(!snaMax.contains(".")) {
            int smax = Integer.parseInt(snaMax);
            if(nwMax.contains(".")) {
              double snmax = Double.parseDouble(nwMax);
              if(smax>snmax) {
                nwMax = snaMax;
              }
            }else {
              int esmax = Integer.parseInt(snaMax);
              int ensmax = Integer.parseInt(nwMax);
              if(esmax>ensmax) {
                nwMax = snaMax;
              }
            }
          }
        }
      }
      if (!swlinearverbal.getMin().equals(nwlinearverbal.getMin()) || !swlinearverbal.getMax().equals(nwMax)) {
        return true;
        }
      }

  } else if (nwPti instanceof MVerbalTableConversion) {
    if(swItp instanceof MLinearConversion) {
    MLinearConversion swlinear = (MLinearConversion) swItp;
    MLinearConversion nwlinear = (MLinearConversion) nwPti;
    if (!swlinear.getMin().equals(nwlinear.getMin()) || !swlinear.getMax().equals(nwlinear.getMax())) {
      return true;
    }
    }

    if(swItp instanceof MLinearVerbalTableConversion) {
      MLinearVerbalTableConversion nwlinearverbal = (MLinearVerbalTableConversion) nwPti;
      MLinearVerbalTableConversion swlinearverbal = (MLinearVerbalTableConversion) swItp;
      MLinearVerbalTableConversion nwItplinearverbal = (MLinearVerbalTableConversion) nwPtic;
      String nwMax =  nwlinearverbal.getMax();
      List<MTableValue> tableValues = nwlinearverbal.getTableValues();
      if (tableValues.size() > 0) {
        Optional<MTableValue> st = tableValues.stream().filter(a -> a.getName().contains("SNA_")).findAny();
        if (st.isPresent()) {
          MTableValue tv = st.get();
          String snaMax = tv.getXIndex();

          if(snaMax.contains(".")) {
            double psmax = Double.parseDouble(snaMax);
            if(nwMax.contains(".")) {
              double pnmax = Double.parseDouble(nwMax);
              if(psmax>pnmax) {
                nwMax = snaMax;
              }
            }else {
              int fsmax = Integer.parseInt(snaMax);
              int fnmax = Integer.parseInt(nwMax);
              if(fsmax>fnmax) {
                nwMax = snaMax;
              }
            }
          }
          if(!snaMax.contains(".")) {
            int smax = Integer.parseInt(snaMax);
            if(nwMax.contains(".")) {
              double snmax = Double.parseDouble(nwMax);
              if(smax>snmax) {
                nwMax = snaMax;
              }
            }else {
              int esmax = Integer.parseInt(snaMax);
              int ensmax = Integer.parseInt(nwMax);
              if(esmax>ensmax) {
                nwMax = snaMax;
              }
            }
          }
        }
      }
      if (!swlinearverbal.getMin().equals(nwlinearverbal.getMin()) || !swlinearverbal.getMax().equals(nwMax)) {
        return true;
      }
    }

    if (swItp instanceof MVerbalTableConversion) {
      MVerbalTableConversion swlinearverbal = (MVerbalTableConversion) swItp;
      MVerbalTableConversion nwlinearverbal = (MVerbalTableConversion) nwPti;
      MLinearVerbalTableConversion nwItplinearverbal = (MLinearVerbalTableConversion) nwPtic;
      String nwMax =  nwlinearverbal.getMax();
      List<MTableValue> tableValues = nwlinearverbal.getTableValues();
      if (tableValues.size() > 0) {
        Optional<MTableValue> st = tableValues.stream().filter(a -> a.getName().contains("SNA_")).findAny();
        if (st.isPresent()) {
          MTableValue tv = st.get();
          String snaMax = tv.getXIndex();

          if(snaMax.contains(".")) {
            double psmax = Double.parseDouble(snaMax);
            if(nwMax.contains(".")) {
              double pnmax = Double.parseDouble(nwMax);
              if(psmax>pnmax) {
                nwMax = snaMax;
              }
            }else {
              int fsmax = Integer.parseInt(snaMax);
              int fnmax = Integer.parseInt(nwMax);
              if(fsmax>fnmax) {
                nwMax = snaMax;
              }
            }
          }
          if(!snaMax.contains(".")) {
            int smax = Integer.parseInt(snaMax);
            if(nwMax.contains(".")) {
              double snmax = Double.parseDouble(nwMax);
              if(smax>snmax) {
                nwMax = snaMax;
              }
            }else {
              int esmax = Integer.parseInt(snaMax);
              int ensmax = Integer.parseInt(nwMax);
              if(esmax>ensmax) {
                nwMax = snaMax;
              }
            }
          }
        }
      }
      if (!swlinearverbal.getMin().equals(nwlinearverbal.getMin()) || !swlinearverbal.getMax().equals(nwMax)) {
           return true;
        }
  }
  }
return false;
  } 
   	
public static boolean isGrpSignalCompMethodMinMaxSameAsSwCompMethod(MApplicationRecordType param2, MComputationMethod param1, MSignal param3) {
Optional<MApplicationRecordElement> isReExist = param2.getApplicationRecordElements().stream().filter(a -> param3.getName().equalsIgnoreCase(a.getName())).findAny();
  if (isReExist.isPresent()) {
    MComputationMethod cm = null;
    MApplicationRecordElement apre = isReExist.get();
    MApplicationDataType atype = apre.getApplicationType();
    if (atype instanceof MApplicationValueType) {
      MApplicationValueType av = (MApplicationValueType) atype;
      cm = av.getUsedComputationMethod();
    } else if (atype instanceof MApplicationBooleanType) {
      MApplicationBooleanType av = (MApplicationBooleanType) atype;
      cm = av.getUsedComputationMethod();
    } else if (atype instanceof MApplicationIntegerType) {
      MApplicationIntegerType av = (MApplicationIntegerType) atype;
      cm = av.getUsedComputationMethod();
    } else if (atype instanceof MApplicationFloatType) {
      MApplicationFloatType av = (MApplicationFloatType) atype;
      cm = av.getUsedComputationMethod();
    }
    if (cm != null && param1 != null) {
     return isMinMaxEqualGrpSignalCompSwAndNwCompMethod(param1, cm);
    }

  }

return false;
  } 
   	
public static boolean IsGrpSignalCompMethodOffsetAndfactorSameAsInNwAndSw(MApplicationRecordType param2, MComputationMethod param1, MSignal param3) {
Optional<MApplicationRecordElement> isReExist = param2.getApplicationRecordElements().stream().filter(a -> param3.getName().contains(a.getName())).findAny();
  if (isReExist.isPresent()) {
    MComputationMethod cm = null;
    MApplicationRecordElement apre = isReExist.get();
    MApplicationDataType atype = apre.getApplicationType();
    if (atype instanceof MApplicationValueType) {
      MApplicationValueType av = (MApplicationValueType) atype;
      cm = av.getUsedComputationMethod();
    } else if (atype instanceof MApplicationBooleanType) {
      MApplicationBooleanType av = (MApplicationBooleanType) atype;
      cm = av.getUsedComputationMethod();
    } else if (atype instanceof MApplicationIntegerType) {
      MApplicationIntegerType av = (MApplicationIntegerType) atype;
      cm = av.getUsedComputationMethod();
    } else if (atype instanceof MApplicationFloatType) {
      MApplicationFloatType av = (MApplicationFloatType) atype;
      cm = av.getUsedComputationMethod();
    }
    if (cm != null && param1 != null) {
     return isOffsetAndFactorEqual(param1, cm);
    } else {
      return true;
    }

  } else if (param1 != null && !isReExist.isPresent()) {
    return true;
  }
return false;
  } 
   	
public static boolean isIPKExistCorrectRunnableTiming(MRunnableEntity param2, MSenderPortType param1, MRunnableEntity param3, MSignal param4, MCyclicTiming param5) {
String tp = null;
  if (param5 != null && param5.getTimePeriod() > 0) {
    tp = String.valueOf((int) Math.round(param5.getTimePeriod()));
  }

  if(param1.getName().contains("_IPK") && param1.getName().contains(param4.getName())) {
    if(!param2.getName().equals(param3.getName()) || (tp != null && !param2.getName().endsWith(tp + "ms"))) {
      return true;
    }

  }
  return false;
  } 
   	
public static boolean isPDUTxEcuExistInSignalGrpSignaltx(MSignalTransmission param2, MPDUTransmission param1) {
Collection<MECUInterface> sigTxEcuList = param2.getSendingECUInterface();
Collection<MECUInterface> pduTxEcuList = param1.getSendingECUInterface();
  for (MECUInterface ecu : pduTxEcuList) {
    Optional<MECUInterface> exist = sigTxEcuList.stream().filter(a -> a.getName().equals(ecu.getName())).findAny();
      if(!exist.isPresent()) {
        return true;
      }
    }

return false;
  } 
   	
public static boolean isADTMappingExist(MInternalBehavior param2, MApplicationDataType param1, MSWPortPrototype param3) {
boolean isExist = false;
  String de = null;
  List<MApplicationTypeImplementationTypeMapping> adtMappingList = param1.getApplicationTypeImplementationTypeMappings();
  Collection<MDataTypeMappings> dataMappingPkg = param2.getDataTypeMappingSet();
  for (MDataTypeMappings dm : dataMappingPkg) {
    //Collection<MAbstractDataTypeMapping> pkgMappings = dm.getAbstractDataTypeMappings();
    // List<MAbstractDataTypeMapping> newList = new ArrayList<>(pkgMappings);
    for (MApplicationTypeImplementationTypeMapping dtm : adtMappingList) {
      // MAbstractDataTypeMapping mapping = pkgMappings.stream().filter(a -> a.getName().equals(dtm.getName())).findAny().get();
      if (dtm.getDataTypeMappingOwner().getName().equals(dm.getName())) {
        isExist = true;
      }
    }
  }
  if (!isExist) {
    return true;
  }
return false;
  } 
   	
public static boolean isValidVersionExistInLinFrameTx(MFrameTransmission param1) {
boolean isValidVersion = false;
  boolean isNotValidVersion = false;
  if (param1 instanceof MLINFrameTransmission) {
    List<MECUInterface> ecuList = new ArrayList();
    MLINFrameTransmission mlft = (MLINFrameTransmission) param1;
    Collection<MECUInterface> txECUList = mlft.getSendingECUInterface();
    Collection<MECUInterface> rxECUList = mlft.getReceivingECUInterface();
    ecuList.addAll(txECUList);
    ecuList.addAll(rxECUList);
    for (MECUInterface ecuIface : ecuList) {
      MAbstractControllerConfiguration controllerConfig = ecuIface.getControllerConfigurationOfECUInterface();
      if(controllerConfig instanceof MLINControllerConfiguration) {
        MLINControllerConfiguration mlinConfig = (MLINControllerConfiguration)controllerConfig;
        float version = Float.parseFloat(mlinConfig.getLinNodeProtocolVersion());
        if (version >= 2.0) {
          isValidVersion = true;
        } else {
          isValidVersion = false;
          isNotValidVersion = true;
          break;
        }
      }
    }
    if ((isValidVersion && (mlft.getChecksumType() == null || mlft.getChecksumType().equals(MLINChecksumTypeEnumEnum.CLASSIC) ))
        || isNotValidVersion && (mlft.getChecksumType() == null || mlft.getChecksumType().equals(MLINChecksumTypeEnumEnum.ENHANCED) )) {
      return true;
    }
  }
return false;
  } 
   	
public static boolean isUniSameInNwAndSWArtefacts(MComputationMethod param1) {
String unitName = param1.getUnit().getName();
  Collection<MAbstractComputationMethodUser> usedArtefacts = param1.getComputationMethodUsers();
  for(MAbstractComputationMethodUser mac:usedArtefacts) {
    if(mac instanceof MSignal) {
      MSignal signal = (MSignal)mac;
      if (signal.getApplicationType().getUnit() != null) {
        String appTypeUnit = signal.getApplicationType().getUnit().getName();
        if (!unitName.equals(appTypeUnit)) {
          return true;
        }
      }
    }
    if(mac instanceof MApplicationDataType) {
      MApplicationDataType dataType = (MApplicationDataType)mac;
      if (dataType.getUnit() != null) {
        String appTypeUnit = dataType.getUnit().getName();
        if (!unitName.equals(appTypeUnit)) {
          return true;
        }
      }
    }
  }
return false;
  } 
   	
public static boolean IsIntiValueSameInSignalAndDE(MDataElement param2, MSignal param1, MAbstractConversionSpecification conversion) {
double factorD =0.0;
  double offsetD=0.0;
  if (conversion instanceof MLinearConversion) {
    factorD =  ((MLinearConversion) conversion).getFactor();
    offsetD =  ((MLinearConversion) conversion).getOffset();
  }
  if (conversion instanceof MLinearVerbalTableConversion) {
    factorD =((MLinearVerbalTableConversion) conversion).getFactor();
    offsetD = ((MLinearVerbalTableConversion) conversion).getOffset();
  }
  if (param2 != null && param1 != null) {
MValueSpecification rawIv = param1.getRawInitValue();
  MValueSpecification deIv = param2.getInitValue();
  if (deIv != null) {
    if (deIv instanceof MRecordSpecification) {
      MRecordSpecification dmrs = (MRecordSpecification) deIv;
  Optional<MValueSpecification> isExist = dmrs.getRecordElements().stream().filter(a -> a.getName().equals(param1.getName())).findAny();
  if(isExist.isPresent()) {
    MValueSpecification dmv = isExist.get();
    if (dmv instanceof MIntegerLiteral && rawIv instanceof MIntegerLiteral) {
      MIntegerLiteral dliteral = (MIntegerLiteral) dmv;
      MIntegerLiteral sliteral = (MIntegerLiteral) rawIv;
      int convertedValue = (int) (sliteral.getValue() * factorD + offsetD);
      if ((dliteral.getValue() != sliteral.getValue()) && (dliteral.getValue() != (convertedValue))) {
        return true;
      }
    } else if (dmv instanceof MFloatLiteral && rawIv instanceof MFloatLiteral) {
      MFloatLiteral dliteral = (MFloatLiteral) dmv;
      MFloatLiteral sliteral = (MFloatLiteral) rawIv;
      double convertedValue = (sliteral.getValue() * factorD + offsetD);
      if ((dliteral.getValue() != sliteral.getValue()) && (dliteral.getValue() != (convertedValue))) {
        return true;
      }
    }
  }
}
}
}

return false;
  } 
   	
public static boolean IsIDT_DE_Signal_ElementMismatch(MImplementationValue param2, MImplementationRecord param1) {
List<MImplementationRecord> lisIma = new ArrayList<>();
if (param1 != null && param2 != null) {
 List<MImplementationTypedArtefact> impla =  param2.getImplementationTypedArtefacts();
 for(MImplementationTypedArtefact ima:impla) {
  if(ima instanceof MImplementationRecordElement) {
    MImplementationRecordElement mrec= (MImplementationRecordElement)ima;
    lisIma.add( mrec.getImplementationRecord());
  }
 }
 if(lisIma.size()>0) {
   Optional<MImplementationRecord> isExist = lisIma.stream().filter(a -> a.getName().equals(param1.getName())).findAny();
   if (!isExist.isPresent()) {
     return true;
   }
 }
  }

return false;
  } 
   	
public static boolean IsCompMethodContainsSpecialCharacter(MComputationMethod param1) {
Pattern regex = Pattern.compile("[a-zA-Z$&+,:;=\\\\?@#|/'<>^*()%!\\s]");
MAbstractConversionSpecification compItp = param1.getInternalToPhysicalConversion();
  MAbstractConversionSpecification compPTI = param1.getPhysicalToInternalConversion();
  if (compItp instanceof MLinearVerbalTableConversion) {
    MLinearVerbalTableConversion itpVc = (MLinearVerbalTableConversion) compItp;
    MLinearVerbalTableConversion ptiVc = (MLinearVerbalTableConversion) compPTI;
    String min = itpVc.getMin();
    String max = itpVc.getMax();
    if (regex.matcher(max).find() || regex.matcher(min).find()) {
      return true;
    }

    String pmin = ptiVc.getMin();
    String pmax = ptiVc.getMax();
    if (regex.matcher(pmax).find() || regex.matcher(pmin).find()) {
      return true;
    }
  }
  if (compItp instanceof MVerbalTableConversion) {
    MVerbalTableConversion itpVc = (MVerbalTableConversion) compItp;
    MVerbalTableConversion ptiVc = (MVerbalTableConversion) compPTI;
    String min = itpVc.getMin();
    String max = itpVc.getMax();
    if (regex.matcher(max).find() || regex.matcher(min).find()) {
      return true;
    }
    String pmin = ptiVc.getMin();
    String pmax = ptiVc.getMax();
    if (regex.matcher(pmax).find() || regex.matcher(pmin).find()) {
      return true;
    }

  }
  if (compItp instanceof MLinearConversion) {
    MLinearConversion itpVtc = (MLinearConversion) compItp;
    MLinearConversion ptiVtc = (MLinearConversion) compPTI;
    String min = itpVtc.getMin();
    String max = itpVtc.getMax();
    if (regex.matcher(max).find() || regex.matcher(min).find()) {
      return true;
    }
    String pmin = ptiVtc.getMin();
    String pmax = ptiVtc.getMax();
    if (regex.matcher(pmax).find() || regex.matcher(pmin).find()) {
      return true;
    }
  }
return false;
  } 
   	
public static boolean IsNameContainsSpecialCharacter(MAbstractNameAttributeArtefact param1) {
Pattern regex = Pattern.compile("[$&+,:;=\\\\?@#|/'<>^*()%!\\s-]");
  if (regex.matcher(param1.getName()).find()) {
    return true;
  }
return false;
  } 
   	
public static boolean IsADTAndIDTElementMismatch(MImplementationRecord param2, MApplicationRecordType param1) {
if (param1 != null && param2 != null) {
    if (param1.getApplicationRecordElements() != null) {
      List<MApplicationRecordElement> recordElements = param1.getApplicationRecordElements();
        for (int i = 0; i < recordElements.size(); i++) {
          if (param2.getImplementationRecordElements().get(i).getName().contains(recordElements.get(i).getName())) {
            //order OK
          } else {
            //order not OK
            return true;
            //listNotOrdered = true;
          }
        }
      }

  }
return false;
  } 
   	
public static boolean IsADT_DE_IDT_ElementMismatch(MRecordSpecification param2, MApplicationRecordType param1, MSignalGroup param3) {
if (param1 != null && param2 != null && param3 != null) {
    if (param1.getApplicationRecordElements() != null) {
      List<MApplicationRecordElement> recordElements = param1.getApplicationRecordElements();
      for (int i = 0; i < recordElements.size(); i++) {
        if (param2.getRecordElements().get(i).getName().contains(recordElements.get(i).getName())) {
          String name = recordElements.get(i).getName();
          Optional<MAbstractSignal> isExist = param3.getSignals().stream().filter(a -> a.getName().equals(name)).findAny();
          if(!isExist.isPresent()) {
            return true;
          }
          //order OK
        } else {
          //order not OK
          return true;
          //listNotOrdered = true;
        }
      }
    }

  }
return false;
  } 
   	
public static boolean isGrpPPortContainsPportmappingForGrpSignal(MSystemSignalGroup param2, MSWPort param1) {
List<MSystemSignal> sigNameList = param2.getSystemSignals();

  MAbstractPortType portType = param1.getSwPortPrototype().getPortType();
  if (portType instanceof MSenderPortType) {
    if (param1.getPportTransmissionMappings().size() == 0) {
      return true;
    }
    List<MAbstractTransmittableSignal> iSignalsList = param1.getPportTransmissionMappings().stream().map(a -> a.getMappedSignalTransmissions().iterator().next().getSignalType()).collect(Collectors.toList());
    List<MSystemSignalGroup> systemSignalGroups = iSignalsList.stream().filter(MSignalGroup.class::isInstance).map(MSignalGroup.class::cast).map(m -> m.getSystemSignalGroup()).collect(Collectors.toList());
   if(!systemSignalGroups.contains(param2)) {
     return true;
   }
    for (MSystemSignal sigName : sigNameList) {
      List<MAbstractTransmittableSignal> iSignals = param1.getPportTransmissionMappings().stream().map(a -> a.getMappedSignalTransmissions().iterator().next().getSignalType()).collect(Collectors.toList());
      List<MSystemSignal> systemSignals = iSignals.stream().filter(MSignal.class::isInstance).map(MSignal.class::cast).map(m -> m.getSystemSignal()).collect(Collectors.toList());
     if(!systemSignals.contains(sigName)) {
       return true;
     }

    }
  }
  if (portType instanceof MReceiverPortType) {
    if (param1.getRportTransmissionMappings().size() == 0) {
      return true;
    }
    List<MAbstractTransmittableSignal> iSignalsList = param1.getRportTransmissionMappings().stream().map(a -> a.getMappedSignalTransmissions().iterator().next().getSignalType()).collect(Collectors.toList());
    List<MSystemSignalGroup> systemSignalGroups = iSignalsList.stream().filter(MSignalGroup.class::isInstance).map(MSignalGroup.class::cast).map(m -> m.getSystemSignalGroup()).collect(Collectors.toList());
   if(!systemSignalGroups.contains(param2)) {
     return true;
   }

    for (MSystemSignal sigName : sigNameList) {
      List<MAbstractTransmittableSignal> iSignals = param1.getRportTransmissionMappings().stream().map(a -> a.getMappedSignalTransmissions().iterator().next().getSignalType()).collect(Collectors.toList());
      List<MSystemSignal> systemSignals = iSignals.stream().filter(MSignal.class::isInstance).map(MSignal.class::cast).map(m -> m.getSystemSignal()).collect(Collectors.toList());
     if(!systemSignals.contains(sigName)) {
       return true;
     }

    }
  }
return false;
  } 
   	
public static boolean IsSysSignalWithoutSWPort(MSystemSignal param1) {
boolean istxExist = false;
  boolean isRxExist = false;
  boolean isEligible = true;
  Collection<MSignal> signals = param1.getSignals();
  for (MSignal mSignal : signals) {
    List<MSignalTransmission> signalTransmissions = mSignal.getSignalTransmissions();
    for (MSignalTransmission signalTx : signalTransmissions) {
      if (!signalTx.getRoutingEntriesIn().isEmpty() || !signalTx.getRoutingEntriesOut().isEmpty()) {
        Collection<MPDUTransmission> pduTransmissions = signalTx.getPduTransmissions();
        for (MPDUTransmission pduTx : pduTransmissions) {
          if (pduTx.getRoutingEntriesIn().isEmpty() && pduTx.getRoutingEntriesOut().isEmpty()) {
            isEligible = false;
          }
        }
      }
    }
  }
  if (isEligible) {
  List<MSWPort> swList = param1.getPortInstances().stream().filter(MSWPort.class::isInstance).map(MSWPort.class::cast).collect(Collectors.toList());
  for (MSWPort ssw : swList) {
    MAbstractPortType stype = ssw.getSwPortPrototype().getPortType();
    if(stype instanceof MSenderPortType && !istxExist) {
      istxExist = true;
    }

   if(stype instanceof MReceiverPortType && !isRxExist) {
     isRxExist = true;
    }
  }

  if(!istxExist || !isRxExist) {
    return true;
  }
}
return false;
  } 
   	
public static boolean IsSystemSignalGrpWithOutPort(MSystemSignalGroup param1) {
boolean istxExist = false;
  boolean isRxExist = false;
  List<MSWPort> swList = param1.getPortInstances().stream().filter(MSWPort.class::isInstance).map(MSWPort.class::cast).collect(Collectors.toList());
  for (MSWPort ssw : swList) {
    MAbstractPortType stype = ssw.getSwPortPrototype().getPortType();
    if(stype instanceof MSenderPortType && !istxExist) {
      istxExist = true;
    }

   if(stype instanceof MReceiverPortType && !isRxExist) {
     isRxExist = true;
    }
  }

  if(!istxExist || !isRxExist) {
    return true;
  }
return false;
  } 
   	
public static boolean checkInterfacePortAndComSpecsCountSame(MDataElement param2, MSenderReceiverInterface param1) {
List<MInterfaceAssignment> portAssignments = param1.getPortAssignments();
  int count=0;
  for (MInterfaceAssignment mInterfaceAssignment : portAssignments) {
    MAbstractInterfaceAssignmentOwner assignedFromPort = mInterfaceAssignment.getAssignedFromPort();
    if(assignedFromPort instanceof MSenderPortType) {
      count++;
    }
    if(assignedFromPort instanceof MReceiverPortType) {
      count++;
     }

  }
  int comSpecSize =  param2.getSenderComSpecs().size()+param2.getReceiverComSpecs().size();

  if(count!=comSpecSize) {
    return true;
  }
return false;
  } 
   	
public static boolean isEthCtrlConfigAndCouplingPortPLTypeSame(MEthernetControllerConfiguration param2, MCouplingPort param1) {
if(param2.getPhysicalLayerType()==null || param1.getPhysicalLayerType()==null
      || param2.getPhysicalLayerType().equals(MEthernetPhysicalLayerTypeEnumEnum.__1000BASE_T)
      || param1.getPhysicalLayerType().equals(MEthernetPhysicalLayerTypeEnumEnum.__1000BASE_T)
      || param2.getPhysicalLayerType().equals(MEthernetPhysicalLayerTypeEnumEnum.IEEE802_11P)
      || param1.getPhysicalLayerType().equals(MEthernetPhysicalLayerTypeEnumEnum.IEEE802_11P)) {
    return true;
  }
return false;
  } 
   	
public static boolean isReceiverECUMissingInSocket(MSocketAddress param2, MPDUTransmission param1) {
if (!param1.getName().startsWith("DoIp_") && !param1.getName().startsWith("XCP_") && !param1.getName().startsWith("OBDTester")) {
    Collection<MECUInterface> pduReceivingEcuList = param1.getReceivingECUInterface();
    Collection<MEthernetECUInterface> socketEcuList = param2.getMulticastECUInterface();

    for (MECUInterface ecu : pduReceivingEcuList) {
      boolean exist = socketEcuList.stream().anyMatch(a -> a.getName().equals(ecu.getName()));
      if (!exist) {
        return true;
      }
    }
  }
return false;
  } 
   	
public static boolean verifyDoIpTpNode(MEthernetTpNode source) {
String TpNodeName=source.getName();
if(source.getTpAddressingType().toString().equals("FUNCTIONAL")){
if(!TpNodeName.endsWith("Func")){
return true;
}
}
else if(source.getTpAddressingType().toString().equals("PHYSICAL")){
if(!TpNodeName.endsWith("Phy")){
return true;
}
}
else if(source.getTpAddressingType().toString().equals("TESTER")){
if(!TpNodeName.endsWith("Tester")){
return true;
}
}
return false;
  } 
   	
public static boolean ValidateAddressOfTpConnections(MAbstractTpConnection source) {
if (source instanceof MLinTpConnection) {
      if (((MLinTpConnection) source).getTpAddress() != -1) {
        return true;
      }
    } else if (source instanceof MCanTpConnection) {
      if (((MCanTpConnection) source).getTpAddress() != -1) {
       return true;
      }

    } else if (source instanceof MDoIpTpConnection) {
      if (((MDoIpTpConnection) source).getTpAddress() != -1) {
        return true;
      }
    }
 return false;
  } 
   	
public static boolean signalsMatch(MPDU pdu2, MPDU pdu1) {
List<MSignalIPDUAssignment> pduAss1 = pdu1.getSignalAssignments();
		List<MSignalIPDUAssignment> pduAss2 = pdu2.getSignalAssignments();

		if (pduAss1 == null || pduAss1.isEmpty()) {
			if (pduAss2 == null || pduAss2.isEmpty()) {
				return true;
			} else {
				return false;
			}
		}
		if (pduAss2 == null || pduAss2.isEmpty()) {
			return false;
		}
		for (MSignalIPDUAssignment pduAs1 : pduAss1) {
			boolean found = false;
			for (MSignalIPDUAssignment pduAs2 : pduAss2) {
				if (pduAs1.getAssignedSignal().equals(pduAs2.getAssignedSignal())) {
					found = true;
				}
			}
			if (!found) {
				return false;
			}
		}
		for (MSignalIPDUAssignment pduAs2 : pduAss2) {
			boolean found = false;
			for (MSignalIPDUAssignment pduAs1 : pduAss1) {
				if (pduAs1.getAssignedSignal().equals(pduAs2.getAssignedSignal())) {
					found = true;
				}
			}
			if (!found) {
				return false;
			}
		}
		return true;
  } 
   	
public static boolean isIORequirement(MReqHWLogMapping mapping) {
if (mapping.getRequirement() == null) {
	return false;
}
	  if (mapping.getRequirement().getRequirementOwner() == null) {
		return false;
	}
	  if (mapping.getRequirement().getRequirementOwner().getName() == null) {
		return false;
	}
	  if (mapping.getRequirement().getRequirementOwner().getName().equals ("Domain Controller IO")) {
		return true;
	}
	  return false;
  } 
   	
public static boolean IsSizeGreaterthanZero(MApplicationArrayType Source) {
int arraySize = (int) Source.getArraySize();
  if(arraySize != 0)
  {
    return true;
  }

  return false;
  } 
   	
public static boolean isInitialvaluelargerthanenum(MDataElement source) {
boolean status = false;
  long HighestEnumvalue = 0;
  int value = 0;
  MValueSpecification initValue = source.getInitValue();
  if (initValue instanceof MIntegerLiteral) {
    MIntegerLiteral literal = (MIntegerLiteral) initValue;
    value = literal.getValue();
  }
  MApplicationDataType applicationType = source.getApplicationType();
  if (applicationType instanceof MApplicationValueType) {
    MApplicationValueType appvalue = (MApplicationValueType) applicationType;
    if (appvalue.getUsedComputationMethod() != null) {
      MComputationMethod usedComputationMethod = appvalue.getUsedComputationMethod();
      if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
        MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
        if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
          MLinearVerbalTableConversion conversion = (MLinearVerbalTableConversion) internalToPhysicalConversion;
          List<MTableValue> tableValues = conversion.getTableValues();
          if(conversion.getFactor()==1.0 && conversion.getOffset()==0.0) {
          if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1)  {
            for (MTableValue mTableValue : tableValues) {
              long parseInt = Long.parseLong(mTableValue.getXIndex());
              if (parseInt > HighestEnumvalue) {
                HighestEnumvalue = parseInt;
                status = true;
              }
            }}
          }
        }
      }
    }
  } else if (applicationType instanceof MApplicationBooleanType) {
    MApplicationBooleanType appbool = (MApplicationBooleanType) applicationType;
    if (appbool.getUsedComputationMethod() != null) {
      MComputationMethod usedComputationMethod = appbool.getUsedComputationMethod();
      if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
        MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
        if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
          MLinearVerbalTableConversion conversion = (MLinearVerbalTableConversion) internalToPhysicalConversion;
          List<MTableValue> tableValues = conversion.getTableValues();
          if(conversion.getFactor()==1.0 && conversion.getOffset()==0.0) {
          if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1) {
            for (MTableValue mTableValue : tableValues) {
              long parseInt = Long.parseLong(mTableValue.getXIndex());
              if (parseInt > HighestEnumvalue) {
                HighestEnumvalue = parseInt;
                status = true;
              }
            }}
          }
        }
      }
    }
  } else if (applicationType instanceof MApplicationArrayType) {
    MApplicationArrayType apparray = (MApplicationArrayType) applicationType;
    MApplicationDataType arrayElementType = apparray.getArrayElementType();
    if (arrayElementType instanceof MApplicationValueType) {
      MApplicationValueType appvalue = (MApplicationValueType) arrayElementType;
      if (appvalue.getUsedComputationMethod() != null) {
        MComputationMethod usedComputationMethod = appvalue.getUsedComputationMethod();
        if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
          MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
          if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
            MLinearVerbalTableConversion conversion = (MLinearVerbalTableConversion) internalToPhysicalConversion;
            List<MTableValue> tableValues = conversion.getTableValues();
            if(conversion.getFactor()==1.0 && conversion.getOffset()==0.0) {
            if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1) {
              for (MTableValue mTableValue : tableValues) {
                long parseInt = Long.parseLong(mTableValue.getXIndex());
                if (parseInt > HighestEnumvalue) {
                  HighestEnumvalue = parseInt;
                  status = true;
                }
              }
            }}
          }
        }
      }
    } else if (arrayElementType instanceof MApplicationBooleanType) {
      MApplicationBooleanType appbool = (MApplicationBooleanType) arrayElementType;
      if (appbool.getUsedComputationMethod() != null) {
        MComputationMethod usedComputationMethod = appbool.getUsedComputationMethod();
        if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
          MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
          if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
            MLinearVerbalTableConversion conversion = (MLinearVerbalTableConversion) internalToPhysicalConversion;
            List<MTableValue> tableValues = conversion.getTableValues();
            if(conversion.getFactor()==1.0 && conversion.getOffset()==0.0) {
            if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1)  {
              for (MTableValue mTableValue : tableValues) {
                long parseInt = Long.parseLong(mTableValue.getXIndex());
                if (parseInt > HighestEnumvalue) {
                  HighestEnumvalue = parseInt;
                  status = true;
                }
              }
            }}
          }
        }
      }
    }
  } else if (applicationType instanceof MApplicationRecordType) {
    MApplicationRecordType apprec = (MApplicationRecordType) applicationType;
    List<MApplicationRecordElement> applicationRecordElements = apprec.getApplicationRecordElements();
    if (!applicationRecordElements.isEmpty()) {
      for (MApplicationRecordElement mApplicationRecordElement : applicationRecordElements) {
        if (mApplicationRecordElement instanceof MApplicationValueType) {
          MApplicationValueType appvalue = (MApplicationValueType) mApplicationRecordElement;
          if (appvalue.getUsedComputationMethod() != null) {
            MComputationMethod usedComputationMethod = appvalue.getUsedComputationMethod();
            if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
              MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
              if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
                MLinearVerbalTableConversion conversion = (MLinearVerbalTableConversion) internalToPhysicalConversion;
                List<MTableValue> tableValues = conversion.getTableValues();
                if(conversion.getFactor()==1.0 && conversion.getOffset()==0.0) {
                if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1)  {
                  for (MTableValue mTableValue : tableValues) {
                    long parseInt = Long.parseLong(mTableValue.getXIndex());
                    if (parseInt > HighestEnumvalue) {
                      HighestEnumvalue = parseInt;
                      status = true;
                    }
                  }}
                }
              }
            }
          }
        } else if (mApplicationRecordElement instanceof MApplicationBooleanType) {
          MApplicationBooleanType appbool = (MApplicationBooleanType) mApplicationRecordElement;
          if (appbool.getUsedComputationMethod() != null) {
            MComputationMethod usedComputationMethod = appbool.getUsedComputationMethod();
            if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
              MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
              if (internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
                MLinearVerbalTableConversion conversion = (MLinearVerbalTableConversion) internalToPhysicalConversion;
                List<MTableValue> tableValues = conversion.getTableValues();
                if(conversion.getFactor()==1.0 && conversion.getOffset()==0.0) {
                if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1)  {
                  for (MTableValue mTableValue : tableValues) {
                    long parseInt = Long.parseLong(mTableValue.getXIndex());
                    if (parseInt > HighestEnumvalue) {
                      HighestEnumvalue = parseInt;
                      status = true;
                    }
                  }
                }
              }}
            }
          }
        }
      }
    }
  }
  if (value > HighestEnumvalue && status == true) {
    return true;
  }
  return false;
  } 
   	
public static boolean isInitialvalueSmallerthanenum(MDataElement source) {
boolean status = false;
  long HighestEnumvalue = 0;
  int value = 0;
  long max = 0;
  boolean isLinearConversion=false;
  List<Long> enumValues = new ArrayList<>();
  MValueSpecification initValue = source.getInitValue();
  if (initValue instanceof MIntegerLiteral) {
    MIntegerLiteral literal = (MIntegerLiteral) initValue;
    value = literal.getValue();
  }else {
    return false;
  }
  MApplicationDataType applicationType = source.getApplicationType();
  if (applicationType instanceof MApplicationValueType) {
    MApplicationValueType appvalue = (MApplicationValueType) applicationType;
    if (appvalue.getUsedComputationMethod() != null) {
      MComputationMethod usedComputationMethod = appvalue.getUsedComputationMethod();
      if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
        MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
        if (internalToPhysicalConversion instanceof MVerbalTableConversion) {
          if(internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
            String maxString = ((MVerbalTableConversion) internalToPhysicalConversion).getMax();
            max = Long.parseLong(maxString);
            isLinearConversion =true;
          }
          MVerbalTableConversion conversion = (MVerbalTableConversion) internalToPhysicalConversion;
          List<MTableValue> tableValues = conversion.getTableValues();
          //          if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1) {
            for (MTableValue mTableValue : tableValues) {
              long parseInt = Long.parseLong(mTableValue.getXIndex());
              enumValues.add(parseInt);
              if (parseInt > HighestEnumvalue) {
                HighestEnumvalue = parseInt;
                status = true;
              }
              //            }
          }
        }
      }
    }
  } else if (applicationType instanceof MApplicationBooleanType) {
    MApplicationBooleanType appbool = (MApplicationBooleanType) applicationType;
    if (appbool.getUsedComputationMethod() != null) {
      MComputationMethod usedComputationMethod = appbool.getUsedComputationMethod();
      if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
        MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
        if (internalToPhysicalConversion instanceof MVerbalTableConversion) {
          if(internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
            String maxString = ((MVerbalTableConversion) internalToPhysicalConversion).getMax();
            max = Long.parseLong(maxString);
            isLinearConversion =true;
          }
          MVerbalTableConversion conversion = (MVerbalTableConversion) internalToPhysicalConversion;
          List<MTableValue> tableValues = conversion.getTableValues();
          //          if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1) {
            for (MTableValue mTableValue : tableValues) {
              long parseInt = Long.parseLong(mTableValue.getXIndex());
              enumValues.add(parseInt);
              if (parseInt > HighestEnumvalue) {
                HighestEnumvalue = parseInt;
                status = true;
                //              }
            }
          }
        }
      }
    }
  } else if (applicationType instanceof MApplicationArrayType) {
    MApplicationArrayType apparray = (MApplicationArrayType) applicationType;
    MApplicationDataType arrayElementType = apparray.getArrayElementType();
    if (arrayElementType instanceof MApplicationValueType) {
      MApplicationValueType appvalue = (MApplicationValueType) arrayElementType;
      if (appvalue.getUsedComputationMethod() != null) {
        MComputationMethod usedComputationMethod = appvalue.getUsedComputationMethod();
        if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
          MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
          if (internalToPhysicalConversion instanceof MVerbalTableConversion) {
            if(internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
              String maxString = ((MVerbalTableConversion) internalToPhysicalConversion).getMax();
              max = Long.parseLong(maxString);
              isLinearConversion =true;
            }
            MVerbalTableConversion conversion = (MVerbalTableConversion) internalToPhysicalConversion;
            List<MTableValue> tableValues = conversion.getTableValues();
            //            if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1) {
              for (MTableValue mTableValue : tableValues) {
                long parseInt = Long.parseLong(mTableValue.getXIndex());
                enumValues.add(parseInt);
                if (parseInt > HighestEnumvalue) {
                  HighestEnumvalue = parseInt;
                  status = true;
                }
                //              }
            }
          }
        }
      }
    } else if (arrayElementType instanceof MApplicationBooleanType) {
      MApplicationBooleanType appbool = (MApplicationBooleanType) arrayElementType;
      if (appbool.getUsedComputationMethod() != null) {
        MComputationMethod usedComputationMethod = appbool.getUsedComputationMethod();
        if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
          MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
          if (internalToPhysicalConversion instanceof MVerbalTableConversion) {
            if(internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
              String maxString = ((MVerbalTableConversion) internalToPhysicalConversion).getMax();
              max = Long.parseLong(maxString);
              isLinearConversion =true;
            }
            MVerbalTableConversion conversion = (MVerbalTableConversion) internalToPhysicalConversion;
            List<MTableValue> tableValues = conversion.getTableValues();
            //            if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1) {
              for (MTableValue mTableValue : tableValues) {
                long parseInt = Long.parseLong(mTableValue.getXIndex());
                enumValues.add(parseInt);
                if (parseInt > HighestEnumvalue) {
                  HighestEnumvalue = parseInt;
                  status = true;
                }
                //              }
            }
          }
        }
      }
    }
  } else if (applicationType instanceof MApplicationRecordType) {
    MApplicationRecordType apprec = (MApplicationRecordType) applicationType;
    List<MApplicationRecordElement> applicationRecordElements = apprec.getApplicationRecordElements();
    if (!applicationRecordElements.isEmpty()) {
      for (MApplicationRecordElement mApplicationRecordElement : applicationRecordElements) {
        if (mApplicationRecordElement instanceof MApplicationValueType) {
          MApplicationValueType appvalue = (MApplicationValueType) mApplicationRecordElement;
          if (appvalue.getUsedComputationMethod() != null) {
            MComputationMethod usedComputationMethod = appvalue.getUsedComputationMethod();
            if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
              MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
              if (internalToPhysicalConversion instanceof MVerbalTableConversion) {
                if(internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
                  String maxString = ((MVerbalTableConversion) internalToPhysicalConversion).getMax();
                  max = Long.parseLong(maxString);
                  isLinearConversion =true;
                }
                MVerbalTableConversion conversion = (MVerbalTableConversion) internalToPhysicalConversion;
                List<MTableValue> tableValues = conversion.getTableValues();
                //                if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1) {
                  for (MTableValue mTableValue : tableValues) {
                    long parseInt = Long.parseLong(mTableValue.getXIndex());
                    enumValues.add(parseInt);
                    if (parseInt > HighestEnumvalue) {
                      HighestEnumvalue = parseInt;
                      status = true;
                    }
                    //                  }
                }
              }
            }
          }
        } else if (mApplicationRecordElement instanceof MApplicationBooleanType) {
          MApplicationBooleanType appbool = (MApplicationBooleanType) mApplicationRecordElement;
          if (appbool.getUsedComputationMethod() != null) {
            MComputationMethod usedComputationMethod = appbool.getUsedComputationMethod();
            if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
              MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
              if (internalToPhysicalConversion instanceof MVerbalTableConversion) {
                if(internalToPhysicalConversion instanceof MLinearVerbalTableConversion) {
                  String maxString = ((MVerbalTableConversion) internalToPhysicalConversion).getMax();
                  max = Long.parseLong(maxString);
                  isLinearConversion =true;
                }
                MVerbalTableConversion conversion = (MVerbalTableConversion) internalToPhysicalConversion;
                List<MTableValue> tableValues = conversion.getTableValues();
                //                if (!tableValues.isEmpty() && conversion.getTableValues().size() == 1) {
                  for (MTableValue mTableValue : tableValues) {
                    long parseInt = Long.parseLong(mTableValue.getXIndex());
                    enumValues.add(parseInt);
                    if (parseInt > HighestEnumvalue) {
                      HighestEnumvalue = parseInt;
                      status = true;
                    }
                    //                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if (status && ((isLinearConversion && value > max) || (!isLinearConversion && !enumValues.contains((long) value)))) {
    return true;
  }
  return false;
  } 
   	
public static boolean checkIfTableValueIsValid(MTableValue tableValue, MVerbalTableConversion verbalTableConversion) {
String minValueString = tableValue.getMin();
    int value = Integer.parseInt(minValueString);
    String minString = verbalTableConversion.getMin();
    String maxString = verbalTableConversion.getMax();
    int min=0;
    int max=0;
    double minDouble = 0.0;
    double maxDouble = 0.0;

    boolean minFlag = false;
    boolean maxFlag = false;
    boolean minDoubleFlag = false;
    boolean maxDoubleFlag = false;
    if(!minString.contains(".")) {
    min= Integer.parseInt(minString);
    minFlag = true;
    }

    if (minString.contains(".")) {
      minDoubleFlag = true;
      minDouble = Double.parseDouble(minString);
    }
   if(!maxString.contains(".")) {
     maxFlag = true;
     max= Integer.parseInt(maxString);
   }
   if (maxString.contains(".")) {
     maxDoubleFlag = true;
     maxDouble = Double.parseDouble(maxString);
   }
    if(minFlag && min>value ) {
      return true;
    }
    if(minDoubleFlag && minDouble>value) {
      return true;
    }

    if(maxFlag && value>max) {
      return true;
    }

    if(maxDoubleFlag &&  value>maxDouble) {
      return true;
    }




    return false;
  } 
   	
public static boolean checkIfTableValueOfVerbalTableInRange(MVerbalTableConversion verbalTableConversion) {
List<MTableValue> tableValues = verbalTableConversion.getTableValues();
  for (MTableValue mTableValue : tableValues) {
    boolean checkIfTableValueIsValid = checkIfTableValueIsValid(mTableValue, verbalTableConversion);
    if(checkIfTableValueIsValid) {
      return true;
    }
  }
  return false;
  } 
   	
public static boolean isTableValueSmallerThanEnum(MVerbalTableConversion param2, MSignal param1) {
int length = (int) (Math.pow(2, param1.getBitLength()));
  if (param2 != null && param2.getTableValues().size() > 0 && length < param2.getTableValues().size()) {
    return true;
  }
  return false;
  } 
   	
public static boolean isSignalMismatchInPDU(MPDU param1) {
List<MSignal> listSignal = new ArrayList<>();
  if (param1 != null) {
    List<MPDUTransmission> pduTxList = param1.getIPDUTransmissions();
    for(MPDUTransmission pduTms:pduTxList) {
      List<MSignalTransmission> containedSigTx = pduTms.getContainedSignalTransmissions();
      for (MSignalTransmission sigTx : containedSigTx) {
        MSignal pSignal = (MSignal) sigTx.getSignalType();
        listSignal.add(pSignal);
      }
    }

    List<MSignalIPDUAssignment> sigIPDUAssignment = param1.getSignalAssignments();
    for (MSignal sig : listSignal) {
      boolean isExist = sigIPDUAssignment.stream().anyMatch(sia -> sia.getName().equals(sig.getName()));
      if (!isExist) {
        return true;
      }
    }
  }
return false;
  } 
   	
public static boolean checkIfMissedECUInterfaceBasedOnGWEntries(MPDUTransmission pduTransmission) {
List<MIPDUGatewayRoutingEntry> routingEntriesIn = pduTransmission.getRoutingEntriesIn();
    Collection<MIPDUGatewayRoutingEntry> routingEntriesOut = pduTransmission.getRoutingEntriesOut();
    Collection<MECUInterface> sendingECUInterface = pduTransmission.getSendingECUInterface();
    Collection<MECUInterface> receivingECUInterface = pduTransmission.getReceivingECUInterface();
    for (MIPDUGatewayRoutingEntry pduGatewayRoutingEntry : routingEntriesIn) {
      MGateway gateway = pduGatewayRoutingEntry.getGatewayLookUp();
      MProcessUnit processUnit = gateway.getProcessUnit();
      MECU gatewayECU = (MECU) processUnit.getInternalComponentOwner();
      boolean receiverGatewayECUFound = false;
      for (MECUInterface mecuInterface : receivingECUInterface) {
        MSignalConnector connector = mecuInterface.getConnector();
        MDetailedElectricElectronic electronicComposite = connector.getElectronicComposite();
        if (electronicComposite instanceof MECU) {
          if (electronicComposite == gatewayECU) {
            receiverGatewayECUFound = true;
          }
        }
      }

      if (!receiverGatewayECUFound) {
        return true;
      }
    }

    for (MIPDUGatewayRoutingEntry pduGatewayRoutingEntry : routingEntriesOut) {
      MGateway gateway = pduGatewayRoutingEntry.getGatewayLookUp();
      MProcessUnit processUnit = gateway.getProcessUnit();
      MECU gatewayECU = (MECU) processUnit.getInternalComponentOwner();
      boolean senderGatewayECUFound = false;
      for (MECUInterface mecuInterface : sendingECUInterface) {
        MSignalConnector connector = mecuInterface.getConnector();
        MDetailedElectricElectronic electronicComposite = connector.getElectronicComposite();
        if (electronicComposite instanceof MECU) {
          if (electronicComposite == gatewayECU) {
            senderGatewayECUFound = true;
          }
        }
      }

      if (!senderGatewayECUFound) {
        return true;
      }
    }

    return false;
  } 
   	
public static boolean isTableValueBiggerThanMaxConversion(MTableValue param1, MVerbalTableConversion param2) {
if ((param1.getXIndex() != null) && (param2.getMax() != null) && !(param1.getName().contains("SNA_"))) {
			String xIndex = param1.getXIndex();

			Integer xIndexIntCandidate = null;
			try {
				xIndexIntCandidate = Integer.parseInt(xIndex);
			} catch (NumberFormatException nfe) {

			}

			String max = param2.getMax();

			Integer maxIntCandidate = null;
			try {
				maxIntCandidate = Integer.parseInt(max);
			} catch (NumberFormatException nfe) {

			}

			if (xIndexIntCandidate != null && maxIntCandidate != null) {
				if(xIndexIntCandidate > maxIntCandidate){
					return true;
				}else{
					return false;
				}

			}
		}
		return false;
  } 
   	
public static boolean isSignalInitialValueOutOfRange(MIntegerLiteral param1, MAbstractConversionSpecification param2) {
if (param2 instanceof MLinearConversion) {
			MLinearConversion linConv = (MLinearConversion) param2;

			Integer minIntCandidate = null;
			Integer maxIntCandidate = null;

			try {
				minIntCandidate = Integer.parseInt(linConv.getMin());
				maxIntCandidate = Integer.parseInt(linConv.getMax());
			} catch (NumberFormatException nfe) {

			}

			if(minIntCandidate != null && maxIntCandidate != null){
				if (param1.getValue() < minIntCandidate || param1.getValue() > maxIntCandidate) {
					return true;
				} else {
					return false;
				}
			}

		}
		if (param2 instanceof MVerbalTableConversion) {
			MVerbalTableConversion verTabConv = (MVerbalTableConversion) param2;

			Integer minIntCandidate = null;
			Integer maxIntCandidate = null;

			try {
				minIntCandidate = Integer.parseInt(verTabConv.getMin());
				maxIntCandidate = Integer.parseInt(verTabConv.getMax());
			} catch (NumberFormatException nfe) {

			}

			if(minIntCandidate != null && maxIntCandidate != null){
				if (param1.getValue() < minIntCandidate || param1.getValue() > maxIntCandidate) {
					return true;
				} else {
					return false;
				}
			}

		}

		return false;
  } 
   	
public static boolean isArraySizeMismatch(MArraySpecification aSpec, MImplementationArray iArray) {
if((aSpec.getArrayElements().size()) !=  ((iArray.getArraySize())) ){
		  return true;
	  }
	  return false;
  } 
   	
public static boolean hasSection(MEEDiagram EEDiagram) {
boolean hasSection = false;
		if (EEDiagram.getContained() != null) {
			List<MDiagramElement> contained = EEDiagram.getContained();
			outerloop: for (MDiagramElement element : contained) {
				if (element instanceof MChildAreaGraphNode) {
					MChildAreaGraphNode childGraphNode = (MChildAreaGraphNode) element;
					List<MDiagramElement> contained2 = childGraphNode.getContained();
					for (MDiagramElement element2 : contained2) {
						if (element2 instanceof MSectionGraphNode) {
							hasSection = true;
							break outerloop;
						}
					}
				}
			}
		}
		return hasSection;
  } 
   	
public static boolean isNmCoordinatorExistInNmCluster(MCanNmCluster param1) {
if (param1 instanceof MCanNmCluster) {
    MCanNmCluster mnc = param1;
    List<MAbstractNmNode> st = mnc.getNmNodes();
    for (MAbstractNmNode mnode : st) {
      if(mnode.getNmCoordinatorRole()==null) {
        if(mnode.getCoordinatorNmECU().size()==0) {
          return true;
        }
      }else {
        if(mnode.getCoordinatorNmECU().size()>0) {
          return true;
        }
      }
    }
  }
return false;
  } 
   	
public static boolean IsBaseTypeEncodingCompatible(MBaseType param1) {
if(param1.getBaseTypeEncoding()==null) {
    return true;
  }
if (param1.getName().equals("boolean_I")&& !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.BOOLEAN)) {
    return true;
  }else if(param1.getName().equals("boolean_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.BOOLEAN)) {
    return true;
  } else if (param1.getName().equals("float32_I") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.IEEE754)) {
    return true;
  } else if( param1.getName().equals("float32_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.IEEE754)){
    return true;
  }else if( param1.getName().equals("float64_I") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.IEEE754)){
    return true;
  }else if( param1.getName().equals("float64_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.IEEE754)){
    return true;
  }else if (param1.getName().equals("sint8_I") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum._2C)) {
    return true;
  }else if (param1.getName().equals("sint8_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum._2C)) {
    return true;
  }else if (param1.getName().equals("sint16_I") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum._2C)) {
    return true;
  }else if (param1.getName().equals("sint16_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum._2C)) {
    return true;
  }else if (param1.getName().equals("sint32_I") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum._2C)) {
    return true;
  }else if (param1.getName().equals("sint32_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum._2C)) {
    return true;
 } else if(param1.getName().equals("uint8_I") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.NONE)) {
   return true;
 }else if(param1.getName().equals("uint8_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.NONE)) {
   return true;
 }else if(param1.getName().equals("uint16_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.NONE)) {
   return true;
 }else if(param1.getName().equals("uint16_I") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.NONE)) {
   return true;
 }else if(param1.getName().equals("uint32_I") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.NONE)) {
   return true;
 }else if(param1.getName().equals("uint32_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.NONE)) {
   return true;
 }else if(param1.getName().equals("uint64_I") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.NONE)) {
   return true;
 }else if(param1.getName().equals("uint64_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.NONE)) {
   return true;
 }else if (param1.getName().equals("char_M") && !param1.getBaseTypeEncoding().equals(MBaseTypeEncodingEnumEnum.ISO_8859_1)) {
   return true;
 }
return false;
  } 
   	
public static boolean IsBaseTypeNameBitLengthCompatible(MBaseType param1) {
if (param1.getName().equals("boolean_I")) {
    return param1.getBitLength() != 8 ? true : false;
  } else if (param1.getName().equals("boolean_M")) {
    return param1.getBitLength() != 8 ? true : false;
  } else if (param1.getName().equals("char_M")) {
    return param1.getBitLength() != 8 ? true : false;
  }
  Pattern pattern = Pattern.compile("\\d+");
  Matcher matcher = pattern.matcher(param1.getName());
  while (matcher.find()) {
    int blength = Integer.parseInt(matcher.group());
    if (blength !=param1.getBitLength()) {
      return true;
    }
  }
return false;
  } 
   	
public static boolean IsByteOrderCompatible(MBaseType param1) {
if(param1.getByteOrder()!=null) {
    String bname = param1.getName().substring(param1.getName().lastIndexOf("_") + 1, param1.getName().length());
    if (param1.getByteOrder().equals(MByteOrderKindEnum.BIGENDIAN)) {
      if (!bname.equals("M")) {
        return true;
      }
    } else if (param1.getByteOrder().equals(MByteOrderKindEnum.LITTLEENDIAN)) {
      if (!bname.equals("I")) {
        return true;
      }
    } else if (param1.getByteOrder().equals(MByteOrderKindEnum.OPAQUE)) {
      if (!bname.equals("N")) {
        return true;
      }
    }

  }

return false;
  } 
   	
public static boolean isSignalGrpAndPortExistInRentity(MSignal param2, MReceiverPortType param1, MSignalGroup param3) {
boolean isExist = true;
MSystemSignalGroup sysGrp = param3.getSystemSignalGroup();
 List<MPortPrototypeReadAccess> drList =  param1.getDataReadAccess();
 if (drList != null && drList.size() > 0) {
   MPortPrototypeReadAccess mbracess = drList.get(0);
   if (mbracess instanceof MDataRead) {
     MDataRead mdataRead = (MDataRead) mbracess;

     Collection<MAbstractPort> mabsPort = sysGrp.getPortInstances();
     for(MAbstractPort mabport :mabsPort) {
       if(mabport instanceof MSWPort) {
         MSWPort mswPort = (MSWPort)mabport;
         MSWPortPrototype msWPtype = mswPort.getSwPortPrototype();
         MAbstractPortType mrPtype = msWPtype.getPortType();
         if(mrPtype instanceof MReceiverPortType) {
           MReceiverPortType mrcPtype = (MReceiverPortType)mrPtype;
           MPortTypeOwner appSwComp = mrcPtype.getPortTypeOwner();
           if (appSwComp instanceof MApplicationSWComponentType) {
             MApplicationSWComponentType mappSWC = (MApplicationSWComponentType) appSwComp;
             List<MPortType> ownedPorts = mappSWC.getOwnedPorts();

             for(MPortType port :ownedPorts) {
               if (port instanceof MReceiverPortType) {
                 MReceiverPortType mrtype = (MReceiverPortType)port;
                 if(param2.getName().contains(mrtype.getName())) {
                   if (mrtype.getDataReadAccess() != null && mrtype.getDataReadAccess().size() > 0) {
                     MPortPrototypeReadAccess dataReadAccess = mrtype.getDataReadAccess().get(0);
                     if (dataReadAccess instanceof MDataRead) {
                       MDataRead mreadAccess = (MDataRead) dataReadAccess;
                       if(mreadAccess!=null &&  mreadAccess.getRunnableEntity()!=null) {
                        MRunnableEntity re =  mreadAccess.getRunnableEntity();

                       List<MVariableAccess> vaccess =  re.getVariableAccess();

                       for (MVariableAccess access : vaccess) {
                         if (access instanceof MDataRead) {
                           MDataRead readAccess = (MDataRead) access;
                           if (readAccess.getName().equalsIgnoreCase(param3.getName())) {
                             isExist = false;
                           }
                         }
                       }
                       }
                   }
                 }
               }
             }

           }
         }
        }
     }

   }
  }
}
return isExist;
  } 
   	
public static boolean isValidDataTypeMappedInADTToIDT(MApplicationDataType param1) {
if (param1 instanceof MApplicationBooleanType) {
  MApplicationBooleanType maType = (MApplicationBooleanType) param1;
  List<MApplicationTypeImplementationTypeMapping> appImappings = maType.getApplicationTypeImplementationTypeMappings();
  for(MApplicationTypeImplementationTypeMapping mappIm:appImappings) {
    MImplementationDataType impDtype = mappIm.getImplementationDataType();
    if(impDtype instanceof MImplementationValue) {
      MImplementationValue mIvalue = (MImplementationValue)impDtype;
      MBaseType mimpKind = mIvalue.getBaseType().get(0);
      String mvl = mIvalue.getImplementationType().toString();
      if (!mimpKind.getBaseTypeEncoding().toString().equalsIgnoreCase("Boolean")) {
        return true;
      }
    }
  }

  }
  if (param1 instanceof MApplicationValueType) {
    MApplicationValueType maType = (MApplicationValueType) param1;
    List<MApplicationTypeImplementationTypeMapping> appImappings = maType.getApplicationTypeImplementationTypeMappings();
    for (MApplicationTypeImplementationTypeMapping mappIm : appImappings) {
      MImplementationDataType impDtype = mappIm.getImplementationDataType();
      if (impDtype instanceof MImplementationValue) {
        MImplementationValue mIvalue = (MImplementationValue) impDtype;
        MBaseType mimpKind = mIvalue.getBaseType().get(0);
        String mvl = mIvalue.getImplementationType().toString();
        if (mvl.equals("INTEGER") && mimpKind.getBaseTypeEncoding().toString().equalsIgnoreCase("Boolean")) {
          return true;
        }
      }
    }
  }

  return false;
  } 
   	
public static boolean rxEcuMissingInPduSignalTx(MPDUTransmission param1) {
List<String> listEcu = new ArrayList<>();
Collection<MECUInterface> rxECuList = param1.getReceivingECUInterface();
  List<MSignalTransmission> stList = param1.getContainedSignalTransmissions();
  for(MSignalTransmission stx:stList) {
    Collection<MECUInterface> stxRxEcu = stx.getReceivingECUInterface();
    for (MECUInterface ecu : stxRxEcu) {
      if (!listEcu.contains(ecu.getName())) {
        listEcu.add(ecu.getName());
      }
    }
  }


  if(stList!=null && stList.size()>0) {
  for (MECUInterface rxEcu : rxECuList) {
    if (!listEcu.contains(rxEcu.getName())) {
      return true;
    }
  }
  }

return false;
  } 
   	
public static boolean rxEcuMissingInFramePduTx(MFrameTransmission param1) {
List<String> listEcu = new ArrayList<>();
  Collection<MECUInterface> rxECuList = param1.getReceivingECUInterface();
    List<MPDUTransmission> ptList = param1.getContainedIPDUTransmissions();
    for(MPDUTransmission ptx:ptList) {
      Collection<MECUInterface> ptxRxEcu = ptx.getReceivingECUInterface();
      for (MECUInterface ecu : ptxRxEcu) {
        if (!listEcu.contains(ecu.getName())) {
          listEcu.add(ecu.getName());
        }
      }
    }
    for (MECUInterface rxEcu : rxECuList) {
      if (!listEcu.contains(rxEcu.getName())) {
        return true;
      }
    }
  return false;
  } 
   	
public static boolean IsMxPduGwTypeWrong(MDynamicPart param2, MIPDU param1) {
boolean isGwExist = false;
  List<MPDUTransmission> mptxList = param1.getIPDUTransmissions();
  for (MPDUTransmission ptx : mptxList) {
    if (ptx.getRoutingEntriesIn().size() > 0 || ptx.getRoutingEntriesOut().size() > 0) {
      isGwExist = true;
      break;
    }
  }
  if (isGwExist) {
    if(param1 instanceof MMultiplexedIPDU) {
    List<MDynamicPartAlternative> daList = param2.getDynamicPartAlternatives();
    for (MDynamicPartAlternative dpa : daList) {
      MSignalIPDU spdu = dpa.getIpdu();
      List<MSignalIPDUAssignment> spaList = spdu.getSignalAssignments();
      List<MPDUTransmission> sptxList = spdu.getIPDUTransmissions();
      for (MPDUTransmission sptx : sptxList) {
        for (MSignalIPDUAssignment msa : spaList) {
          Optional<MSignalTransmission> isExist = sptx.getContainedSignalTransmissions().stream().filter(a -> a.getName().equals(msa.getName())).findAny();
          if(!isExist.isPresent()) {
            return true;
          }
        }
      }
    }
    }else if(param1 instanceof MSignalIPDU) {
      List<MSignalIPDUAssignment> spaList = param1.getSignalAssignments();
      for (MPDUTransmission sptx : mptxList) {
      for (MSignalIPDUAssignment msa : spaList) {
        Optional<MSignalTransmission> isExist = sptx.getContainedSignalTransmissions().stream().filter(a -> a.getName().equals(msa.getName())).findAny();
        if(!isExist.isPresent()) {
          return true;
        }
      }
      }
    }
    }
return false;
  } 
   	
public static boolean isGwExistInPDUAndSignal(MDynamicPart param2, MIPDU param1) {
boolean isGwExist = false;
  boolean isSignalexist = false;
  List<MPDUTransmission> mptxList = param1.getIPDUTransmissions();
  for (MPDUTransmission ptx : mptxList) {
    if (ptx.getRoutingEntriesIn().size() > 0 || ptx.getRoutingEntriesOut().size() > 0) {
      isGwExist = true;
      break;
    }
  }
  if (isGwExist) {
    if (param1 instanceof MMultiplexedIPDU) {
      List<MDynamicPartAlternative> daList = param2.getDynamicPartAlternatives();
      for (MDynamicPartAlternative dpa : daList) {
        MSignalIPDU spdu = dpa.getIpdu();
        List<MSignalIPDUAssignment> spaList = spdu.getSignalAssignments();
        List<MPDUTransmission> sptxList = spdu.getIPDUTransmissions();
        for (MPDUTransmission sptx : sptxList) {
          for (MSignalIPDUAssignment msa : spaList) {
            Optional<MSignalTransmission> isExist = sptx.getContainedSignalTransmissions().stream().filter(a -> a.getName().equals(msa.getName())).findAny();
            if (isExist.isPresent()) {
              //return true;
            } else {
              return false;
            }
          }
          List<MSignalTransmission> conSigTxList = sptx.getContainedSignalTransmissions();
          for(MSignalTransmission stx:conSigTxList) {
            if(stx.getRoutingEntriesIn().size()==0 &&  stx.getRoutingEntriesOut().size()==0) {
              return true;
            }
          }
        }
      }

    } else if (param1 instanceof MSignalIPDU) {
      List<MSignalIPDUAssignment> spaList = param1.getSignalAssignments();
      for (MPDUTransmission sptx : mptxList) {
        for (MSignalIPDUAssignment msa : spaList) {
          Optional<MSignalTransmission> isExist = sptx.getContainedSignalTransmissions().stream().filter(a -> a.getName().equals(msa.getName())).findAny();
          if (isExist.isPresent()) {
            //return true;
          } else {
            return false;
          }
        }
        List<MSignalTransmission> conSigTxList = sptx.getContainedSignalTransmissions();
        for(MSignalTransmission stx:conSigTxList) {
          if(stx.getRoutingEntriesIn().size()==0 &&  stx.getRoutingEntriesOut().size()==0) {
            return true;
          }
        }
      }
    }
  }
return false;
  } 
   	
public static boolean IsDomainController(MSoftwareTypePackage param1) {
if (param1.getName().contains("Domain_Controller")) {
    return true;
  } else {
    MSoftwareTypeContainer spc = param1.getSoftwareTypePackageOwner();
    if (spc instanceof MSoftwareTypePackage) {
      MSoftwareTypePackage sp = (MSoftwareTypePackage) spc;
      if (sp.getName().contains("Domain_Controller")) {
        return true;
      } else if (sp.getName().contains("Vehicle Domains")) {
        return false;
      } else {
        MSoftwareTypePackage swp = getSwpkg(sp);
        if (swp.getName().contains("Domain_Controller")) {
          return true;
        }else if (swp.getName().contains("Vehicle Domains")) {
          return false;
        }
      }
    }
  }
return false;
  } 
   	
public static MSoftwareTypePackage getSwpkg(MSoftwareTypePackage param1) {
MSoftwareTypeContainer spc = param1.getSoftwareTypePackageOwner();
    if (spc instanceof MSoftwareTypePackage) {
      MSoftwareTypePackage sp = (MSoftwareTypePackage) spc;
      return sp;
    }
    return null;
  } 
   	
public static boolean IsImplValueMinMaxCompatibleWithbaseType(MBaseType param2, MGenericInternalDataConstraint param1) {
if (param2.getName().equals("sint8_I") || param2.getName().equals("sint8_M") || param2.getName().equals("sint16_I") || param2.getName().equals("sint16_M")
    || param2.getName().equals("sint32_I") || param2.getName().equals("sint32_M")) {

long calculatedmax = (long) Math.pow(2, param2.getBitLength());
  long calval = calculatedmax/2;
  long calMax = calval-1;
  String cmin = String.valueOf(-calval);
  String cmax = String.valueOf(calMax);
  if (!param1.getMax().equals(cmax) || !param1.getMin().equals(cmin)) {
    return true;
  }

} else if (param2.getName().equals("uint8_I") || param2.getName().equals("uint8_M") || param2.getName().equals("uint16_I")
           || param2.getName().equals("boolean_M") || param2.getName().equals("boolean_I") || param2.getName().equals("uint16_M")
           || param2.getName().equals("uint32_I") || param2.getName().equals("uint32_M")) {

  long calculatedmax = (long) Math.pow(2, param2.getBitLength());
  long calMax = calculatedmax - 1;
  long max = Long.parseLong(param1.getMax());
  long min = Long.parseLong(param1.getMin());
  if ((min!=0) || max>calMax) {
    return true;
  }

} else {
if (!param1.getMin().equals("0") &&  !param2.getName().contains("float")) {
  return true;
}
if (param2 != null && ! param2.getName().contains("float")) {
  int calculatedmax = (int) Math.pow(2, param2.getBitLength()) - 1;
  String cmax = String.valueOf(calculatedmax);
  if (!param1.getMax().equals(cmax)) {
    return true;
  }
}
}
return false;
  } 
   	
public static boolean IsCarConfigRxPortReceiveFromZaDomainctrl(MSystemSignal param1) {
List<MSWPort> swList = param1.getPortInstances().stream().filter(MSWPort.class::isInstance).map(MSWPort.class::cast).collect(Collectors.toList());
    boolean isTxSwc = false;
    for (MSWPort ssw : swList) {
      MAbstractPortType stype = ssw.getSwPortPrototype().getPortType();
      if(stype instanceof MSenderPortType) {
        isTxSwc = true;
        MSenderPortType mst = (MSenderPortType)stype;
        MPortTypeOwner po = mst.getPortTypeOwner();
        if (po instanceof MApplicationSWComponentType) {
          MApplicationSWComponentType mappSWC = (MApplicationSWComponentType) po;
          if (!mappSWC.getName().contains("CarConfigurationZa1")) {
            return true;
          }
        }
      }
    }
    if(!isTxSwc) {
      return true;
    }
  return false;
  } 
   	
public static boolean IsApplArrayDataTypeMappingSameAsCSIPort(MApplicationArrayType param1) {
int count = 0;
    Set<MPortTypeOwner> swcs = new HashSet<>();
    Collection<MOperationArgument> opaList = param1.getApplicationTypedArtefacts().stream().filter(MOperationArgument.class::isInstance).map(MOperationArgument.class::cast).collect(Collectors.toList());

    for (MOperationArgument opa : opaList) {
      MClientServerInterface csi = opa.getOwningOperation().getCsInterface();
      List<MClientServerPortType> portTypes = csi.getPortAssignments().stream().map(interfaceAssign -> interfaceAssign.getAssignedFromPort()).filter(MClientServerPortType.class::isInstance).map(MClientServerPortType.class::cast).collect(Collectors.toList());
      for (MClientServerPortType portType : portTypes) {
        if (portType instanceof MClientPortType) {
          MPortTypeOwner portTypeOwner = ((MClientPortType) portType).getPortTypeOwner();
          swcs.add(portTypeOwner);
        }
        if (portType instanceof MServerPortType) {
          MPortTypeOwner portTypeOwner = ((MServerPortType) portType).getPortTypeOwner();
          swcs.add(portTypeOwner);
        }
      }

    }
    count = swcs.size();

    if (param1.getApplicationTypeImplementationTypeMappings().size() != count) {
      return true;
    }

    return false;
  } 
   	
public static boolean IsApplArrayDataTypeMappingSameAsSRIPort(MApplicationArrayType param1) {
int count = 0;
Set<MPortTypeOwner> swcs=new HashSet<>();
  Collection<MDataElement> deList = param1.getApplicationTypedArtefacts().stream().filter(MDataElement.class::isInstance).map(MDataElement.class::cast).collect(Collectors.toList());

  for(MDataElement de:deList) {
    List<MInterfaceAssignment> csi = de.getSrInterface().getPortAssignments();
    List<MSenderReceiverPortType> portTypes = csi.stream().map(interfaceAssign -> interfaceAssign.getAssignedFromPort()).filter(MSenderReceiverPortType.class::isInstance).map(MSenderReceiverPortType.class::cast).collect(Collectors.toList());

    for (MSenderReceiverPortType portType : portTypes) {
      if (portType instanceof MSenderPortType) {
        MPortTypeOwner portTypeOwner = ((MSenderPortType) portType).getPortTypeOwner();
        swcs.add(portTypeOwner);
      }
      if (portType instanceof MReceiverPortType) {
        MPortTypeOwner portTypeOwner = ((MReceiverPortType) portType).getPortTypeOwner();
        swcs.add(portTypeOwner);
      }
    }count=swcs.size();
  }
  if(param1.getApplicationTypeImplementationTypeMappings().size()!=count) {
    return true;
  }

return false;
  } 
   	
public static boolean isIDTAndADTElemnetsEqual(MImplementationRecord param2, MApplicationRecordType param1) {
List<String> appElementList = param1.getApplicationRecordElements().stream().map(a -> a.getName()).collect(Collectors.toList());
  List<String> implElementList = param2.getImplementationRecordElements().stream().map(a -> a.getName()).collect(Collectors.toList());
return implElementList.equals(appElementList)?false:true;
  } 
   	
public static boolean IsApplRecordmappingExistRxTxSwc(MApplicationRecordType param2, MSenderReceiverInterface param1) {
int count = 0;
  Set<MPortTypeOwner> swcs = new HashSet<>();
  Collection<MDataElement> deList = param2.getApplicationTypedArtefacts().stream().filter(MDataElement.class::isInstance).map(MDataElement.class::cast).collect(Collectors.toList());
  for (MDataElement de : deList) {
    List<MInterfaceAssignment> csi = de.getSrInterface().getPortAssignments();
    List<MSenderReceiverPortType> portTypes = csi.stream().map(interfaceAssign -> interfaceAssign.getAssignedFromPort()).filter(MSenderReceiverPortType.class::isInstance).map(MSenderReceiverPortType.class::cast).collect(Collectors.toList());
    for (MSenderReceiverPortType portType : portTypes) {
      if (portType instanceof MSenderPortType) {
        MPortTypeOwner portTypeOwner = ((MSenderPortType) portType).getPortTypeOwner();
        swcs.add(portTypeOwner);
      }
      if (portType instanceof MReceiverPortType) {
        MPortTypeOwner portTypeOwner = ((MReceiverPortType) portType).getPortTypeOwner();
        swcs.add(portTypeOwner);
      }
    }
    count = swcs.size();
  }

  if (param2.getApplicationTypeImplementationTypeMappings().size() != count) {
    return true;
  }

  return false;
  } 
   	
public static boolean isDnamicPartOffsetTimevalid(MDynamicPart param1) {
List<MDynamicPartAlternative> dyaList = param1.getDynamicPartAlternatives();
double ts = dyaList.size();
double timePeriod = 0.0;
double totalOffset = 0;
boolean isExist = false;
  for(MDynamicPartAlternative dya:dyaList) {
    if (!isExist) {
      timePeriod = dya.getIpdu().getCyclicTimings().get(0).getTimePeriod();
      totalOffset = timePeriod / ts;
      isExist = true;
    }

    double offsetTime = (dya.getSelectorFieldCode() * totalOffset);

    if(dya.getIpdu().getCyclicTimings().get(0).getTimeOffset()!=offsetTime) {
return true;
    }


  }

return false;
  } 
   	
public static boolean IsPDuGwExistSignalNotExist(MSignalIPDU param1) {
boolean isGwExist = false;
  List<MPDUTransmission> mptxList = param1.getIPDUTransmissions();
  for (MPDUTransmission ptx : mptxList) {
    if (ptx.getRoutingEntriesIn().size() > 0 || ptx.getRoutingEntriesOut().size() > 0) {
      isGwExist = true;
      break;
    }
  }
  if (isGwExist) {
    List<MSignalIPDUAssignment> spaList = param1.getSignalAssignments();
    for (MPDUTransmission sptx : mptxList) {
    for (MSignalIPDUAssignment msa : spaList) {
      Optional<MSignalTransmission> isExist = sptx.getContainedSignalTransmissions().stream().filter(a -> a.getName().contains(msa.getName())).findAny();
      if(!isExist.isPresent()) {
        return true;
      }
    }
    }

  }
return false;
  } 
   	
public static boolean IsPduAndSignalGwExist(MPDUTransmission param1) {
if (param1.getRoutingEntriesIn().size() > 0 || param1.getRoutingEntriesOut().size() > 0) {
    List<MSignalTransmission> conSigTxList = param1.getContainedSignalTransmissions();
    for(MSignalTransmission stx:conSigTxList) {
      if(stx.getRoutingEntriesIn().size()==0 &&  stx.getRoutingEntriesOut().size()==0) {
        return true;
      }
    }
  }

return false;
  } 
   	
public static boolean IsCompMethodFactorOffsetContainsFloatValue(MMinMaxGeneric param1) {
if (param1 instanceof MLinearConversion) {
    MLinearConversion linear = (MLinearConversion) param1;
    double factor = linear.getFactor();
    double offset = linear.getOffset();
    String sfactor = String.valueOf(factor);
    String soffset = String.valueOf(offset);
    if (sfactor.endsWith(".0") && soffset.endsWith(".0")) {
      if(linear.getMax().contains(".") ||linear.getMin().contains(".")) {
        return true;
      }
    }
  } else if(!(param1 instanceof MLinearVerbalTableConversion) && param1 instanceof MVerbalTableConversion) {
    MVerbalTableConversion verbal = (MVerbalTableConversion) param1;
    if(verbal.getMax().contains(".") ||verbal.getMin().contains(".")) {
      return true;
    }
  }

else if (param1 instanceof MLinearVerbalTableConversion) {
    MLinearVerbalTableConversion linearverbal = (MLinearVerbalTableConversion) param1;
    double factor = linearverbal.getFactor();
    double offset = linearverbal.getOffset();
    String sfactor = String.valueOf(factor);
    String soffset = String.valueOf(offset);
    if (sfactor.endsWith(".0") && soffset.endsWith(".0")) {
      if(linearverbal.getMax().contains(".") ||linearverbal.getMin().contains(".")) {
        return true;
      }
    }
  }
return false;
  } 
   	
public static boolean IsOperationInvokeCountSameAsCSIPorts(MRunnableEntity param2, MSensorActuatorSWComponentType param1) {
int count = 0,dacount=0;
  List<MPortType> ownedPorts = param1.getOwnedPorts();
  for (MPortType mPortType : ownedPorts) {
    if(mPortType instanceof MClientPortType) {
      count++;
    }
  }

  List<MVariableAccess> vac = param2.getVariableAccess();
  for(MVariableAccess vas:vac) {
    if(vas instanceof MOperationInvoke) {
      dacount++;
    }
  }

  if(dacount!=count) {
    return true;
  }


return false;
  } 
   	
public static boolean isTableValueXIndexEmpty(MTableValue param1) {
if(param1.getXIndex()==null || (param1.getMinIntervalType().equals(MIntervalTypeKindEnum.CLOSED) && (!param1.getMin().equals(param1.getXIndex()) || !param1.getMax().equals(param1.getXIndex())))) {
    return true;
  }
return false;
  } 
   	
public static boolean isInitialValueWithInRange(MDataElement param1) {
boolean status = false;
  long HighestEnumvalue = 0;
  int value = 0;
  boolean isCompMethodExist = false;
if(! (param1.getInitValue() instanceof MIntegerLiteral)) {
  return false;
}
  MApplicationDataType applicationType = param1.getApplicationType();
  if (applicationType instanceof MApplicationValueType) {
    MApplicationValueType appvalue = (MApplicationValueType) applicationType;
  MValueSpecification initValue = param1.getInitValue();
  if (initValue instanceof MIntegerLiteral) {
    MIntegerLiteral literal = (MIntegerLiteral) initValue;
    value = literal.getValue();
  }

  if (applicationType instanceof MApplicationValueType) {
    if (appvalue.getUsedComputationMethod() != null) {
      MComputationMethod usedComputationMethod = appvalue.getUsedComputationMethod();
      if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
        MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
        if (!(internalToPhysicalConversion instanceof MLinearVerbalTableConversion) && internalToPhysicalConversion instanceof MVerbalTableConversion) {
          isCompMethodExist = true;
          MVerbalTableConversion conversion = (MVerbalTableConversion) internalToPhysicalConversion;
          List<MTableValue> tableValues = conversion.getTableValues();
          if (!tableValues.isEmpty() && conversion.getTableValues().size() > 0) {
            for (MTableValue mTableValue : tableValues) {
              int parseInt = Integer.parseInt(mTableValue.getXIndex());
              if (parseInt == value) {
                HighestEnumvalue = parseInt;
                return false;
              }
            }
          }
        }else {
          return false;
        }
      }
    }
  }
  } else if (applicationType instanceof MApplicationBooleanType) {
    MApplicationBooleanType appbool = (MApplicationBooleanType) applicationType;
    if (appbool.getUsedComputationMethod() != null) {
      MComputationMethod usedComputationMethod = appbool.getUsedComputationMethod();
      if (usedComputationMethod.getInternalToPhysicalConversion() != null) {
        MAbstractConversionSpecification internalToPhysicalConversion = usedComputationMethod.getInternalToPhysicalConversion();
        if (!(internalToPhysicalConversion instanceof MLinearVerbalTableConversion) && internalToPhysicalConversion instanceof MVerbalTableConversion) {
          isCompMethodExist = true;
          MVerbalTableConversion conversion = (MVerbalTableConversion) internalToPhysicalConversion;
          List<MTableValue> tableValues = conversion.getTableValues();
          if (!tableValues.isEmpty() && conversion.getTableValues().size() > 0) {
            for (MTableValue mTableValue : tableValues) {
              int parseInt = Integer.parseInt(mTableValue.getXIndex());
              if (parseInt == value) {
                HighestEnumvalue = parseInt;
                return false;
              }
            }
          }
        }else {
          return false;
        }
      }
    }
  } else if (applicationType instanceof MApplicationRecordType || applicationType instanceof MImplementationRecord
             || applicationType instanceof MApplicationArrayType || applicationType instanceof MArraySpecification) {
    return false;
  }
  if (isCompMethodExist && !status) {
    return true;
  }
  return false;
  } 
   	
  
  // 
  
  public String getLastModified() {
  					   return "1762321236000";
  }
}
